<?php
/**
 * Root Entrypoint Forwarder
 * Enables transparent hosting on both local OSPanel domains and cPanel shared hosting.
 */
declare(strict_types=1);

require_once __DIR__ . '/public/index.php';

