<?php
declare(strict_types=1);

namespace Controllers;

use Core\Controller;
use Core\Response;
use Models\Document;

class DocumentController extends Controller
{
    public function index(): string
    {
        $cat = $this->request->get('cat');
        $docModel = new Document();
        $docs = $docModel->allActive($cat);

        return $this->render('documents.index', [
            'title' => trans('documents') . ' - ' . setting('site_name', 'Kosonsoy Kolleji'),
            'documents' => $docs,
            'currentCat' => $cat
        ], 'layouts.main');
    }

    public function download(int $id)
    {
        $docModel = new Document();
        $doc = $docModel->find($id);

        if (!$doc || $doc['is_active'] != 1) {
            Response::setStatusCode(404);
            return $this->render('errors.404', ['title' => 'Hujjat topilmadi'], 'layouts.main');
        }

        $docModel->incrementDownloads($id);

        $path = dirname(__DIR__) . '/public' . $doc['file_path'];
        if (!file_exists($path)) {
            $this->flashError("Hujjat fayli serverda topilmadi.");
            return $this->redirect('/documents');
        }

        return Response::download($path, basename($doc['file_path']));
    }
}

