<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\AuditLog;
use Models\Menu;

class MenuAdminController extends Controller
{
    public function index(): string
    {
        $m = new Menu();
        return $this->render('admin.menus.index', [
            'title' => 'Menyular boshqaruvi',
            'menus' => $m->where('1=1', [], 'location ASC, sort_order ASC, id ASC')
        ], 'layouts.admin');
    }

    public function store()
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'title_uz' => 'required',
            'url' => 'required'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/menus');
        }

        $m = new Menu();
        $id = $m->create([
            'parent_id' => !empty($data['parent_id']) ? (int)$data['parent_id'] : null,
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'url' => trim((string)$data['url']),
            'target' => $data['target'] ?? '_self',
            'location' => $data['location'] ?? 'header',
            'sort_order' => (int)($data['sort_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'CREATE', 'menus', $id, "Menyu bandi qo'shildi: " . $data['title_uz']);
        $this->flashSuccess("Menyu bandi muvaffaqiyatli qo'shildi.");
        return $this->redirect('/admin/menus');
    }

    public function update(int $id)
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'title_uz' => 'required',
            'url' => 'required'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/menus');
        }

        $m = new Menu();
        $m->update($id, [
            'parent_id' => !empty($data['parent_id']) ? (int)$data['parent_id'] : null,
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'url' => trim((string)$data['url']),
            'target' => $data['target'] ?? '_self',
            'location' => $data['location'] ?? 'header',
            'sort_order' => (int)($data['sort_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'UPDATE', 'menus', $id, "Menyu bandi yangilandi: " . $data['title_uz']);
        $this->flashSuccess("Menyu bandi yangilandi.");
        return $this->redirect('/admin/menus');
    }

    public function delete(int $id)
    {
        $m = new Menu();
        $m->delete($id);
        AuditLog::log(Auth::id(), 'DELETE', 'menus', $id, "Menyu o'chirildi");
        $this->flashSuccess("Menyu bandi o'chirildi.");
        return $this->redirect('/admin/menus');
    }
}

