<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\Database;
use Core\AuditLog;
use Services\UploadService;

class MediaAdminController extends Controller
{
    public function index(): string
    {
        $db = Database::getInstance();
        $media = $db->query("SELECT m.*, u.full_name as uploader FROM media m LEFT JOIN users u ON u.id = m.user_id ORDER BY m.id DESC");

        return $this->render('admin.media.index', [
            'title' => 'Fayllar menejeri (Media kutubxona)',
            'media' => $media
        ], 'layouts.admin');
    }

    public function upload()
    {
        if (!$this->request->hasFile('file')) {
            $this->flashError("Yuklash uchun fayl tanlang.");
            return $this->redirect('/admin/media');
        }

        try {
            UploadService::uploadDocument($this->request->file('file'), 'media');
            $this->flashSuccess("Fayl muvaffaqiyatli yuklandi.");
        } catch (\Throwable $e) {
            $this->flashError("Fayl yuklashda xato: " . $e->getMessage());
        }

        return $this->redirect('/admin/media');
    }

    public function delete(int $id)
    {
        $db = Database::getInstance();
        $item = $db->first("SELECT * FROM media WHERE id = ?", [$id]);

        if ($item) {
            $fullPath = dirname(__DIR__, 2) . '/public' . $item['file_path'];
            if (file_exists($fullPath)) {
                @unlink($fullPath);
            }
            $db->delete('media', 'id = ?', [$id]);
            AuditLog::log(Auth::id(), 'DELETE', 'media', $id, "Fayl o'chirildi: " . $item['file_name']);
        }

        $this->flashSuccess("Fayl o'chirildi.");
        return $this->redirect('/admin/media');
    }
}

