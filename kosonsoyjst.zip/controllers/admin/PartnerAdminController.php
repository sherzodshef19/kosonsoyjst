<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\AuditLog;
use Models\Partner;
use Services\UploadService;

class PartnerAdminController extends Controller
{
    public function index(): string
    {
        $m = new Partner();
        return $this->render('admin.partners.index', [
            'title' => 'Hamkor tashkilotlar',
            'partners' => $m->all('sort_order ASC, id ASC')
        ], 'layouts.admin');
    }

    public function store()
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'name' => 'required|min:2'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/partners');
        }

        $logoPath = null;
        if ($this->request->hasFile('logo')) {
            try {
                $logoPath = UploadService::uploadImage($this->request->file('logo'), 'partners');
            } catch (\Throwable $e) {}
        }

        $m = new Partner();
        $id = $m->create([
            'name' => trim((string)$data['name']),
            'logo' => $logoPath ?: '/assets/images/partner-default.png',
            'website_url' => trim((string)($data['website_url'] ?? '')),
            'description_uz' => trim((string)($data['description_uz'] ?? '')),
            'description_ru' => trim((string)($data['description_ru'] ?? '')),
            'description_en' => trim((string)($data['description_en'] ?? '')),
            'sort_order' => (int)($data['sort_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'CREATE', 'partners', $id, "Hamkor qo'shildi: " . $data['name']);
        $this->flashSuccess("Hamkor muvaffaqiyatli qo'shildi.");
        return $this->redirect('/admin/partners');
    }

    public function update(int $id)
    {
        $m = new Partner();
        $partner = $m->find($id);

        if (!$partner) {
            $this->flashError("Hamkor topilmadi.");
            return $this->redirect('/admin/partners');
        }

        $data = $this->request->all();
        $logoPath = $partner['logo'];

        if ($this->request->hasFile('logo')) {
            try {
                $logoPath = UploadService::uploadImage($this->request->file('logo'), 'partners');
            } catch (\Throwable $e) {}
        }

        $m->update($id, [
            'name' => trim((string)$data['name']),
            'logo' => $logoPath,
            'website_url' => trim((string)($data['website_url'] ?? '')),
            'description_uz' => trim((string)($data['description_uz'] ?? '')),
            'description_ru' => trim((string)($data['description_ru'] ?? '')),
            'description_en' => trim((string)($data['description_en'] ?? '')),
            'sort_order' => (int)($data['sort_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'UPDATE', 'partners', $id, "Hamkor yangilandi: " . $data['name']);
        $this->flashSuccess("Hamkor yangilandi.");
        return $this->redirect('/admin/partners');
    }

    public function delete(int $id)
    {
        $m = new Partner();
        $m->delete($id);
        AuditLog::log(Auth::id(), 'DELETE', 'partners', $id, "Hamkor o'chirildi");
        $this->flashSuccess("Hamkor o'chirildi.");
        return $this->redirect('/admin/partners');
    }
}

