<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\Session;
use Core\Database;
use Core\AuditLog;
use Services\UploadService;

class AuthController extends Controller
{
    public function showLogin(): string
    {
        if (Auth::check()) {
            $this->redirect('/admin');
        }

        return $this->render('admin.auth.login', [
            'title' => 'Tizimga kirish - Kosonsoy Kolleji Admin'
        ], null);
    }

    public function login()
    {
        $username = trim((string)$this->request->input('username'));
        $password = (string)$this->request->input('password');

        if (empty($username) || empty($password)) {
            $this->flashError("Foydalanuvchi nomi va parolni kiriting.");
            return $this->redirect('/admin/login');
        }

        if (Auth::attempt($username, $password)) {
            $this->flashSuccess("Xush kelibsiz, " . (Auth::user()['full_name'] ?? 'Administrator') . "!");
            return $this->redirect('/admin');
        }

        $this->flashError("Foydalanuvchi nomi yoki parol noto'g'ri.");
        return $this->redirect('/admin/login');
    }

    public function logout()
    {
        Auth::logout();
        $this->flashSuccess("Tizimdan muvaffaqiyatli chiqdingiz.");
        return $this->redirect('/admin/login');
    }

    public function profile(): string
    {
        return $this->render('admin.auth.profile', [
            'title' => 'Admin Profili',
            'user' => Auth::user()
        ], 'layouts.admin');
    }

    public function updateProfile()
    {
        $userId = Auth::id();
        $fullName = trim((string)$this->request->input('full_name'));
        $email = trim((string)$this->request->input('email'));
        $phone = trim((string)$this->request->input('phone'));

        $validator = $this->validate($this->request->all(), [
            'full_name' => 'required|min:3',
            'email' => "required|email|unique:users,email,{$userId}"
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/profile');
        }

        $data = [
            'full_name' => $fullName,
            'email' => $email,
            'phone' => $phone
        ];

        if ($this->request->hasFile('avatar')) {
            try {
                $data['avatar'] = UploadService::uploadImage($this->request->file('avatar'), 'avatars');
            } catch (\Throwable $e) {
                $this->flashError("Avatar yuklashda xato: " . $e->getMessage());
                return $this->redirect('/admin/profile');
            }
        }

        $db = Database::getInstance();
        $db->update('users', $data, 'id = ?', [$userId]);

        // Refresh user in session
        $updatedUser = $db->first("SELECT u.*, r.name as role_name, r.display_name as role_display FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?", [$userId]);
        unset($updatedUser['password']);
        Session::set('_auth_user', $updatedUser);

        AuditLog::log($userId, 'UPDATE_PROFILE', 'users', $userId, 'Profil ma\'lumotlari yangilandi');
        $this->flashSuccess("Profil ma'lumotlari muvaffaqiyatli yangilandi.");
        return $this->redirect('/admin/profile');
    }

    public function changePassword()
    {
        $userId = Auth::id();
        $oldPass = (string)$this->request->input('old_password');
        $newPass = (string)$this->request->input('new_password');
        $confirmPass = (string)$this->request->input('confirm_password');

        if (empty($oldPass) || empty($newPass)) {
            $this->flashError("Barcha parol maydonlarini to'ldiring.");
            return $this->redirect('/admin/profile');
        }

        if (strlen($newPass) < 6) {
            $this->flashError("Yangi parol kamida 6 ta belgidan iborat bo'lishi kerak.");
            return $this->redirect('/admin/profile');
        }

        if ($newPass !== $confirmPass) {
            $this->flashError("Yangi parol va tasdiqlovchi parol bir-biriga mos kelmadi.");
            return $this->redirect('/admin/profile');
        }

        $db = Database::getInstance();
        $user = $db->first("SELECT password FROM users WHERE id = ?", [$userId]);

        if (!password_verify($oldPass, $user['password'])) {
            $this->flashError("Amaldagi joriy parol noto'g'ri kiritildi.");
            return $this->redirect('/admin/profile');
        }

        $db->update('users', [
            'password' => password_hash($newPass, PASSWORD_BCRYPT)
        ], 'id = ?', [$userId]);

        AuditLog::log($userId, 'CHANGE_PASSWORD', 'users', $userId, 'Parol o\'zgartirildi');
        $this->flashSuccess("Parolingiz muvaffaqiyatli o'zgartirildi.");
        return $this->redirect('/admin/profile');
    }
}
