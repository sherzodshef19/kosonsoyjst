<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Database;

class DashboardController extends Controller
{
    public function index(): string
    {
        $db = Database::getInstance();

        $stats = [
            'news_count' => (int)$db->value("SELECT COUNT(*) FROM news WHERE is_deleted = 0"),
            'messages_count' => (int)$db->value("SELECT COUNT(*) FROM messages WHERE is_deleted = 0"),
            'messages_new' => (int)$db->value("SELECT COUNT(*) FROM messages WHERE status = 'NEW' AND is_deleted = 0"),
            'vacancies_count' => (int)$db->value("SELECT COUNT(*) FROM vacancies WHERE is_deleted = 0"),
            'applications_count' => (int)$db->value("SELECT COUNT(*) FROM vacancy_applications WHERE is_deleted = 0"),
            'applications_new' => (int)$db->value("SELECT COUNT(*) FROM vacancy_applications WHERE status = 'NEW' AND is_deleted = 0"),
            'users_count' => (int)$db->value("SELECT COUNT(*) FROM users"),
            'documents_count' => (int)$db->value("SELECT COUNT(*) FROM documents WHERE is_deleted = 0")
        ];

        // Recent messages
        $recentMessages = $db->query(
            "SELECT * FROM messages WHERE is_deleted = 0 ORDER BY id DESC LIMIT 5"
        );

        // Recent applications
        $recentApplications = $db->query(
            "SELECT a.*, v.title_uz as vacancy_title 
             FROM vacancy_applications a 
             JOIN vacancies v ON v.id = a.vacancy_id 
             WHERE a.is_deleted = 0 
             ORDER BY a.id DESC LIMIT 5"
        );

        // Recent news
        $recentNews = $db->query(
            "SELECT n.*, c.name_uz as cat_name 
             FROM news n 
             LEFT JOIN news_categories c ON c.id = n.category_id 
             WHERE n.is_deleted = 0 
             ORDER BY n.id DESC LIMIT 5"
        );

        // Recent audit logs
        $recentLogs = $db->query(
            "SELECT a.*, u.username, u.full_name 
             FROM audit_logs a 
             LEFT JOIN users u ON u.id = a.user_id 
             ORDER BY a.id DESC LIMIT 6"
        );

        return $this->render('admin.dashboard.index', [
            'title' => 'Boshqaruv paneli',
            'stats' => $stats,
            'recentMessages' => $recentMessages,
            'recentApplications' => $recentApplications,
            'recentNews' => $recentNews,
            'recentLogs' => $recentLogs
        ], 'layouts.admin');
    }
}

