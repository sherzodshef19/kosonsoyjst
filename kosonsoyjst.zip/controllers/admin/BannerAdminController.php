<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\AuditLog;
use Models\Banner;
use Services\UploadService;

class BannerAdminController extends Controller
{
    public function index(): string
    {
        $m = new Banner();
        return $this->render('admin.banners.index', [
            'title' => 'Bosh sahifa slayderi',
            'banners' => $m->where('1=1', [], 'sort_order ASC, id ASC')
        ], 'layouts.admin');
    }

    public function create(): string
    {
        return $this->render('admin.banners.form', [
            'title' => 'Yangi banner qo\'shish',
            'banner' => null
        ], 'layouts.admin');
    }

    public function store()
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'title_uz' => 'required|min:3'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/banners/create');
        }

        if (!$this->request->hasFile('image')) {
            $this->flashError("Banner rasmini yuklang.");
            return $this->redirect('/admin/banners/create');
        }

        try {
            $imagePath = UploadService::uploadImage($this->request->file('image'), 'banners');
        } catch (\Throwable $e) {
            $this->flashError("Rasm yuklashda xato: " . $e->getMessage());
            return $this->redirect('/admin/banners/create');
        }

        $m = new Banner();
        $id = $m->create([
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'subtitle_uz' => trim((string)($data['subtitle_uz'] ?? '')),
            'subtitle_ru' => trim((string)($data['subtitle_ru'] ?? '')),
            'subtitle_en' => trim((string)($data['subtitle_en'] ?? '')),
            'image' => $imagePath,
            'button_text_uz' => trim((string)($data['button_text_uz'] ?? '')),
            'button_text_ru' => trim((string)($data['button_text_ru'] ?? '')),
            'button_text_en' => trim((string)($data['button_text_en'] ?? '')),
            'button_url' => trim((string)($data['button_url'] ?? '')),
            'sort_order' => (int)($data['sort_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'CREATE', 'banners', $id, "Banner qo'shildi: " . $data['title_uz']);
        $this->flashSuccess("Banner muvaffaqiyatli saqlandi.");
        return $this->redirect('/admin/banners');
    }

    public function edit(int $id): string
    {
        $m = new Banner();
        $banner = $m->find($id);

        if (!$banner) {
            $this->flashError("Banner topilmadi.");
            return $this->redirect('/admin/banners');
        }

        return $this->render('admin.banners.form', [
            'title' => 'Bannerni tahrirlash',
            'banner' => $banner
        ], 'layouts.admin');
    }

    public function update(int $id)
    {
        $m = new Banner();
        $banner = $m->find($id);

        if (!$banner) {
            $this->flashError("Banner topilmadi.");
            return $this->redirect('/admin/banners');
        }

        $data = $this->request->all();
        $imagePath = $banner['image'];

        if ($this->request->hasFile('image')) {
            try {
                $imagePath = UploadService::uploadImage($this->request->file('image'), 'banners');
            } catch (\Throwable $e) {
                $this->flashError("Rasm yuklashda xato: " . $e->getMessage());
                return $this->redirect("/admin/banners/edit/{$id}");
            }
        }

        $m->update($id, [
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'subtitle_uz' => trim((string)($data['subtitle_uz'] ?? '')),
            'subtitle_ru' => trim((string)($data['subtitle_ru'] ?? '')),
            'subtitle_en' => trim((string)($data['subtitle_en'] ?? '')),
            'image' => $imagePath,
            'button_text_uz' => trim((string)($data['button_text_uz'] ?? '')),
            'button_text_ru' => trim((string)($data['button_text_ru'] ?? '')),
            'button_text_en' => trim((string)($data['button_text_en'] ?? '')),
            'button_url' => trim((string)($data['button_url'] ?? '')),
            'sort_order' => (int)($data['sort_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'UPDATE', 'banners', $id, "Banner yangilandi: " . $data['title_uz']);
        $this->flashSuccess("Banner muvaffaqiyatli yangilandi.");
        return $this->redirect('/admin/banners');
    }

    public function delete(int $id)
    {
        $m = new Banner();
        $m->delete($id);
        AuditLog::log(Auth::id(), 'DELETE', 'banners', $id, "Banner o'chirildi");
        $this->flashSuccess("Banner o'chirildi.");
        return $this->redirect('/admin/banners');
    }
}

