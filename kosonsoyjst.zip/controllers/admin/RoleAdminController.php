<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\AuditLog;
use Models\Role;
use Models\Permission;

class RoleAdminController extends Controller
{
    public function index(): string
    {
        $roleModel = new Role();
        $permModel = new Permission();

        $roles = $roleModel->all('id ASC');
        $groupedPerms = $permModel->groupedByModule();

        // For each role get array of its permission ids
        $rolePerms = [];
        foreach ($roles as $r) {
            $perms = $roleModel->permissions((int)$r['id']);
            $rolePerms[$r['id']] = array_column($perms, 'id');
        }

        return $this->render('admin.roles.index', [
            'title' => 'Rollar va ruxsatlar matritsasi',
            'roles' => $roles,
            'groupedPerms' => $groupedPerms,
            'rolePerms' => $rolePerms
        ], 'layouts.admin');
    }

    public function updatePermissions(int $roleId)
    {
        $permIds = $this->request->input('permissions', []);
        if (!is_array($permIds)) {
            $permIds = [];
        }

        $roleModel = new Role();
        $role = $roleModel->find($roleId);

        if (!$role) {
            $this->flashError("Rol topilmadi.");
            return $this->redirect('/admin/roles');
        }

        $roleModel->syncPermissions($roleId, $permIds);

        AuditLog::log(Auth::id(), 'UPDATE_PERMISSIONS', 'roles', $roleId, "Ruxsatlar yangilandi: " . $role['name']);
        $this->flashSuccess("{$role['display_name']} roli ruxsatlari muvaffaqiyatli saqlandi.");
        return $this->redirect('/admin/roles');
    }
}

