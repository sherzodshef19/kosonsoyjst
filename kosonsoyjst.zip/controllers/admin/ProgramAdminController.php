<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\AuditLog;
use Models\Program;

class ProgramAdminController extends Controller
{
    public function index(): string
    {
        $m = new Program();
        return $this->render('admin.programs.index', [
            'title' => "Ta'lim yo'nalishlari",
            'programs' => $m->all('sort_order ASC, id ASC')
        ], 'layouts.admin');
    }

    public function store()
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'title_uz' => 'required|min:2'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/programs');
        }

        $m = new Program();
        $id = $m->create([
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'description_uz' => trim((string)($data['description_uz'] ?? '')),
            'description_ru' => trim((string)($data['description_ru'] ?? '')),
            'description_en' => trim((string)($data['description_en'] ?? '')),
            'icon' => trim((string)($data['icon'] ?? 'bi-heart-pulse-fill')) ?: 'bi-heart-pulse-fill',
            'icon_color' => trim((string)($data['icon_color'] ?? 'primary')) ?: 'primary',
            'badge_category_uz' => trim((string)($data['badge_category_uz'] ?? 'Tibbiyot')),
            'badge_category_ru' => trim((string)($data['badge_category_ru'] ?? '')),
            'badge_category_en' => trim((string)($data['badge_category_en'] ?? '')),
            'duration_uz' => trim((string)($data['duration_uz'] ?? '3 yil')),
            'duration_ru' => trim((string)($data['duration_ru'] ?? '')),
            'duration_en' => trim((string)($data['duration_en'] ?? '')),
            'type_uz' => trim((string)($data['type_uz'] ?? 'Grant / Shartnoma')),
            'type_ru' => trim((string)($data['type_ru'] ?? '')),
            'type_en' => trim((string)($data['type_en'] ?? '')),
            'sort_order' => (int)($data['sort_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'CREATE', 'programs', $id, "Ta'lim yo'nalishi qo'shildi: " . $data['title_uz']);
        $this->flashSuccess("Ta'lim yo'nalishi muvaffaqiyatli qo'shildi.");
        return $this->redirect('/admin/programs');
    }

    public function update(int $id)
    {
        $m = new Program();
        $program = $m->find($id);

        if (!$program) {
            $this->flashError("Yo'nalish topilmadi.");
            return $this->redirect('/admin/programs');
        }

        $data = $this->request->all();
        $validator = $this->validate($data, [
            'title_uz' => 'required|min:2'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/programs');
        }

        $m->update($id, [
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'description_uz' => trim((string)($data['description_uz'] ?? '')),
            'description_ru' => trim((string)($data['description_ru'] ?? '')),
            'description_en' => trim((string)($data['description_en'] ?? '')),
            'icon' => trim((string)($data['icon'] ?? $program['icon'])),
            'icon_color' => trim((string)($data['icon_color'] ?? $program['icon_color'])),
            'badge_category_uz' => trim((string)($data['badge_category_uz'] ?? '')),
            'badge_category_ru' => trim((string)($data['badge_category_ru'] ?? '')),
            'badge_category_en' => trim((string)($data['badge_category_en'] ?? '')),
            'duration_uz' => trim((string)($data['duration_uz'] ?? '')),
            'duration_ru' => trim((string)($data['duration_ru'] ?? '')),
            'duration_en' => trim((string)($data['duration_en'] ?? '')),
            'type_uz' => trim((string)($data['type_uz'] ?? '')),
            'type_ru' => trim((string)($data['type_ru'] ?? '')),
            'type_en' => trim((string)($data['type_en'] ?? '')),
            'sort_order' => (int)($data['sort_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'UPDATE', 'programs', $id, "Ta'lim yo'nalishi tahrirlandi: " . $data['title_uz']);
        $this->flashSuccess("Yo'nalish ma'lumotlari yangilandi.");
        return $this->redirect('/admin/programs');
    }

    public function delete(int $id)
    {
        $m = new Program();
        $program = $m->find($id);

        if ($program) {
            $m->delete($id);
            AuditLog::log(Auth::id(), 'DELETE', 'programs', $id, "Ta'lim yo'nalishi o'chirildi: " . $program['title_uz']);
            $this->flashSuccess("Yo'nalish muvaffaqiyatli o'chirildi.");
        }

        return $this->redirect('/admin/programs');
    }

    public function toggle(int $id)
    {
        $m = new Program();
        $program = $m->find($id);

        if ($program) {
            $newStatus = $program['is_active'] ? 0 : 1;
            $m->update($id, ['is_active' => $newStatus]);
            $this->flashSuccess("Holat muvaffaqiyatli o'zgartirildi.");
        }

        return $this->redirect('/admin/programs');
    }
}

