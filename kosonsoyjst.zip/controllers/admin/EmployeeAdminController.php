<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\AuditLog;
use Models\Employee;
use Services\UploadService;

class EmployeeAdminController extends Controller
{
    public function index(): string
    {
        $empModel = new Employee();
        return $this->render('admin.employees.index', [
            'title' => 'Xodimlar va o\'qituvchilar',
            'employees' => $empModel->where('1=1', [], 'sort_order ASC, id ASC')
        ], 'layouts.admin');
    }

    public function create(): string
    {
        return $this->render('admin.employees.form', [
            'title' => 'Yangi o\'qituvchi / xodim qo\'shish',
            'employee' => null
        ], 'layouts.admin');
    }

    public function store()
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'full_name_uz' => 'required|min:3',
            'department_uz' => 'required',
            'specialty_uz' => 'required'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/employees/create');
        }

        $imagePath = null;
        if ($this->request->hasFile('image')) {
            try {
                $imagePath = UploadService::uploadImage($this->request->file('image'), 'employees');
            } catch (\Throwable $e) {
                $this->flashError("Rasm yuklashda xato: " . $e->getMessage());
                return $this->redirect('/admin/employees/create');
            }
        }

        $empModel = new Employee();
        $id = $empModel->create([
            'full_name_uz' => trim((string)$data['full_name_uz']),
            'full_name_ru' => trim((string)($data['full_name_ru'] ?? '')),
            'full_name_en' => trim((string)($data['full_name_en'] ?? '')),
            'department_uz' => trim((string)$data['department_uz']),
            'department_ru' => trim((string)($data['department_ru'] ?? '')),
            'department_en' => trim((string)($data['department_en'] ?? '')),
            'specialty_uz' => trim((string)$data['specialty_uz']),
            'specialty_ru' => trim((string)($data['specialty_ru'] ?? '')),
            'specialty_en' => trim((string)($data['specialty_en'] ?? '')),
            'degree_uz' => trim((string)($data['degree_uz'] ?? '')),
            'degree_ru' => trim((string)($data['degree_ru'] ?? '')),
            'degree_en' => trim((string)($data['degree_en'] ?? '')),
            'phone' => trim((string)($data['phone'] ?? '')),
            'email' => trim((string)($data['email'] ?? '')),
            'image' => $imagePath,
            'sort_order' => (int)($data['sort_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'CREATE', 'employees', $id, "O'qituvchi qo'shildi: " . $data['full_name_uz']);
        $this->flashSuccess("Xodim muvaffaqiyatli saqlandi.");
        return $this->redirect('/admin/employees');
    }

    public function edit(int $id): string
    {
        $empModel = new Employee();
        $employee = $empModel->find($id);

        if (!$employee) {
            $this->flashError("Xodim topilmadi.");
            return $this->redirect('/admin/employees');
        }

        return $this->render('admin.employees.form', [
            'title' => 'Xodim ma\'lumotlarini tahrirlash',
            'employee' => $employee
        ], 'layouts.admin');
    }

    public function update(int $id)
    {
        $empModel = new Employee();
        $employee = $empModel->find($id);

        if (!$employee) {
            $this->flashError("Xodim topilmadi.");
            return $this->redirect('/admin/employees');
        }

        $data = $this->request->all();
        $validator = $this->validate($data, [
            'full_name_uz' => 'required|min:3',
            'department_uz' => 'required',
            'specialty_uz' => 'required'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect("/admin/employees/edit/{$id}");
        }

        $imagePath = $employee['image'];
        if ($this->request->hasFile('image')) {
            try {
                $imagePath = UploadService::uploadImage($this->request->file('image'), 'employees');
            } catch (\Throwable $e) {
                $this->flashError("Rasm yuklashda xato: " . $e->getMessage());
                return $this->redirect("/admin/employees/edit/{$id}");
            }
        }

        $empModel->update($id, [
            'full_name_uz' => trim((string)$data['full_name_uz']),
            'full_name_ru' => trim((string)($data['full_name_ru'] ?? '')),
            'full_name_en' => trim((string)($data['full_name_en'] ?? '')),
            'department_uz' => trim((string)$data['department_uz']),
            'department_ru' => trim((string)($data['department_ru'] ?? '')),
            'department_en' => trim((string)($data['department_en'] ?? '')),
            'specialty_uz' => trim((string)$data['specialty_uz']),
            'specialty_ru' => trim((string)($data['specialty_ru'] ?? '')),
            'specialty_en' => trim((string)($data['specialty_en'] ?? '')),
            'degree_uz' => trim((string)($data['degree_uz'] ?? '')),
            'degree_ru' => trim((string)($data['degree_ru'] ?? '')),
            'degree_en' => trim((string)($data['degree_en'] ?? '')),
            'phone' => trim((string)($data['phone'] ?? '')),
            'email' => trim((string)($data['email'] ?? '')),
            'image' => $imagePath,
            'sort_order' => (int)($data['sort_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'UPDATE', 'employees', $id, "Xodim yangilandi: " . $data['full_name_uz']);
        $this->flashSuccess("Ma'lumotlar muvaffaqiyatli yangilandi.");
        return $this->redirect('/admin/employees');
    }

    public function delete(int $id)
    {
        $empModel = new Employee();
        $empModel->softDelete($id);
        AuditLog::log(Auth::id(), 'DELETE', 'employees', $id, "Xodim o'chirildi");
        $this->flashSuccess("Xodim o'chirildi.");
        return $this->redirect('/admin/employees');
    }
}

