<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\Database;
use Models\AuditLogModel;

class AuditLogAdminController extends Controller
{
    public function index(): string
    {
        $page = (int)$this->request->get('page', 1);
        $m = new AuditLogModel();
        $pagination = $m->paginateLogs($page, 20);

        return $this->render('admin.audit_logs.index', [
            'title' => 'Audit jurnali (Tizim harakatlari)',
            'logs' => $pagination['data'],
            'pagination' => $pagination
        ], 'layouts.admin');
    }

    public function clear()
    {
        if (Auth::role() !== 'SUPER_ADMIN') {
            $this->flashError("Faqat Bosh Administrator audit jurnalini tozalashi mumkin.");
            return $this->redirect('/admin/audit-logs');
        }

        $db = Database::getInstance();
        $db->execute("DELETE FROM audit_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");

        $this->flashSuccess("30 kundan eski audit loglar tozalandi.");
        return $this->redirect('/admin/audit-logs');
    }
}

