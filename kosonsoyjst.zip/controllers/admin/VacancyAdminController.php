<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\AuditLog;
use Models\Vacancy;

class VacancyAdminController extends Controller
{
    public function index(): string
    {
        $m = new Vacancy();
        return $this->render('admin.vacancies.index', [
            'title' => 'Vakansiyalar boshqaruvi',
            'vacancies' => $m->allActive()
        ], 'layouts.admin');
    }

    public function create(): string
    {
        return $this->render('admin.vacancies.form', [
            'title' => 'Yangi vakansiya yaratish',
            'vacancy' => null
        ], 'layouts.admin');
    }

    public function store()
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'title_uz' => 'required|min:3',
            'department_uz' => 'required',
            'requirements_uz' => 'required'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/vacancies/create');
        }

        $m = new Vacancy();
        $id = $m->create([
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'department_uz' => trim((string)$data['department_uz']),
            'department_ru' => trim((string)($data['department_ru'] ?? '')),
            'department_en' => trim((string)($data['department_en'] ?? '')),
            'employment_type' => in_array($data['employment_type'] ?? 'full_time', ['full_time', 'part_time', 'internship', 'contract'], true) ? $data['employment_type'] : 'full_time',
            'salary_text' => trim((string)($data['salary_text'] ?? 'Suhbat asosida')),
            'deadline_date' => !empty($data['deadline_date']) ? $data['deadline_date'] : null,
            'requirements_uz' => (string)$data['requirements_uz'],
            'requirements_ru' => (string)($data['requirements_ru'] ?? ''),
            'requirements_en' => (string)($data['requirements_en'] ?? ''),
            'responsibilities_uz' => (string)($data['responsibilities_uz'] ?? ''),
            'responsibilities_ru' => (string)($data['responsibilities_ru'] ?? ''),
            'responsibilities_en' => (string)($data['responsibilities_en'] ?? ''),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'CREATE', 'vacancies', $id, "Vakansiya yaratildi: " . $data['title_uz']);
        $this->flashSuccess("Vakansiya muvaffaqiyatli e'lon qilindi.");
        return $this->redirect('/admin/vacancies');
    }

    public function edit(int $id): string
    {
        $m = new Vacancy();
        $item = $m->find($id);

        if (!$item) {
            $this->flashError("Vakansiya topilmadi.");
            return $this->redirect('/admin/vacancies');
        }

        return $this->render('admin.vacancies.form', [
            'title' => 'Vakansiyani tahrirlash',
            'vacancy' => $item
        ], 'layouts.admin');
    }

    public function update(int $id)
    {
        $m = new Vacancy();
        $item = $m->find($id);

        if (!$item) {
            $this->flashError("Vakansiya topilmadi.");
            return $this->redirect('/admin/vacancies');
        }

        $data = $this->request->all();
        $validator = $this->validate($data, [
            'title_uz' => 'required|min:3',
            'department_uz' => 'required',
            'requirements_uz' => 'required'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect("/admin/vacancies/edit/{$id}");
        }

        $m->update($id, [
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'department_uz' => trim((string)$data['department_uz']),
            'department_ru' => trim((string)($data['department_ru'] ?? '')),
            'department_en' => trim((string)($data['department_en'] ?? '')),
            'employment_type' => in_array($data['employment_type'] ?? 'full_time', ['full_time', 'part_time', 'internship', 'contract'], true) ? $data['employment_type'] : 'full_time',
            'salary_text' => trim((string)($data['salary_text'] ?? 'Suhbat asosida')),
            'deadline_date' => !empty($data['deadline_date']) ? $data['deadline_date'] : null,
            'requirements_uz' => (string)$data['requirements_uz'],
            'requirements_ru' => (string)($data['requirements_ru'] ?? ''),
            'requirements_en' => (string)($data['requirements_en'] ?? ''),
            'responsibilities_uz' => (string)($data['responsibilities_uz'] ?? ''),
            'responsibilities_ru' => (string)($data['responsibilities_ru'] ?? ''),
            'responsibilities_en' => (string)($data['responsibilities_en'] ?? ''),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'UPDATE', 'vacancies', $id, "Vakansiya yangilandi: " . $data['title_uz']);
        $this->flashSuccess("Vakansiya muvaffaqiyatli yangilandi.");
        return $this->redirect('/admin/vacancies');
    }

    public function delete(int $id)
    {
        $m = new Vacancy();
        $m->softDelete($id);
        AuditLog::log(Auth::id(), 'DELETE', 'vacancies', $id, "Vakansiya o'chirildi");
        $this->flashSuccess("Vakansiya o'chirildi.");
        return $this->redirect('/admin/vacancies');
    }
}

