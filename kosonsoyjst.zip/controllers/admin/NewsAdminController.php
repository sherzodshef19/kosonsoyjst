<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\Database;
use Core\AuditLog;
use Models\News;
use Models\Category;
use Services\UploadService;

class NewsAdminController extends Controller
{
    public function index(): string
    {
        $page = (int)$this->request->get('page', 1);
        $search = $this->request->get('q');
        $catId = $this->request->get('category_id') ? (int)$this->request->get('category_id') : null;
        $status = $this->request->get('status');

        $newsModel = new News();
        $catModel = new Category();

        $pagination = $newsModel->paginateWithDetails($page, 10, $catId, $search, $status);
        $categories = $catModel->all();

        return $this->render('admin.news.index', [
            'title' => 'Yangiliklar boshqaruvi',
            'news' => $pagination['data'],
            'pagination' => $pagination,
            'categories' => $categories,
            'search' => $search,
            'currentCat' => $catId,
            'currentStatus' => $status
        ], 'layouts.admin');
    }

    public function create(): string
    {
        $catModel = new Category();
        $db = Database::getInstance();
        $tags = $db->query("SELECT * FROM news_tags ORDER BY name_uz ASC");

        return $this->render('admin.news.form', [
            'title' => 'Yangi yangilik qo\'shish',
            'categories' => $catModel->all(),
            'tags' => $tags,
            'news' => null,
            'newsTags' => []
        ], 'layouts.admin');
    }

    public function store()
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'title_uz' => 'required|min:5|max:255',
            'category_id' => 'required|numeric',
            'content_uz' => 'required|min:10'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/news/create');
        }

        $imagePath = null;
        if ($this->request->hasFile('image')) {
            try {
                $imagePath = UploadService::uploadImage($this->request->file('image'), 'news');
            } catch (\Throwable $e) {
                $this->flashError("Rasm yuklashda xato: " . $e->getMessage());
                return $this->redirect('/admin/news/create');
            }
        }

        $slug = !empty($data['slug']) ? slugify($data['slug']) : slugify($data['title_uz']);
        // Ensure slug unique
        $db = Database::getInstance();
        $existing = $db->first("SELECT id FROM news WHERE slug = ?", [$slug]);
        if ($existing) {
            $slug .= '-' . time();
        }

        $newsModel = new News();
        $insertData = [
            'category_id' => (int)$data['category_id'],
            'author_id' => Auth::id(),
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'slug' => $slug,
            'summary_uz' => trim((string)($data['summary_uz'] ?? '')),
            'summary_ru' => trim((string)($data['summary_ru'] ?? '')),
            'summary_en' => trim((string)($data['summary_en'] ?? '')),
            'content_uz' => (string)$data['content_uz'],
            'content_ru' => (string)($data['content_ru'] ?? ''),
            'content_en' => (string)($data['content_en'] ?? ''),
            'image' => $imagePath,
            'is_featured' => isset($data['is_featured']) ? 1 : 0,
            'is_announcement' => isset($data['is_announcement']) ? 1 : 0,
            'status' => in_array($data['status'] ?? 'published', ['published', 'draft', 'archived'], true) ? $data['status'] : 'published',
            'meta_title' => trim((string)($data['meta_title'] ?? '')),
            'meta_description' => trim((string)($data['meta_description'] ?? '')),
            'published_at' => !empty($data['published_at']) ? $data['published_at'] : date('Y-m-d H:i:s')
        ];

        $newsId = $newsModel->create($insertData);

        // Tags
        if (!empty($data['tags']) && is_array($data['tags'])) {
            $newsModel->syncTags($newsId, $data['tags']);
        }

        // Multi gallery images
        if (isset($_FILES['gallery_images']) && !empty($_FILES['gallery_images']['name'][0])) {
            $uploadedGallery = [];
            $files = $_FILES['gallery_images'];
            for ($i = 0; $i < count($files['name']); $i++) {
                if ($files['error'][$i] === UPLOAD_ERR_OK) {
                    $singleFile = [
                        'name' => $files['name'][$i],
                        'type' => $files['type'][$i],
                        'tmp_name' => $files['tmp_name'][$i],
                        'error' => $files['error'][$i],
                        'size' => $files['size'][$i]
                    ];
                    try {
                        $uploadedGallery[] = UploadService::uploadImage($singleFile, 'news');
                    } catch (\Throwable $e) {}
                }
            }
            if (!empty($uploadedGallery)) {
                $newsModel->saveGalleryImages($newsId, $uploadedGallery);
            }
        }

        AuditLog::log(Auth::id(), 'CREATE', 'news', $newsId, "Yangilik qo'shildi: " . $insertData['title_uz']);
        $this->flashSuccess("Yangilik muvaffaqiyatli saqlandi.");
        return $this->redirect('/admin/news');
    }

    public function edit(int $id): string
    {
        $newsModel = new News();
        $news = $newsModel->find($id);

        if (!$news) {
            $this->flashError("Yangilik topilmadi.");
            $this->redirect('/admin/news');
        }

        $catModel = new Category();
        $db = Database::getInstance();
        $tags = $db->query("SELECT * FROM news_tags ORDER BY name_uz ASC");
        $newsTags = array_column($newsModel->getTags($id), 'id');
        $gallery = $newsModel->getGallery($id);

        return $this->render('admin.news.form', [
            'title' => 'Yangilikni tahrirlash',
            'categories' => $catModel->all(),
            'tags' => $tags,
            'news' => $news,
            'newsTags' => $newsTags,
            'gallery' => $gallery
        ], 'layouts.admin');
    }

    public function update(int $id)
    {
        $newsModel = new News();
        $news = $newsModel->find($id);

        if (!$news) {
            $this->flashError("Yangilik topilmadi.");
            return $this->redirect('/admin/news');
        }

        $data = $this->request->all();
        $validator = $this->validate($data, [
            'title_uz' => 'required|min:5|max:255',
            'category_id' => 'required|numeric',
            'content_uz' => 'required|min:10'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect("/admin/news/edit/{$id}");
        }

        $imagePath = $news['image'];
        if ($this->request->hasFile('image')) {
            try {
                $imagePath = UploadService::uploadImage($this->request->file('image'), 'news');
            } catch (\Throwable $e) {
                $this->flashError("Rasm yuklashda xato: " . $e->getMessage());
                return $this->redirect("/admin/news/edit/{$id}");
            }
        }

        $slug = !empty($data['slug']) ? slugify($data['slug']) : slugify($data['title_uz']);
        $db = Database::getInstance();
        $existing = $db->first("SELECT id FROM news WHERE slug = ? AND id != ?", [$slug, $id]);
        if ($existing) {
            $slug .= '-' . time();
        }

        $updateData = [
            'category_id' => (int)$data['category_id'],
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'slug' => $slug,
            'summary_uz' => trim((string)($data['summary_uz'] ?? '')),
            'summary_ru' => trim((string)($data['summary_ru'] ?? '')),
            'summary_en' => trim((string)($data['summary_en'] ?? '')),
            'content_uz' => (string)$data['content_uz'],
            'content_ru' => (string)($data['content_ru'] ?? ''),
            'content_en' => (string)($data['content_en'] ?? ''),
            'image' => $imagePath,
            'is_featured' => isset($data['is_featured']) ? 1 : 0,
            'is_announcement' => isset($data['is_announcement']) ? 1 : 0,
            'status' => in_array($data['status'] ?? 'published', ['published', 'draft', 'archived'], true) ? $data['status'] : 'published',
            'meta_title' => trim((string)($data['meta_title'] ?? '')),
            'meta_description' => trim((string)($data['meta_description'] ?? '')),
            'published_at' => !empty($data['published_at']) ? $data['published_at'] : $news['published_at']
        ];

        $newsModel->update($id, $updateData);

        // Tags
        $tagIds = isset($data['tags']) && is_array($data['tags']) ? $data['tags'] : [];
        $newsModel->syncTags($id, $tagIds);

        // Gallery uploads
        if (isset($_FILES['gallery_images']) && !empty($_FILES['gallery_images']['name'][0])) {
            $uploadedGallery = [];
            $files = $_FILES['gallery_images'];
            for ($i = 0; $i < count($files['name']); $i++) {
                if ($files['error'][$i] === UPLOAD_ERR_OK) {
                    $singleFile = [
                        'name' => $files['name'][$i],
                        'type' => $files['type'][$i],
                        'tmp_name' => $files['tmp_name'][$i],
                        'error' => $files['error'][$i],
                        'size' => $files['size'][$i]
                    ];
                    try {
                        $uploadedGallery[] = UploadService::uploadImage($singleFile, 'news');
                    } catch (\Throwable $e) {}
                }
            }
            if (!empty($uploadedGallery)) {
                $newsModel->saveGalleryImages($id, $uploadedGallery);
            }
        }

        AuditLog::log(Auth::id(), 'UPDATE', 'news', $id, "Yangilik yangilandi: " . $updateData['title_uz']);
        $this->flashSuccess("Yangilik muvaffaqiyatli yangilandi.");
        return $this->redirect('/admin/news');
    }

    public function delete(int $id)
    {
        $newsModel = new News();
        $newsModel->softDelete($id);
        AuditLog::log(Auth::id(), 'DELETE', 'news', $id, "Yangilik o'chirildi (soft delete)");
        $this->flashSuccess("Yangilik o'chirildi.");
        return $this->redirect('/admin/news');
    }

    public function deleteGalleryImage(int $id)
    {
        $db = Database::getInstance();
        $db->delete('news_gallery', 'id = ?', [$id]);
        return $this->back();
    }
}

