<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\AuditLog;
use Models\Document;
use Services\UploadService;

class DocumentAdminController extends Controller
{
    public function index(): string
    {
        $m = new Document();
        return $this->render('admin.documents.index', [
            'title' => 'Rasmiy hujjatlar boshqaruvi',
            'documents' => $m->where('1=1', [], 'doc_date DESC, id DESC')
        ], 'layouts.admin');
    }

    public function create(): string
    {
        return $this->render('admin.documents.form', [
            'title' => 'Yangi hujjat yuklash',
            'doc' => null
        ], 'layouts.admin');
    }

    public function store()
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'title_uz' => 'required|min:3',
            'category' => 'required'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/documents/create');
        }

        if (!$this->request->hasFile('file')) {
            $this->flashError("Hujjat faylini yuklang (PDF, DOCX).");
            return $this->redirect('/admin/documents/create');
        }

        try {
            $filePath = UploadService::uploadDocument($this->request->file('file'), 'documents');
            $fileSize = round($this->request->file('file')['size'] / 1048576, 2) . ' MB';
            if ($this->request->file('file')['size'] < 1048576) {
                $fileSize = round($this->request->file('file')['size'] / 1024, 1) . ' KB';
            }
        } catch (\Throwable $e) {
            $this->flashError("Fayl yuklashda xato: " . $e->getMessage());
            return $this->redirect('/admin/documents/create');
        }

        $m = new Document();
        $id = $m->create([
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'doc_number' => trim((string)($data['doc_number'] ?? '')),
            'doc_date' => !empty($data['doc_date']) ? $data['doc_date'] : null,
            'category' => $data['category'],
            'file_path' => $filePath,
            'file_size' => $fileSize,
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'CREATE', 'documents', $id, "Hujjat yuklandi: " . $data['title_uz']);
        $this->flashSuccess("Hujjat muvaffaqiyatli saqlandi.");
        return $this->redirect('/admin/documents');
    }

    public function edit(int $id): string
    {
        $m = new Document();
        $doc = $m->find($id);

        if (!$doc) {
            $this->flashError("Hujjat topilmadi.");
            return $this->redirect('/admin/documents');
        }

        return $this->render('admin.documents.form', [
            'title' => 'Hujjatni tahrirlash',
            'doc' => $doc
        ], 'layouts.admin');
    }

    public function update(int $id)
    {
        $m = new Document();
        $doc = $m->find($id);

        if (!$doc) {
            $this->flashError("Hujjat topilmadi.");
            return $this->redirect('/admin/documents');
        }

        $data = $this->request->all();
        $filePath = $doc['file_path'];
        $fileSize = $doc['file_size'];

        if ($this->request->hasFile('file')) {
            try {
                $filePath = UploadService::uploadDocument($this->request->file('file'), 'documents');
                $sizeInBytes = $this->request->file('file')['size'];
                $fileSize = $sizeInBytes > 1048576 ? round($sizeInBytes / 1048576, 2) . ' MB' : round($sizeInBytes / 1024, 1) . ' KB';
            } catch (\Throwable $e) {
                $this->flashError("Fayl yuklashda xato: " . $e->getMessage());
                return $this->redirect("/admin/documents/edit/{$id}");
            }
        }

        $m->update($id, [
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'doc_number' => trim((string)($data['doc_number'] ?? '')),
            'doc_date' => !empty($data['doc_date']) ? $data['doc_date'] : null,
            'category' => $data['category'] ?? $doc['category'],
            'file_path' => $filePath,
            'file_size' => $fileSize,
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'UPDATE', 'documents', $id, "Hujjat yangilandi: " . $data['title_uz']);
        $this->flashSuccess("Hujjat yangilandi.");
        return $this->redirect('/admin/documents');
    }

    public function delete(int $id)
    {
        $m = new Document();
        $m->softDelete($id);
        AuditLog::log(Auth::id(), 'DELETE', 'documents', $id, "Hujjat o'chirildi");
        $this->flashSuccess("Hujjat o'chirildi.");
        return $this->redirect('/admin/documents');
    }
}

