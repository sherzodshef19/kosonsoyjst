<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\AuditLog;
use Models\Setting;
use Services\UploadService;
use Services\TelegramService;

class SettingAdminController extends Controller
{
    public function index(): string
    {
        $settingModel = new Setting();
        return $this->render('admin.settings.index', [
            'title' => 'Sayt sozlamalari',
            'settings' => $settingModel->allAssoc()
        ], 'layouts.admin');
    }

    public function update()
    {
        $data = $this->request->all();
        $settingModel = new Setting();

        $allowedKeys = [
            'site_name', 'site_tagline', 'site_phone', 'site_hotline', 'site_email',
            'site_address', 'working_hours', 'telegram_channel', 'instagram_url',
            'facebook_url', 'youtube_url', 'telegram_bot_token', 'telegram_chat_id',
            'telegram_notifications_enabled', 'meta_title_default', 'meta_desc_default',
            'meta_keywords_default', 'maintenance_mode', 'director_quote_uz',
            'director_quote_ru', 'director_quote_en', 'director_name', 'director_title',
            'google_maps_iframe'
        ];

        foreach ($allowedKeys as $key) {
            if (isset($data[$key])) {
                $val = trim((string)$data[$key]);
                if ($key === 'google_maps_iframe') {
                    // Extract src if full <iframe ... src="..." ...> HTML snippet was entered
                    if (preg_match('/src=["\']([^"\']+)["\']/i', $val, $match)) {
                        $val = $match[1];
                    }
                }
                $settingModel->set($key, $val);
            }
        }

        // Handle Site Logo / Favicon uploads
        if ($this->request->hasFile('site_logo')) {
            try {
                $logo = UploadService::uploadImage($this->request->file('site_logo'), 'branding');
                $settingModel->set('site_logo', $logo);
            } catch (\Throwable $e) {}
        }

        if ($this->request->hasFile('site_favicon')) {
            try {
                $favicon = UploadService::uploadImage($this->request->file('site_favicon'), 'branding');
                $settingModel->set('site_favicon', $favicon);
            } catch (\Throwable $e) {}
        }

        AuditLog::log(Auth::id(), 'UPDATE_SETTINGS', 'settings', null, "Sayt sozlamalari yangilandi");
        $this->flashSuccess("Sozlamalar muvaffaqiyatli saqlandi.");
        return $this->redirect('/admin/settings');
    }

    public function testTelegram()
    {
        $testMsg = "✅ <b>Kosonsoy Kolleji</b>\nTelegram Bot integratsiyasi muvaffaqiyatli sinovdan o'tkazildi!\nVaqt: " . date('Y-m-d H:i:s');
        $sent = TelegramService::send($testMsg);

        if ($sent) {
            $this->flashSuccess("Sinov xabari Telegram orqali muvaffaqiyatli yuborildi!");
        } else {
            $this->flashError("Telegram xabari yuborilmadi. Bot tokeni va Chat ID ni tekshiring yoki bildirishnomalarni yoqing.");
        }

        return $this->redirect('/admin/settings');
    }
}

