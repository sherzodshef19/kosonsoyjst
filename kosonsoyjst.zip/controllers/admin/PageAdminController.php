<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\AuditLog;
use Models\Page;
use Services\UploadService;

class PageAdminController extends Controller
{
    public function index(): string
    {
        $m = new Page();
        return $this->render('admin.pages.index', [
            'title' => 'Sayt sahifalari boshqaruvi',
            'pages' => $m->where('1=1', [], 'id DESC')
        ], 'layouts.admin');
    }

    public function create(): string
    {
        return $this->render('admin.pages.form', [
            'title' => 'Yangi sahifa yaratish',
            'page' => null
        ], 'layouts.admin');
    }

    public function store()
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'title_uz' => 'required|min:3',
            'content_uz' => 'required'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/pages/create');
        }

        $bannerPath = null;
        if ($this->request->hasFile('banner_image')) {
            try {
                $bannerPath = UploadService::uploadImage($this->request->file('banner_image'), 'pages');
            } catch (\Throwable $e) {}
        }

        $slug = !empty($data['slug']) ? slugify($data['slug']) : slugify($data['title_uz']);
        $m = new Page();
        $id = $m->create([
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'slug' => $slug,
            'content_uz' => (string)$data['content_uz'],
            'content_ru' => (string)($data['content_ru'] ?? ''),
            'content_en' => (string)($data['content_en'] ?? ''),
            'banner_image' => $bannerPath,
            'meta_title' => trim((string)($data['meta_title'] ?? '')),
            'meta_description' => trim((string)($data['meta_description'] ?? '')),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'CREATE', 'pages', $id, "Sahifa yaratildi: " . $data['title_uz']);
        $this->flashSuccess("Sahifa muvaffaqiyatli saqlandi.");
        return $this->redirect('/admin/pages');
    }

    public function edit(int $id): string
    {
        $m = new Page();
        $page = $m->find($id);

        if (!$page) {
            $this->flashError("Sahifa topilmadi.");
            return $this->redirect('/admin/pages');
        }

        return $this->render('admin.pages.form', [
            'title' => 'Sahifani tahrirlash',
            'page' => $page
        ], 'layouts.admin');
    }

    public function update(int $id)
    {
        $m = new Page();
        $page = $m->find($id);

        if (!$page) {
            $this->flashError("Sahifa topilmadi.");
            return $this->redirect('/admin/pages');
        }

        $data = $this->request->all();
        $validator = $this->validate($data, [
            'title_uz' => 'required|min:3',
            'content_uz' => 'required'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect("/admin/pages/edit/{$id}");
        }

        $bannerPath = $page['banner_image'];
        if ($this->request->hasFile('banner_image')) {
            try {
                $bannerPath = UploadService::uploadImage($this->request->file('banner_image'), 'pages');
            } catch (\Throwable $e) {}
        }

        $slug = !empty($data['slug']) ? slugify($data['slug']) : slugify($data['title_uz']);

        $m->update($id, [
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'slug' => $slug,
            'content_uz' => (string)$data['content_uz'],
            'content_ru' => (string)($data['content_ru'] ?? ''),
            'content_en' => (string)($data['content_en'] ?? ''),
            'banner_image' => $bannerPath,
            'meta_title' => trim((string)($data['meta_title'] ?? '')),
            'meta_description' => trim((string)($data['meta_description'] ?? '')),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'UPDATE', 'pages', $id, "Sahifa yangilandi: " . $data['title_uz']);
        $this->flashSuccess("Sahifa muvaffaqiyatli yangilandi.");
        return $this->redirect('/admin/pages');
    }

    public function delete(int $id)
    {
        $m = new Page();
        $m->softDelete($id);
        AuditLog::log(Auth::id(), 'DELETE', 'pages', $id, "Sahifa o'chirildi");
        $this->flashSuccess("Sahifa o'chirildi.");
        return $this->redirect('/admin/pages');
    }
}

