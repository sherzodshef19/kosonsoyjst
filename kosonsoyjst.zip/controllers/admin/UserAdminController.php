<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\AuditLog;
use Models\User;
use Models\Role;

class UserAdminController extends Controller
{
    public function index(): string
    {
        $userModel = new User();
        $roleModel = new Role();

        return $this->render('admin.users.index', [
            'title' => 'Foydalanuvchilar boshqaruvi',
            'users' => $userModel->allWithRole(),
            'roles' => $roleModel->all()
        ], 'layouts.admin');
    }

    public function store()
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'username' => 'required|min:3|unique:users,username',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6',
            'full_name' => 'required|min:3',
            'role_id' => 'required|numeric'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/users');
        }

        $userModel = new User();
        $id = $userModel->create([
            'role_id' => (int)$data['role_id'],
            'username' => trim((string)$data['username']),
            'email' => trim((string)$data['email']),
            'password' => password_hash((string)$data['password'], PASSWORD_BCRYPT),
            'full_name' => trim((string)$data['full_name']),
            'phone' => trim((string)($data['phone'] ?? '')),
            'status' => $data['status'] ?? 'active'
        ]);

        AuditLog::log(Auth::id(), 'CREATE', 'users', $id, "Foydalanuvchi yaratildi: " . $data['username']);
        $this->flashSuccess("Yangi foydalanuvchi muvaffaqiyatli yaratildi.");
        return $this->redirect('/admin/users');
    }

    public function update(int $id)
    {
        $userModel = new User();
        $user = $userModel->find($id);

        if (!$user) {
            $this->flashError("Foydalanuvchi topilmadi.");
            return $this->redirect('/admin/users');
        }

        $data = $this->request->all();
        $validator = $this->validate($data, [
            'username' => "required|min:3|unique:users,username,{$id}",
            'email' => "required|email|unique:users,email,{$id}",
            'full_name' => 'required|min:3',
            'role_id' => 'required|numeric'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/users');
        }

        $updateData = [
            'role_id' => (int)$data['role_id'],
            'username' => trim((string)$data['username']),
            'email' => trim((string)$data['email']),
            'full_name' => trim((string)$data['full_name']),
            'phone' => trim((string)($data['phone'] ?? '')),
            'status' => $data['status'] ?? 'active'
        ];

        if (!empty($data['password'])) {
            $updateData['password'] = password_hash((string)$data['password'], PASSWORD_BCRYPT);
        }

        $userModel->update($id, $updateData);

        AuditLog::log(Auth::id(), 'UPDATE', 'users', $id, "Foydalanuvchi yangilandi: " . $data['username']);
        $this->flashSuccess("Foydalanuvchi ma'lumotlari yangilandi.");
        return $this->redirect('/admin/users');
    }

    public function delete(int $id)
    {
        if ($id === Auth::id()) {
            $this->flashError("O'z hisobingizni o'chira olmaysiz!");
            return $this->redirect('/admin/users');
        }

        $userModel = new User();
        $userModel->delete($id);
        AuditLog::log(Auth::id(), 'DELETE', 'users', $id, "Foydalanuvchi o'chirildi");
        $this->flashSuccess("Foydalanuvchi o'chirildi.");
        return $this->redirect('/admin/users');
    }
}

