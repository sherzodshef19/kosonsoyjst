<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\AuditLog;
use Models\Category;

class CategoryAdminController extends Controller
{
    public function index(): string
    {
        $catModel = new Category();
        return $this->render('admin.categories.index', [
            'title' => 'Yangilik kategoriyalari',
            'categories' => $catModel->allWithCount()
        ], 'layouts.admin');
    }

    public function store()
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'name_uz' => 'required|min:2|max:150'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/categories');
        }

        $slug = !empty($data['slug']) ? slugify($data['slug']) : slugify($data['name_uz']);
        $catModel = new Category();

        $id = $catModel->create([
            'name_uz' => trim((string)$data['name_uz']),
            'name_ru' => trim((string)($data['name_ru'] ?? '')),
            'name_en' => trim((string)($data['name_en'] ?? '')),
            'slug' => $slug,
            'description' => trim((string)($data['description'] ?? '')),
            'sort_order' => (int)($data['sort_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'CREATE', 'categories', $id, "Kategoriya qo'shildi: " . $data['name_uz']);
        $this->flashSuccess("Kategoriya muvaffaqiyatli qo'shildi.");
        return $this->redirect('/admin/categories');
    }

    public function update(int $id)
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'name_uz' => 'required|min:2|max:150'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/categories');
        }

        $slug = !empty($data['slug']) ? slugify($data['slug']) : slugify($data['name_uz']);
        $catModel = new Category();

        $catModel->update($id, [
            'name_uz' => trim((string)$data['name_uz']),
            'name_ru' => trim((string)($data['name_ru'] ?? '')),
            'name_en' => trim((string)($data['name_en'] ?? '')),
            'slug' => $slug,
            'description' => trim((string)($data['description'] ?? '')),
            'sort_order' => (int)($data['sort_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'UPDATE', 'categories', $id, "Kategoriya yangilandi: " . $data['name_uz']);
        $this->flashSuccess("Kategoriya muvaffaqiyatli yangilandi.");
        return $this->redirect('/admin/categories');
    }

    public function delete(int $id)
    {
        $catModel = new Category();
        $catModel->delete($id);
        AuditLog::log(Auth::id(), 'DELETE', 'categories', $id, "Kategoriya o'chirildi");
        $this->flashSuccess("Kategoriya o'chirildi.");
        return $this->redirect('/admin/categories');
    }
}

