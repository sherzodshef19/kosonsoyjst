<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\AuditLog;
use Models\Statistic;

class StatisticAdminController extends Controller
{
    public function index(): string
    {
        $m = new Statistic();
        return $this->render('admin.statistics.index', [
            'title' => 'Statistika ko\'rsatkichlari',
            'statistics' => $m->all('sort_order ASC, id ASC')
        ], 'layouts.admin');
    }

    public function store()
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'title_uz' => 'required',
            'count_value' => 'required|numeric'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/statistics');
        }

        $m = new Statistic();
        $id = $m->create([
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'count_value' => (int)$data['count_value'],
            'suffix' => trim((string)($data['suffix'] ?? '+')),
            'icon' => trim((string)($data['icon'] ?? 'bi-mortarboard')),
            'sort_order' => (int)($data['sort_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'CREATE', 'statistics', $id, "Statistika ko'rsatkichi qo'shildi");
        $this->flashSuccess("Statistika ko'rsatkichi qo'shildi.");
        return $this->redirect('/admin/statistics');
    }

    public function update(int $id)
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'title_uz' => 'required',
            'count_value' => 'required|numeric'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/statistics');
        }

        $m = new Statistic();
        $m->update($id, [
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'count_value' => (int)$data['count_value'],
            'suffix' => trim((string)($data['suffix'] ?? '+')),
            'icon' => trim((string)($data['icon'] ?? 'bi-mortarboard')),
            'sort_order' => (int)($data['sort_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'UPDATE', 'statistics', $id, "Statistika ko'rsatkichi yangilandi");
        $this->flashSuccess("Ko'rsatkich muvaffaqiyatli yangilandi.");
        return $this->redirect('/admin/statistics');
    }

    public function delete(int $id)
    {
        $m = new Statistic();
        $m->delete($id);
        AuditLog::log(Auth::id(), 'DELETE', 'statistics', $id, "Statistika o'chirildi");
        $this->flashSuccess("Ko'rsatkich o'chirildi.");
        return $this->redirect('/admin/statistics');
    }
}

