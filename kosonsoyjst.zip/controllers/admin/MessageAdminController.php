<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\AuditLog;
use Models\Message;
use Services\UploadService;

class MessageAdminController extends Controller
{
    public function index(): string
    {
        $status = $this->request->get('status');
        $type = $this->request->get('type');
        $search = $this->request->get('q');

        $where = ["is_deleted = 0"];
        $params = [];

        if (!empty($status)) {
            $where[] = "status = ?";
            $params[] = $status;
        }

        if (!empty($type)) {
            $where[] = "inquiry_type = ?";
            $params[] = $type;
        }

        if (!empty($search)) {
            $where[] = "(tracking_code LIKE ? OR full_name LIKE ? OR phone LIKE ? OR subject LIKE ?)";
            $term = "%{$search}%";
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
        }

        $messageModel = new Message();
        $messages = $messageModel->where(implode(' AND ', $where), $params, 'id DESC');

        return $this->render('admin.messages.index', [
            'title' => 'Virtual qabulxona murojaatlari',
            'messages' => $messages,
            'currentStatus' => $status,
            'currentType' => $type,
            'search' => $search
        ], 'layouts.admin');
    }

    public function show(int $id): string
    {
        $messageModel = new Message();
        $message = $messageModel->find($id);

        if (!$message) {
            $this->flashError("Murojaat topilmadi.");
            return $this->redirect('/admin/messages');
        }

        $fullData = $messageModel->findByTrackingCode($message['tracking_code']);

        return $this->render('admin.messages.show', [
            'title' => 'Murojaat: ' . $message['tracking_code'],
            'message' => $fullData
        ], 'layouts.admin');
    }

    public function reply(int $id)
    {
        $replyText = trim((string)$this->request->input('reply_text'));
        if (empty($replyText)) {
            $this->flashError("Javob matnini kiriting.");
            return $this->redirect("/admin/messages/{$id}");
        }

        $replyFile = null;
        if ($this->request->hasFile('reply_file')) {
            try {
                $replyFile = UploadService::uploadDocument($this->request->file('reply_file'), 'reception');
            } catch (\Throwable $e) {
                $this->flashError("Fayl yuklashda xato: " . $e->getMessage());
                return $this->redirect("/admin/messages/{$id}");
            }
        }

        $messageModel = new Message();
        $messageModel->addReply($id, Auth::id(), $replyText, $replyFile);

        AuditLog::log(Auth::id(), 'REPLY', 'messages', $id, "Murojaatga javob berildi");
        $this->flashSuccess("Rasmiy javob muvaffaqiyatli saqlandi va murojaatchiga yo'llandi.");
        return $this->redirect("/admin/messages/{$id}");
    }

    public function updateStatus(int $id)
    {
        $status = (string)$this->request->input('status');
        if (!in_array($status, ['NEW', 'IN_PROGRESS', 'ANSWERED', 'CLOSED'], true)) {
            $this->flashError("Noto'g'ri status tanlandi.");
            return $this->redirect("/admin/messages/{$id}");
        }

        $messageModel = new Message();
        $messageModel->update($id, ['status' => $status]);

        AuditLog::log(Auth::id(), 'UPDATE_STATUS', 'messages', $id, "Murojaat statusi: {$status}");
        $this->flashSuccess("Murojaat statusi o'zgartirildi.");
        return $this->redirect("/admin/messages/{$id}");
    }

    public function delete(int $id)
    {
        $messageModel = new Message();
        $messageModel->softDelete($id);
        AuditLog::log(Auth::id(), 'DELETE', 'messages', $id, "Murojaat o'chirildi");
        $this->flashSuccess("Murojaat o'chirildi.");
        return $this->redirect('/admin/messages');
    }

    public function export()
    {
        $messageModel = new Message();
        $messages = $messageModel->all('id DESC');

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="virtual_qabulxona_' . date('Ymd_His') . '.csv"');

        $out = fopen('php://output', 'w');
        fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));

        fputcsv($out, ['ID', 'Kod', 'F.I.Sh', 'Telefon', 'Email', 'Turi', 'Mavzu', 'Holati', 'Sana']);

        foreach ($messages as $m) {
            fputcsv($out, [
                $m['id'],
                $m['tracking_code'],
                $m['full_name'],
                $m['phone'],
                $m['email'] ?? '',
                $m['inquiry_type'],
                $m['subject'],
                $m['status'],
                $m['created_at']
            ]);
        }

        fclose($out);
        exit;
    }
}

