<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\AuditLog;
use Models\Gallery;
use Services\UploadService;

class GalleryAdminController extends Controller
{
    public function index(): string
    {
        $m = new Gallery();
        return $this->render('admin.gallery.index', [
            'title' => 'Fotogalereya albomlari',
            'albums' => $m->allWithImages()
        ], 'layouts.admin');
    }

    public function create(): string
    {
        return $this->render('admin.gallery.form', [
            'title' => 'Yangi albom yaratish',
            'album' => null
        ], 'layouts.admin');
    }

    public function store()
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'title_uz' => 'required|min:3'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/gallery/create');
        }

        if (!$this->request->hasFile('cover_image')) {
            $this->flashError("Albom muqovasi rasmini yuklang.");
            return $this->redirect('/admin/gallery/create');
        }

        try {
            $cover = UploadService::uploadImage($this->request->file('cover_image'), 'gallery');
        } catch (\Throwable $e) {
            $this->flashError("Rasm yuklashda xato: " . $e->getMessage());
            return $this->redirect('/admin/gallery/create');
        }

        $m = new Gallery();
        $id = $m->create([
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'event_date' => !empty($data['event_date']) ? $data['event_date'] : date('Y-m-d'),
            'cover_image' => $cover,
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        // Upload additional images if any
        if (isset($_FILES['images']) && !empty($_FILES['images']['name'][0])) {
            $files = $_FILES['images'];
            for ($i = 0; $i < count($files['name']); $i++) {
                if ($files['error'][$i] === UPLOAD_ERR_OK) {
                    $single = [
                        'name' => $files['name'][$i],
                        'type' => $files['type'][$i],
                        'tmp_name' => $files['tmp_name'][$i],
                        'error' => $files['error'][$i],
                        'size' => $files['size'][$i]
                    ];
                    try {
                        $p = UploadService::uploadImage($single, 'gallery');
                        $m->addImage($id, $p, null, $i + 1);
                    } catch (\Throwable $e) {}
                }
            }
        }

        AuditLog::log(Auth::id(), 'CREATE', 'gallery', $id, "Galereya albomi yaratildi: " . $data['title_uz']);
        $this->flashSuccess("Albom muvaffaqiyatli yaratildi.");
        return $this->redirect('/admin/gallery');
    }

    public function edit(int $id): string
    {
        $m = new Gallery();
        $album = $m->find($id);

        if (!$album) {
            $this->flashError("Albom topilmadi.");
            return $this->redirect('/admin/gallery');
        }

        $album['images'] = (new \Core\Database())->getInstance()->query("SELECT * FROM gallery_images WHERE gallery_id = ? ORDER BY sort_order ASC, id ASC", [$id]);

        return $this->render('admin.gallery.form', [
            'title' => 'Albomni tahrirlash',
            'album' => $album
        ], 'layouts.admin');
    }

    public function update(int $id)
    {
        $m = new Gallery();
        $album = $m->find($id);

        if (!$album) {
            $this->flashError("Albom topilmadi.");
            return $this->redirect('/admin/gallery');
        }

        $data = $this->request->all();
        $cover = $album['cover_image'];

        if ($this->request->hasFile('cover_image')) {
            try {
                $cover = UploadService::uploadImage($this->request->file('cover_image'), 'gallery');
            } catch (\Throwable $e) {
                $this->flashError("Rasm yuklashda xato: " . $e->getMessage());
                return $this->redirect("/admin/gallery/edit/{$id}");
            }
        }

        $m->update($id, [
            'title_uz' => trim((string)$data['title_uz']),
            'title_ru' => trim((string)($data['title_ru'] ?? '')),
            'title_en' => trim((string)($data['title_en'] ?? '')),
            'event_date' => !empty($data['event_date']) ? $data['event_date'] : $album['event_date'],
            'cover_image' => $cover,
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        // Upload additional images
        if (isset($_FILES['images']) && !empty($_FILES['images']['name'][0])) {
            $files = $_FILES['images'];
            for ($i = 0; $i < count($files['name']); $i++) {
                if ($files['error'][$i] === UPLOAD_ERR_OK) {
                    $single = [
                        'name' => $files['name'][$i],
                        'type' => $files['type'][$i],
                        'tmp_name' => $files['tmp_name'][$i],
                        'error' => $files['error'][$i],
                        'size' => $files['size'][$i]
                    ];
                    try {
                        $p = UploadService::uploadImage($single, 'gallery');
                        $m->addImage($id, $p, null, 10);
                    } catch (\Throwable $e) {}
                }
            }
        }

        AuditLog::log(Auth::id(), 'UPDATE', 'gallery', $id, "Galereya albomi yangilandi: " . $data['title_uz']);
        $this->flashSuccess("Albom muvaffaqiyatli yangilandi.");
        return $this->redirect('/admin/gallery');
    }

    public function delete(int $id)
    {
        $m = new Gallery();
        $m->softDelete($id);
        AuditLog::log(Auth::id(), 'DELETE', 'gallery', $id, "Albom o'chirildi");
        $this->flashSuccess("Albom o'chirildi.");
        return $this->redirect('/admin/gallery');
    }

    public function deleteImage(int $imageId)
    {
        $m = new Gallery();
        $m->deleteImage($imageId);
        return $this->back();
    }
}

