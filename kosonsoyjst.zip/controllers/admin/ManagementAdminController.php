<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\AuditLog;
use Models\Management;
use Services\UploadService;

class ManagementAdminController extends Controller
{
    public function index(): string
    {
        $mgmtModel = new Management();
        return $this->render('admin.management.index', [
            'title' => 'Rahbariyat boshqaruvi',
            'management' => $mgmtModel->where('1=1', [], 'sort_order ASC, id ASC')
        ], 'layouts.admin');
    }

    public function create(): string
    {
        return $this->render('admin.management.form', [
            'title' => 'Yangi rahbar qo\'shish',
            'member' => null
        ], 'layouts.admin');
    }

    public function store()
    {
        $data = $this->request->all();
        $validator = $this->validate($data, [
            'full_name_uz' => 'required|min:3',
            'position_uz' => 'required',
            'category' => 'required|in:director,deputy_director,department_head'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect('/admin/management/create');
        }

        $imagePath = null;
        if ($this->request->hasFile('image')) {
            try {
                $imagePath = UploadService::uploadImage($this->request->file('image'), 'management');
            } catch (\Throwable $e) {
                $this->flashError("Rasm yuklashda xato: " . $e->getMessage());
                return $this->redirect('/admin/management/create');
            }
        }

        $mgmtModel = new Management();
        $id = $mgmtModel->create([
            'full_name_uz' => trim((string)$data['full_name_uz']),
            'full_name_ru' => trim((string)($data['full_name_ru'] ?? '')),
            'full_name_en' => trim((string)($data['full_name_en'] ?? '')),
            'position_uz' => trim((string)$data['position_uz']),
            'position_ru' => trim((string)($data['position_ru'] ?? '')),
            'position_en' => trim((string)($data['position_en'] ?? '')),
            'category' => $data['category'],
            'bio_uz' => trim((string)($data['bio_uz'] ?? '')),
            'bio_ru' => trim((string)($data['bio_ru'] ?? '')),
            'bio_en' => trim((string)($data['bio_en'] ?? '')),
            'phone' => trim((string)($data['phone'] ?? '')),
            'email' => trim((string)($data['email'] ?? '')),
            'reception_days_uz' => trim((string)($data['reception_days_uz'] ?? '')),
            'reception_days_ru' => trim((string)($data['reception_days_ru'] ?? '')),
            'reception_days_en' => trim((string)($data['reception_days_en'] ?? '')),
            'image' => $imagePath,
            'sort_order' => (int)($data['sort_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'CREATE', 'management', $id, "Rahbar qo'shildi: " . $data['full_name_uz']);
        $this->flashSuccess("Rahbar ma'lumotlari saqlandi.");
        return $this->redirect('/admin/management');
    }

    public function edit(int $id): string
    {
        $mgmtModel = new Management();
        $member = $mgmtModel->find($id);

        if (!$member) {
            $this->flashError("Rahbar topilmadi.");
            return $this->redirect('/admin/management');
        }

        return $this->render('admin.management.form', [
            'title' => 'Rahbar ma\'lumotlarini tahrirlash',
            'member' => $member
        ], 'layouts.admin');
    }

    public function update(int $id)
    {
        $mgmtModel = new Management();
        $member = $mgmtModel->find($id);

        if (!$member) {
            $this->flashError("Rahbar topilmadi.");
            return $this->redirect('/admin/management');
        }

        $data = $this->request->all();
        $validator = $this->validate($data, [
            'full_name_uz' => 'required|min:3',
            'position_uz' => 'required'
        ]);

        if ($validator->fails()) {
            $this->flashError($validator->first());
            return $this->redirect("/admin/management/edit/{$id}");
        }

        $imagePath = $member['image'];
        if ($this->request->hasFile('image')) {
            try {
                $imagePath = UploadService::uploadImage($this->request->file('image'), 'management');
            } catch (\Throwable $e) {
                $this->flashError("Rasm yuklashda xato: " . $e->getMessage());
                return $this->redirect("/admin/management/edit/{$id}");
            }
        }

        $mgmtModel->update($id, [
            'full_name_uz' => trim((string)$data['full_name_uz']),
            'full_name_ru' => trim((string)($data['full_name_ru'] ?? '')),
            'full_name_en' => trim((string)($data['full_name_en'] ?? '')),
            'position_uz' => trim((string)$data['position_uz']),
            'position_ru' => trim((string)($data['position_ru'] ?? '')),
            'position_en' => trim((string)($data['position_en'] ?? '')),
            'category' => $data['category'] ?? $member['category'],
            'bio_uz' => trim((string)($data['bio_uz'] ?? '')),
            'bio_ru' => trim((string)($data['bio_ru'] ?? '')),
            'bio_en' => trim((string)($data['bio_en'] ?? '')),
            'phone' => trim((string)($data['phone'] ?? '')),
            'email' => trim((string)($data['email'] ?? '')),
            'reception_days_uz' => trim((string)($data['reception_days_uz'] ?? '')),
            'reception_days_ru' => trim((string)($data['reception_days_ru'] ?? '')),
            'reception_days_en' => trim((string)($data['reception_days_en'] ?? '')),
            'image' => $imagePath,
            'sort_order' => (int)($data['sort_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? 1 : 0
        ]);

        AuditLog::log(Auth::id(), 'UPDATE', 'management', $id, "Rahbar yangilandi: " . $data['full_name_uz']);
        $this->flashSuccess("Ma'lumotlar muvaffaqiyatli yangilandi.");
        return $this->redirect('/admin/management');
    }

    public function delete(int $id)
    {
        $mgmtModel = new Management();
        $mgmtModel->softDelete($id);
        AuditLog::log(Auth::id(), 'DELETE', 'management', $id, "Rahbar o'chirildi");
        $this->flashSuccess("Rahbar o'chirildi.");
        return $this->redirect('/admin/management');
    }
}

