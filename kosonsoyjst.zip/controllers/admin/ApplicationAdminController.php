<?php
declare(strict_types=1);

namespace Controllers\Admin;

use Core\Controller;
use Core\Auth;
use Core\Response;
use Core\AuditLog;
use Models\Application;
use Models\Vacancy;

class ApplicationAdminController extends Controller
{
    public function index(): string
    {
        $vacancyId = $this->request->get('vacancy_id') ? (int)$this->request->get('vacancy_id') : null;
        $status = $this->request->get('status');

        $appModel = new Application();
        $vacModel = new Vacancy();

        $applications = $appModel->allWithVacancy($vacancyId, $status);
        $vacancies = $vacModel->all();

        return $this->render('admin.applications.index', [
            'title' => 'Vakansiya arizalari',
            'applications' => $applications,
            'vacancies' => $vacancies,
            'currentVacancy' => $vacancyId,
            'currentStatus' => $status
        ], 'layouts.admin');
    }

    public function show(int $id): string
    {
        $appModel = new Application();
        $item = $appModel->find($id);

        if (!$item) {
            $this->flashError("Ariza topilmadi.");
            return $this->redirect('/admin/applications');
        }

        $vacModel = new Vacancy();
        $vacancy = $vacModel->find((int)$item['vacancy_id']);

        return $this->render('admin.applications.show', [
            'title' => 'Ariza tafsiloti: ' . $item['full_name'],
            'application' => $item,
            'vacancy' => $vacancy
        ], 'layouts.admin');
    }

    public function updateStatus(int $id)
    {
        $status = $this->request->input('status');
        $notes = $this->request->input('admin_notes');

        if (!in_array($status, ['NEW', 'REVIEWING', 'ACCEPTED', 'REJECTED'], true)) {
            $this->flashError("Noto'g'ri status tanlandi.");
            return $this->redirect("/admin/applications/{$id}");
        }

        $appModel = new Application();
        $appModel->update($id, [
            'status' => $status,
            'admin_notes' => trim((string)$notes)
        ]);

        AuditLog::log(Auth::id(), 'UPDATE_STATUS', 'applications', $id, "Ariza statusi o'zgartirildi: {$status}");
        $this->flashSuccess("Ariza statusi yangilandi.");
        return $this->redirect("/admin/applications/{$id}");
    }

    public function delete(int $id)
    {
        $appModel = new Application();
        $appModel->softDelete($id);
        AuditLog::log(Auth::id(), 'DELETE', 'applications', $id, "Ariza o'chirildi");
        $this->flashSuccess("Ariza o'chirildi.");
        return $this->redirect('/admin/applications');
    }

    public function export()
    {
        $appModel = new Application();
        $items = $appModel->allWithVacancy();

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="vakansiya_arizalari_' . date('Ymd_His') . '.csv"');

        $out = fopen('php://output', 'w');
        // UTF-8 BOM for Excel
        fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));

        fputcsv($out, ['ID', 'Lavozim', 'F.I.Sh', 'Telefon', 'Email', 'Holati', 'Qo\'shimcha izoh', 'Sana']);

        foreach ($items as $item) {
            fputcsv($out, [
                $item['id'],
                $item['vacancy_title'],
                $item['full_name'],
                $item['phone'],
                $item['email'],
                $item['status'],
                $item['admin_notes'] ?? '',
                $item['created_at']
            ]);
        }

        fclose($out);
        exit;
    }
}

