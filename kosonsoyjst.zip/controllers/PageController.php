<?php
declare(strict_types=1);

namespace Controllers;

use Core\Controller;
use Core\Response;
use Models\Page;

class PageController extends Controller
{
    public function show(string $slug): string
    {
        $pageModel = new Page();
        $page = $pageModel->findBySlug($slug);

        if (!$page) {
            Response::setStatusCode(404);
            return $this->render('errors.404', ['title' => 'Sahifa topilmadi'], 'layouts.main');
        }

        return $this->render('pages.show', [
            'title' => t($page, 'title') . ' - ' . setting('site_name', 'Kosonsoy Kolleji'),
            'page' => $page,
            'meta_title' => $page['meta_title'] ?: t($page, 'title'),
            'meta_description' => $page['meta_description'] ?: ''
        ], 'layouts.main');
    }
}

