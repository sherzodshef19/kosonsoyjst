<?php
declare(strict_types=1);

namespace Controllers;

use Core\Controller;
use Models\Gallery;

class GalleryController extends Controller
{
    public function index(): string
    {
        $galleryModel = new Gallery();
        $albums = $galleryModel->allWithImages();

        return $this->render('gallery.index', [
            'title' => trans('gallery') . ' - ' . setting('site_name', 'Kosonsoy Kolleji'),
            'albums' => $albums
        ], 'layouts.main');
    }
}

