<?php
declare(strict_types=1);

namespace Controllers;

use Core\Controller;
use Models\Statistic;

class StatisticController extends Controller
{
    public function index(): string
    {
        $statModel = new Statistic();
        $stats = $statModel->allActive();

        return $this->render('statistics.index', [
            'title' => trans('statistics') . ' - ' . setting('site_name', 'Kosonsoy Kolleji'),
            'statistics' => $stats
        ], 'layouts.main');
    }
}

