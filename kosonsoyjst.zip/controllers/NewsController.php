<?php
declare(strict_types=1);

namespace Controllers;

use Core\Controller;
use Core\Response;
use Models\News;
use Models\Category;

class NewsController extends Controller
{
    public function index(): string
    {
        $page = (int)$this->request->get('page', 1);
        $catId = $this->request->get('category') ? (int)$this->request->get('category') : null;
        $search = $this->request->get('q') ? trim((string)$this->request->get('q')) : null;

        $newsModel = new News();
        $catModel = new Category();

        $pagination = $newsModel->paginateWithDetails($page, 9, $catId, $search);
        $categories = $catModel->allWithCount();
        $featuredNews = (!$search && !$catId && $page === 1) ? $newsModel->getFeatured() : null;

        return $this->render('news.index', [
            'title' => trans('news') . ' - ' . setting('site_name', 'Kosonsoy Kolleji'),
            'news' => $pagination['data'],
            'pagination' => $pagination,
            'categories' => $categories,
            'currentCategory' => $catId,
            'searchQuery' => $search,
            'featuredNews' => $featuredNews
        ], 'layouts.main');
    }

    public function show(string $slug): string
    {
        $newsModel = new News();
        $item = $newsModel->findBySlug($slug);

        if (!$item) {
            Response::setStatusCode(404);
            return $this->render('errors.404', ['title' => 'Yangilik topilmadi'], 'layouts.main');
        }

        // Increment views
        $newsModel->incrementViews((int)$item['id']);

        $gallery = $newsModel->getGallery((int)$item['id']);
        $tags = $newsModel->getTags((int)$item['id']);
        $related = $newsModel->getRelated((int)$item['id'], (int)$item['category_id'], 3);

        return $this->render('news.show', [
            'title' => t($item, 'title') . ' - ' . setting('site_name', 'Kosonsoy Kolleji'),
            'news' => $item,
            'gallery' => $gallery,
            'tags' => $tags,
            'related' => $related,
            'meta_title' => $item['meta_title'] ?: t($item, 'title'),
            'meta_description' => $item['meta_description'] ?: t($item, 'summary')
        ], 'layouts.main');
    }
}

