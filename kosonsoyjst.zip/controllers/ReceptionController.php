<?php
declare(strict_types=1);

namespace Controllers;

use Core\Controller;
use Core\Session;
use Models\Message;
use Services\UploadService;
use Services\TelegramService;

class ReceptionController extends Controller
{
    public function index(): string
    {
        // Generate math captcha
        $n1 = rand(1, 9);
        $n2 = rand(1, 9);
        Session::set('_captcha_answer', $n1 + $n2);
        Session::set('_captcha_question', "{$n1} + {$n2} = ?");

        return $this->render('reception.index', [
            'title' => trans('virtual_reception') . ' - ' . setting('site_name', 'Kosonsoy Kolleji'),
            'captcha_question' => "{$n1} + {$n2} = ?"
        ], 'layouts.main');
    }

    public function submit()
    {
        $data = $this->request->all();

        // Check captcha
        $captchaInput = (int)($data['captcha'] ?? 0);
        $expected = (int)Session::get('_captcha_answer', -999);

        if ($captchaInput !== $expected) {
            Session::flash('_old_input', $data);
            $this->flashError("Xavfsizlik kodi (CAPTCHA) noto'g'ri kiritildi.");
            return $this->redirect('/reception');
        }

        $validator = $this->validate($data, [
            'full_name' => 'required|min:3|max:150',
            'phone' => 'required|min:7|max:40',
            'subject' => 'required|min:4|max:255',
            'message' => 'required|min:10',
            'inquiry_type' => 'in:murojaat,taklif,shikoyat,ariza'
        ]);

        if ($validator->fails()) {
            Session::flash('_old_input', $data);
            Session::flash('errors', $validator->errors());
            $this->flashError($validator->first());
            return $this->redirect('/reception');
        }

        // Handle attachment file if present
        $attachmentPath = null;
        if ($this->request->hasFile('attachment')) {
            try {
                $attachmentPath = UploadService::uploadDocument($this->request->file('attachment'), 'reception');
            } catch (\Throwable $e) {
                Session::flash('_old_input', $data);
                $this->flashError("Fayl yuklashda xatolik: " . $e->getMessage());
                return $this->redirect('/reception');
            }
        }

        $code = Message::generateTrackingCode();
        $messageModel = new Message();

        $messageData = [
            'tracking_code' => $code,
            'full_name' => trim((string)$data['full_name']),
            'phone' => trim((string)$data['phone']),
            'email' => trim((string)($data['email'] ?? '')),
            'address' => trim((string)($data['address'] ?? '')),
            'inquiry_type' => $data['inquiry_type'] ?? 'murojaat',
            'subject' => trim((string)$data['subject']),
            'message' => trim((string)$data['message']),
            'attachment_file' => $attachmentPath,
            'status' => 'NEW',
            'ip_address' => $this->request->ip()
        ];

        $messageModel->create($messageData);

        // Notify Telegram
        TelegramService::notifyInquiry($messageData);

        // Flash tracking code to user
        Session::flash('tracking_code', $code);
        $this->flashSuccess("Murojaatingiz muvaffaqiyatli ro'yxatga olindi! Murojaat kodingiz: {$code}");

        return $this->redirect("/reception/check?code={$code}");
    }

    public function check(): string
    {
        $code = trim((string)$this->request->get('code', ''));
        $message = null;
        $searched = false;

        if (!empty($code)) {
            $searched = true;
            $messageModel = new Message();
            $message = $messageModel->findByTrackingCode($code);
        }

        return $this->render('reception.check', [
            'title' => trans('check_status') . ' - ' . setting('site_name', 'Kosonsoy Kolleji'),
            'code' => $code,
            'message' => $message,
            'searched' => $searched
        ], 'layouts.main');
    }
}

