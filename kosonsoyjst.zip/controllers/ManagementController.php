<?php
declare(strict_types=1);

namespace Controllers;

use Core\Controller;
use Models\Management;
use Models\Employee;

class ManagementController extends Controller
{
    public function index(): string
    {
        $mgmtModel = new Management();
        $empModel = new Employee();

        $directors = $mgmtModel->getByCategory('director');
        $deputies = $mgmtModel->getByCategory('deputy_director');
        $heads = $mgmtModel->getByCategory('department_head');
        $employees = $empModel->allActive();

        return $this->render('management.index', [
            'title' => trans('management') . ' - ' . setting('site_name', 'Kosonsoy Kolleji'),
            'directors' => $directors,
            'deputies' => $deputies,
            'heads' => $heads,
            'employees' => $employees
        ], 'layouts.main');
    }
}

