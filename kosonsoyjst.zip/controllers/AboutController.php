<?php
declare(strict_types=1);

namespace Controllers;

use Core\Controller;
use Models\Statistic;
use Models\Partner;
use Models\Management;

class AboutController extends Controller
{
    public function index(): string
    {
        $statModel = new Statistic();
        $partnerModel = new Partner();
        $mgmtModel = new Management();

        return $this->render('about.index', [
            'title' => trans('about_us') . ' - ' . setting('site_name', 'Kosonsoy Kolleji'),
            'statistics' => $statModel->allActive(),
            'partners' => $partnerModel->allActive(),
            'directors' => $mgmtModel->getByCategory('director')
        ], 'layouts.main');
    }
}

