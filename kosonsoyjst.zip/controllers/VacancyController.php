<?php
declare(strict_types=1);

namespace Controllers;

use Core\Controller;
use Core\Response;
use Core\Session;
use Models\Vacancy;
use Models\Application;
use Services\UploadService;
use Services\TelegramService;

class VacancyController extends Controller
{
    public function index(): string
    {
        $vacancyModel = new Vacancy();
        $vacancies = $vacancyModel->allActive();

        return $this->render('vacancies.index', [
            'title' => trans('vacancies') . ' - ' . setting('site_name', 'Kosonsoy Kolleji'),
            'vacancies' => $vacancies
        ], 'layouts.main');
    }

    public function show(int $id): string
    {
        $vacancyModel = new Vacancy();
        $vacancy = $vacancyModel->find($id);

        if (!$vacancy || $vacancy['is_active'] != 1) {
            Response::setStatusCode(404);
            return $this->render('errors.404', ['title' => 'Vakansiya topilmadi'], 'layouts.main');
        }

        return $this->render('vacancies.show', [
            'title' => t($vacancy, 'title') . ' - ' . setting('site_name', 'Kosonsoy Kolleji'),
            'vacancy' => $vacancy
        ], 'layouts.main');
    }

    public function apply(int $id)
    {
        $vacancyModel = new Vacancy();
        $vacancy = $vacancyModel->find($id);

        if (!$vacancy || $vacancy['is_active'] != 1) {
            $this->flashError("Tanlangan vakansiya mavjud emas yoki faol emas.");
            return $this->redirect('/vacancies');
        }

        $validator = $this->validate($this->request->all(), [
            'full_name' => 'required|min:3|max:150',
            'phone' => 'required|min:7|max:40',
            'email' => 'required|email|max:100'
        ]);

        if ($validator->fails()) {
            Session::flash('_old_input', $this->request->all());
            Session::flash('errors', $validator->errors());
            $this->flashError($validator->first());
            return $this->redirect("/vacancies/{$id}");
        }

        // Handle CV upload
        if (!$this->request->hasFile('cv_file')) {
            $this->flashError("Iltimos, rezyume (CV) faylini yuklang (PDF yoki DOCX).");
            return $this->redirect("/vacancies/{$id}");
        }

        try {
            $cvPath = UploadService::uploadCV($this->request->file('cv_file'), 'cv');

            $appModel = new Application();
            $appData = [
                'vacancy_id' => $id,
                'full_name' => trim((string)$this->request->input('full_name')),
                'phone' => trim((string)$this->request->input('phone')),
                'email' => trim((string)$this->request->input('email')),
                'message' => trim((string)$this->request->input('message', '')),
                'cv_file' => $cvPath,
                'status' => 'NEW'
            ];

            $appId = $appModel->create($appData);

            // Notify Telegram
            TelegramService::notifyApplication($appData, t($vacancy, 'title'));

            $this->flashSuccess("Arizangiz muvaffaqiyatli qabul qilindi! Mutaxassislarimiz tez orada siz bilan bog'lanishadi.");
            return $this->redirect("/vacancies/{$id}");
        } catch (\Throwable $e) {
            $this->flashError("Xatolik: " . $e->getMessage());
            return $this->redirect("/vacancies/{$id}");
        }
    }
}

