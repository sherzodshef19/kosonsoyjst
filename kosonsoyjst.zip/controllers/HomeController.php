<?php
declare(strict_types=1);

namespace Controllers;

use Core\Controller;
use Models\Banner;
use Models\News;
use Models\Category;
use Models\Statistic;
use Models\Management;
use Models\Gallery;
use Models\Partner;
use Models\Document;
use Models\Program;

class HomeController extends Controller
{
    public function index(): string
    {
        $bannerModel = new Banner();
        $newsModel = new News();
        $catModel = new Category();
        $statModel = new Statistic();
        $mgmtModel = new Management();
        $galleryModel = new Gallery();
        $partnerModel = new Partner();
        $docModel = new Document();
        $programModel = new Program();

        $banners = $bannerModel->allActive();
        $featuredNews = $newsModel->getFeatured();
        $latestNews = $newsModel->paginateWithDetails(1, 6)['data'];
        $announcements = $newsModel->getAnnouncements(4);
        $categories = $catModel->allWithCount();
        $statistics = $statModel->allActive();
        $management = $mgmtModel->allActive();
        $gallery = $galleryModel->allWithImages();
        $partners = $partnerModel->allActive();
        $documents = $docModel->allActive();
        $programs = $programModel->allActive();

        return $this->render('home.index', [
            'title' => setting('site_name', 'Kosonsoy Kolleji') . ' - Rasmiy veb-sayti',
            'banners' => $banners,
            'featuredNews' => $featuredNews,
            'latestNews' => $latestNews,
            'announcements' => $announcements,
            'categories' => $categories,
            'statistics' => $statistics,
            'management' => $management,
            'gallery' => $gallery,
            'partners' => $partners,
            'documents' => array_slice($documents, 0, 4),
            'programs' => $programs
        ], 'layouts.main');
    }
}

