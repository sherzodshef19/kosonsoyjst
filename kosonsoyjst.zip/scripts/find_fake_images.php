<?php
$dir = __DIR__ . '/../public/assets/images';
$files = glob($dir . '/*.*');

foreach ($files as $f) {
    $content = file_get_contents($f, false, null, 0, 10);
    $isSvg = (strpos($content, '<svg') !== false || strpos($content, '<?xml') !== false);
    $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
    if ($isSvg && in_array($ext, ['png', 'jpg', 'jpeg'])) {
        echo "FAKE $ext (actually SVG!): " . basename($f) . " (" . filesize($f) . " bytes)\n";
    }
}

