<?php
declare(strict_types=1);

use Core\Router;
use Api\NewsApiController;
use Api\VacancyApiController;
use Api\ReceptionApiController;
use Api\PublicApiController;

/** @var Router $router */

$router->group(['prefix' => '/api/v1'], function (Router $r) {
    // News
    $r->get('/news', [NewsApiController::class, 'index']);
    $r->get('/news/{id}', [NewsApiController::class, 'show']);
    $r->get('/categories', [NewsApiController::class, 'categories']);

    // Vacancies
    $r->get('/vacancies', [VacancyApiController::class, 'index']);
    $r->get('/vacancies/{id}', [VacancyApiController::class, 'show']);
    $r->post('/vacancies/{id}/apply', [VacancyApiController::class, 'apply']);

    // Virtual Reception
    $r->post('/inquiry', [ReceptionApiController::class, 'submit']);
    $r->get('/inquiry/status', [ReceptionApiController::class, 'status']);

    // Public Data
    $r->get('/statistics', [PublicApiController::class, 'statistics']);
    $r->get('/management', [PublicApiController::class, 'management']);
    $r->get('/banners', [PublicApiController::class, 'banners']);
    $r->get('/gallery', [PublicApiController::class, 'gallery']);
    $r->get('/documents', [PublicApiController::class, 'documents']);
    $r->get('/partners', [PublicApiController::class, 'partners']);
    $r->get('/settings', [PublicApiController::class, 'settings']);
});

