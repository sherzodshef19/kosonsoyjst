<?php
declare(strict_types=1);

use Core\Router;
use Core\Request;
use Core\Response;
use Core\Session;
use Controllers\HomeController;
use Controllers\NewsController;
use Controllers\ManagementController;
use Controllers\StatisticController;
use Controllers\VacancyController;
use Controllers\ReceptionController;
use Controllers\AboutController;
use Controllers\DocumentController;
use Controllers\GalleryController;
use Controllers\PageController;

use Controllers\Admin\AuthController;
use Controllers\Admin\DashboardController;
use Controllers\Admin\NewsAdminController;
use Controllers\Admin\CategoryAdminController;
use Controllers\Admin\ManagementAdminController;
use Controllers\Admin\EmployeeAdminController;
use Controllers\Admin\StatisticAdminController;
use Controllers\Admin\VacancyAdminController;
use Controllers\Admin\ApplicationAdminController;
use Controllers\Admin\MessageAdminController;
use Controllers\Admin\PageAdminController;
use Controllers\Admin\MenuAdminController;
use Controllers\Admin\BannerAdminController;
use Controllers\Admin\GalleryAdminController;
use Controllers\Admin\DocumentAdminController;
use Controllers\Admin\PartnerAdminController;
use Controllers\Admin\ProgramAdminController;
use Controllers\Admin\MediaAdminController;
use Controllers\Admin\UserAdminController;
use Controllers\Admin\RoleAdminController;
use Controllers\Admin\SettingAdminController;
use Controllers\Admin\AuditLogAdminController;

/** @var Router $router */

// Public Web Pages
$router->get('/lang/{locale}', function(string $locale) {
    if (in_array($locale, ['uz', 'ru', 'en'], true)) {
        Session::set('locale', $locale);
        if (!headers_sent()) {
            setcookie('site_lang', $locale, time() + 86400 * 30, '/');
        }
    }
    $referer = $_SERVER['HTTP_REFERER'] ?? '/';
    if (strpos($referer, '/lang/') !== false) {
        $referer = '/';
    }
    Response::redirect($referer);
});
$router->get('/', [HomeController::class, 'index']);
$router->get('/news', [NewsController::class, 'index']);
$router->get('/news/{slug}', [NewsController::class, 'show']);
$router->get('/management', [ManagementController::class, 'index']);
$router->get('/statistics', [StatisticController::class, 'index']);
$router->get('/vacancies', [VacancyController::class, 'index']);
$router->get('/vacancies/{id}', [VacancyController::class, 'show']);
$router->post('/vacancies/{id}/apply', [VacancyController::class, 'apply'], ['csrf']);
$router->get('/reception', [ReceptionController::class, 'index']);
$router->post('/reception', [ReceptionController::class, 'submit'], ['csrf']);
$router->post('/reception/submit', [ReceptionController::class, 'submit'], ['csrf']);
$router->get('/reception/check', [ReceptionController::class, 'check']);
$router->get('/about', [AboutController::class, 'index']);
$router->get('/documents', [DocumentController::class, 'index']);
$router->get('/documents/download/{id}', [DocumentController::class, 'download']);
$router->get('/gallery', [GalleryController::class, 'index']);
$router->get('/pages/{slug}', [PageController::class, 'show']);

// Admin Auth Routes
$router->get('/admin/login', [AuthController::class, 'showLogin']);
$router->post('/admin/login', [AuthController::class, 'login'], ['csrf']);
$router->get('/admin/logout', [AuthController::class, 'logout']);
$router->post('/admin/logout', [AuthController::class, 'logout']);

// Admin Dashboard & Protected Modules
$router->group(['prefix' => '/admin', 'middleware' => ['auth']], function (Router $r) {
    $r->get('/', [DashboardController::class, 'index']);
    $r->get('/profile', [AuthController::class, 'profile']);
    $r->post('/profile/update', [AuthController::class, 'updateProfile'], ['csrf']);
    $r->post('/profile/password', [AuthController::class, 'changePassword'], ['csrf']);

    // News
    $r->get('/news', [NewsAdminController::class, 'index'], ['can:news.view']);
    $r->get('/news/create', [NewsAdminController::class, 'create'], ['can:news.create']);
    $r->post('/news/store', [NewsAdminController::class, 'store'], ['csrf', 'can:news.create']);
    $r->get('/news/edit/{id}', [NewsAdminController::class, 'edit'], ['can:news.edit']);
    $r->post('/news/update/{id}', [NewsAdminController::class, 'update'], ['csrf', 'can:news.edit']);
    $r->get('/news/delete/{id}', [NewsAdminController::class, 'delete'], ['can:news.delete']);
    $r->get('/news/gallery-delete/{id}', [NewsAdminController::class, 'deleteGalleryImage'], ['can:news.edit']);

    // Categories
    $r->get('/categories', [CategoryAdminController::class, 'index'], ['can:categories.manage']);
    $r->post('/categories/store', [CategoryAdminController::class, 'store'], ['csrf', 'can:categories.manage']);
    $r->post('/categories/update/{id}', [CategoryAdminController::class, 'update'], ['csrf', 'can:categories.manage']);
    $r->get('/categories/delete/{id}', [CategoryAdminController::class, 'delete'], ['can:categories.manage']);

    // Management
    $r->get('/management', [ManagementAdminController::class, 'index'], ['can:management.manage']);
    $r->get('/management/create', [ManagementAdminController::class, 'create'], ['can:management.manage']);
    $r->post('/management/store', [ManagementAdminController::class, 'store'], ['csrf', 'can:management.manage']);
    $r->get('/management/edit/{id}', [ManagementAdminController::class, 'edit'], ['can:management.manage']);
    $r->post('/management/update/{id}', [ManagementAdminController::class, 'update'], ['csrf', 'can:management.manage']);
    $r->get('/management/delete/{id}', [ManagementAdminController::class, 'delete'], ['can:management.manage']);

    // Employees
    $r->get('/employees', [EmployeeAdminController::class, 'index'], ['can:employees.manage']);
    $r->get('/employees/create', [EmployeeAdminController::class, 'create'], ['can:employees.manage']);
    $r->post('/employees/store', [EmployeeAdminController::class, 'store'], ['csrf', 'can:employees.manage']);
    $r->get('/employees/edit/{id}', [EmployeeAdminController::class, 'edit'], ['can:employees.manage']);
    $r->post('/employees/update/{id}', [EmployeeAdminController::class, 'update'], ['csrf', 'can:employees.manage']);
    $r->get('/employees/delete/{id}', [EmployeeAdminController::class, 'delete'], ['can:employees.manage']);

    // Statistics
    $r->get('/statistics', [StatisticAdminController::class, 'index'], ['can:statistics.manage']);
    $r->post('/statistics/store', [StatisticAdminController::class, 'store'], ['csrf', 'can:statistics.manage']);
    $r->post('/statistics/update/{id}', [StatisticAdminController::class, 'update'], ['csrf', 'can:statistics.manage']);
    $r->get('/statistics/delete/{id}', [StatisticAdminController::class, 'delete'], ['can:statistics.manage']);

    // Vacancies
    $r->get('/vacancies', [VacancyAdminController::class, 'index'], ['can:vacancies.manage']);
    $r->get('/vacancies/create', [VacancyAdminController::class, 'create'], ['can:vacancies.manage']);
    $r->post('/vacancies/store', [VacancyAdminController::class, 'store'], ['csrf', 'can:vacancies.manage']);
    $r->get('/vacancies/edit/{id}', [VacancyAdminController::class, 'edit'], ['can:vacancies.manage']);
    $r->post('/vacancies/update/{id}', [VacancyAdminController::class, 'update'], ['csrf', 'can:vacancies.manage']);
    $r->get('/vacancies/delete/{id}', [VacancyAdminController::class, 'delete'], ['can:vacancies.manage']);

    // Applications
    $r->get('/applications', [ApplicationAdminController::class, 'index'], ['can:applications.manage']);
    $r->get('/applications/show/{id}', [ApplicationAdminController::class, 'show'], ['can:applications.manage']);
    $r->post('/applications/status/{id}', [ApplicationAdminController::class, 'updateStatus'], ['csrf', 'can:applications.manage']);
    $r->get('/applications/delete/{id}', [ApplicationAdminController::class, 'delete'], ['can:applications.manage']);
    $r->get('/applications/export', [ApplicationAdminController::class, 'export'], ['can:applications.manage']);

    // Virtual Reception Messages
    $r->get('/messages', [MessageAdminController::class, 'index'], ['can:messages.manage']);
    $r->get('/messages/show/{id}', [MessageAdminController::class, 'show'], ['can:messages.manage']);
    $r->post('/messages/reply/{id}', [MessageAdminController::class, 'reply'], ['csrf', 'can:messages.reply']);
    $r->post('/messages/status/{id}', [MessageAdminController::class, 'updateStatus'], ['csrf', 'can:messages.manage']);
    $r->get('/messages/delete/{id}', [MessageAdminController::class, 'delete'], ['can:messages.manage']);
    $r->get('/messages/export', [MessageAdminController::class, 'export'], ['can:messages.manage']);

    // Pages
    $r->get('/pages', [PageAdminController::class, 'index'], ['can:pages.manage']);
    $r->get('/pages/create', [PageAdminController::class, 'create'], ['can:pages.manage']);
    $r->post('/pages/store', [PageAdminController::class, 'store'], ['csrf', 'can:pages.manage']);
    $r->get('/pages/edit/{id}', [PageAdminController::class, 'edit'], ['can:pages.manage']);
    $r->post('/pages/update/{id}', [PageAdminController::class, 'update'], ['csrf', 'can:pages.manage']);
    $r->get('/pages/delete/{id}', [PageAdminController::class, 'delete'], ['can:pages.manage']);

    // Menus
    $r->get('/menus', [MenuAdminController::class, 'index'], ['can:menus.manage']);
    $r->post('/menus/store', [MenuAdminController::class, 'store'], ['csrf', 'can:menus.manage']);
    $r->post('/menus/update/{id}', [MenuAdminController::class, 'update'], ['csrf', 'can:menus.manage']);
    $r->get('/menus/delete/{id}', [MenuAdminController::class, 'delete'], ['can:menus.manage']);

    // Banners
    $r->get('/banners', [BannerAdminController::class, 'index'], ['can:banners.manage']);
    $r->get('/banners/create', [BannerAdminController::class, 'create'], ['can:banners.manage']);
    $r->post('/banners/store', [BannerAdminController::class, 'store'], ['csrf', 'can:banners.manage']);
    $r->get('/banners/edit/{id}', [BannerAdminController::class, 'edit'], ['can:banners.manage']);
    $r->post('/banners/update/{id}', [BannerAdminController::class, 'update'], ['csrf', 'can:banners.manage']);
    $r->get('/banners/delete/{id}', [BannerAdminController::class, 'delete'], ['can:banners.manage']);

    // Gallery
    $r->get('/gallery', [GalleryAdminController::class, 'index'], ['can:gallery.manage']);
    $r->get('/gallery/create', [GalleryAdminController::class, 'create'], ['can:gallery.manage']);
    $r->post('/gallery/store', [GalleryAdminController::class, 'store'], ['csrf', 'can:gallery.manage']);
    $r->get('/gallery/edit/{id}', [GalleryAdminController::class, 'edit'], ['can:gallery.manage']);
    $r->post('/gallery/update/{id}', [GalleryAdminController::class, 'update'], ['csrf', 'can:gallery.manage']);
    $r->get('/gallery/delete/{id}', [GalleryAdminController::class, 'delete'], ['can:gallery.manage']);
    $r->get('/gallery/image-delete/{id}', [GalleryAdminController::class, 'deleteImage'], ['can:gallery.manage']);

    // Documents
    $r->get('/documents', [DocumentAdminController::class, 'index'], ['can:documents.manage']);
    $r->get('/documents/create', [DocumentAdminController::class, 'create'], ['can:documents.manage']);
    $r->post('/documents/store', [DocumentAdminController::class, 'store'], ['csrf', 'can:documents.manage']);
    $r->get('/documents/edit/{id}', [DocumentAdminController::class, 'edit'], ['can:documents.manage']);
    $r->post('/documents/update/{id}', [DocumentAdminController::class, 'update'], ['csrf', 'can:documents.manage']);
    $r->get('/documents/delete/{id}', [DocumentAdminController::class, 'delete'], ['can:documents.manage']);

    // Partners
    $r->get('/partners', [PartnerAdminController::class, 'index'], ['can:partners.manage']);
    $r->post('/partners/store', [PartnerAdminController::class, 'store'], ['csrf', 'can:partners.manage']);
    $r->post('/partners/update/{id}', [PartnerAdminController::class, 'update'], ['csrf', 'can:partners.manage']);
    $r->get('/partners/delete/{id}', [PartnerAdminController::class, 'delete'], ['can:partners.manage']);

    // Programs (Ta'lim yo'nalishlari)
    $r->get('/programs', [ProgramAdminController::class, 'index'], ['can:programs.manage']);
    $r->post('/programs/store', [ProgramAdminController::class, 'store'], ['csrf', 'can:programs.manage']);
    $r->post('/programs/update/{id}', [ProgramAdminController::class, 'update'], ['csrf', 'can:programs.manage']);
    $r->get('/programs/delete/{id}', [ProgramAdminController::class, 'delete'], ['can:programs.manage']);
    $r->get('/programs/toggle/{id}', [ProgramAdminController::class, 'toggle'], ['can:programs.manage']);

    // Media Manager
    $r->get('/media', [MediaAdminController::class, 'index'], ['can:media.manage']);
    $r->post('/media/upload', [MediaAdminController::class, 'upload'], ['csrf', 'can:media.manage']);
    $r->get('/media/delete/{id}', [MediaAdminController::class, 'delete'], ['can:media.manage']);

    // Users
    $r->get('/users', [UserAdminController::class, 'index'], ['can:users.manage']);
    $r->post('/users/store', [UserAdminController::class, 'store'], ['csrf', 'can:users.manage']);
    $r->post('/users/update/{id}', [UserAdminController::class, 'update'], ['csrf', 'can:users.manage']);
    $r->get('/users/delete/{id}', [UserAdminController::class, 'delete'], ['can:users.manage']);

    // Roles & Permissions
    $r->get('/roles', [RoleAdminController::class, 'index'], ['can:roles.manage']);
    $r->post('/roles/permissions/{id}', [RoleAdminController::class, 'updatePermissions'], ['csrf', 'can:roles.manage']);

    // Site Settings
    $r->get('/settings', [SettingAdminController::class, 'index'], ['can:settings.manage']);
    $r->post('/settings/update', [SettingAdminController::class, 'update'], ['csrf', 'can:settings.manage']);
    $r->post('/settings/test-telegram', [SettingAdminController::class, 'testTelegram'], ['csrf', 'can:settings.manage']);

    // Audit Logs
    $r->get('/audit-logs', [AuditLogAdminController::class, 'index'], ['can:audit_logs.view']);
    $r->post('/audit-logs/clear', [AuditLogAdminController::class, 'clear'], ['csrf', 'role:SUPER_ADMIN']);
});
