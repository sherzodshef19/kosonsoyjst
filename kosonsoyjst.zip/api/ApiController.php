<?php
declare(strict_types=1);

namespace Api;

use Core\Request;
use Core\Response;

abstract class ApiController
{
    protected Request $request;

    public function __construct()
    {
        $this->request = new Request();
    }

    protected function success($data = null, string $message = 'Success', array $meta = [], int $statusCode = 200): void
    {
        $payload = [
            'success' => true,
            'message' => $message,
            'data' => $data
        ];

        if (!empty($meta)) {
            $payload['meta'] = $meta;
        }

        Response::json($payload, $statusCode);
    }

    protected function error(string $message = 'An error occurred', int $statusCode = 400, array $errors = []): void
    {
        $payload = [
            'success' => false,
            'error' => $message
        ];

        if (!empty($errors)) {
            $payload['errors'] = $errors;
        }

        Response::json($payload, $statusCode);
    }
}

