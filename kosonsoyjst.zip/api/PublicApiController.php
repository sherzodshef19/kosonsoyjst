<?php
declare(strict_types=1);

namespace Api;

use Models\Statistic;
use Models\Management;
use Models\Banner;
use Models\Gallery;
use Models\Document;
use Models\Partner;
use Models\Setting;

class PublicApiController extends ApiController
{
    public function statistics(): void
    {
        $m = new Statistic();
        $this->success($m->allActive(), 'Statistics retrieved');
    }

    public function management(): void
    {
        $m = new Management();
        $this->success($m->allActive(), 'Management retrieved');
    }

    public function banners(): void
    {
        $m = new Banner();
        $this->success($m->allActive(), 'Banners retrieved');
    }

    public function gallery(): void
    {
        $m = new Gallery();
        $this->success($m->allWithImages(), 'Gallery retrieved');
    }

    public function documents(): void
    {
        $cat = $this->request->get('category');
        $m = new Document();
        $this->success($m->allActive($cat), 'Documents retrieved');
    }

    public function partners(): void
    {
        $m = new Partner();
        $this->success($m->allActive(), 'Partners retrieved');
    }

    public function settings(): void
    {
        $m = new Setting();
        $all = $m->allAssoc();

        // Strip sensitive keys from public API
        unset($all['telegram_bot_token'], $all['telegram_chat_id']);

        $this->success($all, 'Settings retrieved');
    }
}

