<?php
declare(strict_types=1);

namespace Api;

use Models\Message;
use Services\UploadService;
use Services\TelegramService;

class ReceptionApiController extends ApiController
{
    public function submit(): void
    {
        $fullName = trim((string)$this->request->input('full_name'));
        $phone = trim((string)$this->request->input('phone'));
        $email = trim((string)$this->request->input('email', ''));
        $address = trim((string)$this->request->input('address', ''));
        $type = trim((string)$this->request->input('inquiry_type', 'murojaat'));
        $subject = trim((string)$this->request->input('subject'));
        $message = trim((string)$this->request->input('message'));

        if (empty($fullName) || empty($phone) || empty($subject) || empty($message)) {
            $this->error('Barcha majburiy maydonlarni to\'ldiring', 422);
            return;
        }

        $attachmentPath = null;
        if ($this->request->hasFile('attachment')) {
            try {
                $attachmentPath = UploadService::uploadDocument($this->request->file('attachment'), 'reception');
            } catch (\Throwable $e) {
                $this->error('Fayl yuklashda xatolik: ' . $e->getMessage(), 400);
                return;
            }
        }

        $code = Message::generateTrackingCode();
        $messageModel = new Message();

        $data = [
            'tracking_code' => $code,
            'full_name' => $fullName,
            'phone' => $phone,
            'email' => $email,
            'address' => $address,
            'inquiry_type' => in_array($type, ['murojaat', 'taklif', 'shikoyat', 'ariza'], true) ? $type : 'murojaat',
            'subject' => $subject,
            'message' => $message,
            'attachment_file' => $attachmentPath,
            'status' => 'NEW',
            'ip_address' => $this->request->ip()
        ];

        $id = $messageModel->create($data);
        TelegramService::notifyInquiry($data);

        $this->success([
            'id' => $id,
            'tracking_code' => $code,
            'status' => 'NEW'
        ], 'Murojaatingiz muvaffaqiyatli yuborildi', [], 201);
    }

    public function status(): void
    {
        $code = trim((string)$this->request->get('code', ''));
        if (empty($code)) {
            $this->error('Murojaat kodi kiritilishi shart', 422);
            return;
        }

        $messageModel = new Message();
        $message = $messageModel->findByTrackingCode($code);

        if (!$message) {
            $this->error('Bunday kodli murojaat topilmadi', 404);
            return;
        }

        $this->success($message, 'Murojaat holati topildi');
    }
}

