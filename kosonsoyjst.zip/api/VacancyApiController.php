<?php
declare(strict_types=1);

namespace Api;

use Models\Vacancy;
use Models\Application;
use Services\UploadService;
use Services\TelegramService;

class VacancyApiController extends ApiController
{
    public function index(): void
    {
        $vacancyModel = new Vacancy();
        $this->success($vacancyModel->allActive(), 'Vacancies retrieved');
    }

    public function show(int $id): void
    {
        $vacancyModel = new Vacancy();
        $item = $vacancyModel->find($id);

        if (!$item || $item['is_active'] != 1) {
            $this->error('Vacancy not found or inactive', 404);
            return;
        }

        $this->success($item, 'Vacancy details retrieved');
    }

    public function apply(int $id): void
    {
        $vacancyModel = new Vacancy();
        $vacancy = $vacancyModel->find($id);

        if (!$vacancy || $vacancy['is_active'] != 1) {
            $this->error('Vacancy not found or inactive', 404);
            return;
        }

        $fullName = trim((string)$this->request->input('full_name'));
        $phone = trim((string)$this->request->input('phone'));
        $email = trim((string)$this->request->input('email'));
        $message = trim((string)$this->request->input('message', ''));

        if (empty($fullName) || empty($phone) || empty($email)) {
            $this->error('Maydonlarni to\'liq to\'ldiring (F.I.Sh, telefon, email)', 422);
            return;
        }

        if (!$this->request->hasFile('cv_file')) {
            $this->error('Rezyume (CV) faylini yuklash shart', 422);
            return;
        }

        try {
            $cvPath = UploadService::uploadCV($this->request->file('cv_file'), 'cv');

            $appModel = new Application();
            $data = [
                'vacancy_id' => $id,
                'full_name' => $fullName,
                'phone' => $phone,
                'email' => $email,
                'message' => $message,
                'cv_file' => $cvPath,
                'status' => 'NEW'
            ];

            $appId = $appModel->create($data);

            TelegramService::notifyApplication($data, t($vacancy, 'title'));

            $this->success(['application_id' => $appId], 'Arizangiz muvaffaqiyatli topshirildi', [], 201);
        } catch (\Throwable $e) {
            $this->error('Xatolik: ' . $e->getMessage(), 400);
        }
    }
}

