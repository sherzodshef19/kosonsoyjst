<?php
declare(strict_types=1);

namespace Api;

use Models\News;
use Models\Category;

class NewsApiController extends ApiController
{
    public function index(): void
    {
        $page = (int)$this->request->get('page', 1);
        $perPage = min(50, max(1, (int)$this->request->get('per_page', 9)));
        $catId = $this->request->get('category_id') ? (int)$this->request->get('category_id') : null;
        $search = $this->request->get('search');

        $newsModel = new News();
        $result = $newsModel->paginateWithDetails($page, $perPage, $catId, $search);

        $this->success($result['data'], 'News retrieved successfully', [
            'current_page' => $result['current_page'],
            'per_page' => $result['per_page'],
            'total' => $result['total'],
            'total_pages' => $result['total_pages']
        ]);
    }

    public function show($idOrSlug): void
    {
        $newsModel = new News();
        if (is_numeric($idOrSlug)) {
            $item = $newsModel->find((int)$idOrSlug);
        } else {
            $item = $newsModel->findBySlug((string)$idOrSlug);
        }

        if (!$item || $item['status'] !== 'published') {
            $this->error('News article not found', 404);
            return;
        }

        $newsModel->incrementViews((int)$item['id']);
        $item['gallery'] = $newsModel->getGallery((int)$item['id']);
        $item['tags'] = $newsModel->getTags((int)$item['id']);

        $this->success($item, 'News details retrieved');
    }

    public function categories(): void
    {
        $catModel = new Category();
        $this->success($catModel->allWithCount(), 'Categories retrieved');
    }
}

