<!DOCTYPE html>
<html lang="<?= current_lang() ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title ?? setting('meta_title_default', 'Kosonsoy Kolleji - Rasmiy veb-sayti')) ?></title>
    
    <!-- Favicon & Icons -->
    <link rel="icon" type="image/png" sizes="32x32" href="<?= asset('/assets/images/favicon-32x32.png') ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?= asset('/assets/images/favicon-16x16.png') ?>">
    <link rel="shortcut icon" href="<?= asset('/favicon.ico') ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?= asset('/assets/images/apple-touch-icon.png') ?>">

    <!-- Meta SEO -->
    <meta name="description" content="<?= e($meta_description ?? setting('meta_desc_default', 'Kosonsoy Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumi rasmiy veb-portali.')) ?>">
    <meta name="keywords" content="<?= e(setting('meta_keywords_default', 'Kosonsoy JST, Abu Ali ibn Sino, tibbiyot texnikumi, qabul 2026')) ?>">
    <meta name="author" content="Kosonsoy Abu Ali ibn Sino nomidagi JST">
    
    <!-- Open Graph -->
    <meta property="og:title" content="<?= e($title ?? setting('site_name', 'Kosonsoy Abu Ali ibn Sino nomidagi JST')) ?>">
    <meta property="og:description" content="<?= e($meta_description ?? setting('meta_desc_default', 'Kosonsoy Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumi rasmiy axborot portali.')) ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?= url($_SERVER['REQUEST_URI'] ?? '/') ?>">
    <meta property="og:image" content="<?= asset('/assets/images/logo.png') ?>">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Bootstrap 5.3 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Bootstrap Icons CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= asset('/assets/css/loader.css') ?>">
    <link rel="stylesheet" href="<?= asset('/assets/css/style.css') ?>">
</head>
<body>

    <!-- Global Loader -->
    <?php include __DIR__ . '/loader.php'; ?>

    <!-- Header Navigation -->
    <?php include __DIR__ . '/header.php'; ?>

    <!-- Flash Alerts Container -->
    <div class="container mt-3">
        <?php if (has_flash('success')): ?>
            <div class="alert alert-success alert-dismissible fade show shadow-sm border-0 d-flex align-items-center gap-2" role="alert">
                <i class="bi bi-check-circle-fill fs-5 text-success"></i>
                <div><?= e(flash('success')) ?></div>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (has_flash('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show shadow-sm border-0 d-flex align-items-center gap-2" role="alert">
                <i class="bi bi-exclamation-triangle-fill fs-5 text-danger"></i>
                <div><?= e(flash('error')) ?></div>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
    </div>

    <!-- Main Dynamic Content -->
    <main>
        <?= $content ?>
    </main>

    <!-- Footer -->
    <?php include __DIR__ . '/footer.php'; ?>

    <!-- Vue 3 Global CDN -->
    <script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
    <!-- Bootstrap 5.3 JS Bundle CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <!-- Custom JS -->
    <script src="<?= asset('/assets/js/loader.js') ?>"></script>
    <script src="<?= asset('/assets/js/app.js') ?>"></script>
</body>
</html>

