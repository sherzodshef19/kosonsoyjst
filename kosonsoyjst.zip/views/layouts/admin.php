<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title ?? 'Admin Panel') ?> - Kosonsoy Abu Ali ibn Sino nomidagi JST</title>

    <!-- Favicon & Icons -->
    <link rel="icon" type="image/png" sizes="32x32" href="<?= asset('/assets/images/favicon-32x32.png') ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?= asset('/assets/images/favicon-16x16.png') ?>">
    <link rel="shortcut icon" href="<?= asset('/favicon.ico') ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?= asset('/assets/images/apple-touch-icon.png') ?>">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Bootstrap 5.3 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Admin CSS -->
    <link rel="stylesheet" href="<?= asset('/assets/css/loader.css') ?>">
    <link rel="stylesheet" href="<?= asset('/assets/css/admin.css') ?>">
</head>
<body class="admin-body">

    <!-- Top progress bar -->
    <div id="top-progress-bar"></div>

    <!-- Mobile Sidebar Backdrop Overlay -->
    <div id="sidebar-overlay" class="position-fixed top-0 start-0 w-100 h-100 bg-dark bg-opacity-50 z-3 d-none"></div>

    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="admin-sidebar">
            <div class="sidebar-brand">
                <img src="<?= asset('/assets/images/logo.png') ?>" alt="Logo" class="rounded-circle shadow-sm" style="width: 40px; height: 40px; object-fit: contain;">
                <div>
                    <a href="<?= url('/admin') ?>">KOSONSOY JST</a>
                    <span class="d-block text-secondary small" style="font-size: 0.7rem;">ADMINISTRATION</span>
                </div>
            </div>

            <div class="sidebar-nav">
                <a href="<?= url('/admin') ?>" class="sidebar-nav-item <?= $_SERVER['REQUEST_URI'] === '/admin' ? 'active' : '' ?>">
                    <i class="bi bi-grid-fill"></i>
                    <span>Boshqaruv paneli</span>
                </a>

                <div class="sidebar-section-title">Kontent Boshqaruvi</div>
                <?php if (can('news.view')): ?>
                <a href="<?= url('/admin/news') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/news') !== false ? 'active' : '' ?>">
                    <i class="bi bi-newspaper"></i>
                    <span>Yangiliklar</span>
                </a>
                <?php endif; ?>

                <?php if (can('categories.manage')): ?>
                <a href="<?= url('/admin/categories') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/categories') !== false ? 'active' : '' ?>">
                    <i class="bi bi-tags-fill"></i>
                    <span>Kategoriyalar</span>
                </a>
                <?php endif; ?>

                <?php if (can('banners.manage')): ?>
                <a href="<?= url('/admin/banners') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/banners') !== false ? 'active' : '' ?>">
                    <i class="bi bi-images"></i>
                    <span>Bosh sahifa slayderi</span>
                </a>
                <?php endif; ?>

                <?php if (can('gallery.manage')): ?>
                <a href="<?= url('/admin/gallery') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/gallery') !== false ? 'active' : '' ?>">
                    <i class="bi bi-camera-fill"></i>
                    <span>Fotogalereya</span>
                </a>
                <?php endif; ?>

                <?php if (can('pages.manage')): ?>
                <a href="<?= url('/admin/pages') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/pages') !== false ? 'active' : '' ?>">
                    <i class="bi bi-file-earmark-richtext"></i>
                    <span>Sahifalar</span>
                </a>
                <?php endif; ?>

                <?php if (can('menus.manage')): ?>
                <a href="<?= url('/admin/menus') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/menus') !== false ? 'active' : '' ?>">
                    <i class="bi bi-menu-button-wide"></i>
                    <span>Menyular</span>
                </a>
                <?php endif; ?>

                <?php if (can('documents.manage')): ?>
                <a href="<?= url('/admin/documents') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/documents') !== false ? 'active' : '' ?>">
                    <i class="bi bi-file-earmark-pdf-fill"></i>
                    <span>Rasmiy hujjatlar</span>
                </a>
                <?php endif; ?>

                <?php if (can('programs.manage')): ?>
                <a href="<?= url('/admin/programs') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/programs') !== false ? 'active' : '' ?>">
                    <i class="bi bi-mortarboard-fill"></i>
                    <span>Ta'lim yo'nalishlari</span>
                </a>
                <?php endif; ?>

                <div class="sidebar-section-title">Muassasa & Xodimlar</div>
                <?php if (can('management.manage')): ?>
                <a href="<?= url('/admin/management') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/management') !== false ? 'active' : '' ?>">
                    <i class="bi bi-person-lines-fill"></i>
                    <span>Rahbariyat</span>
                </a>
                <?php endif; ?>

                <?php if (can('employees.manage')): ?>
                <a href="<?= url('/admin/employees') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/employees') !== false ? 'active' : '' ?>">
                    <i class="bi bi-people-fill"></i>
                    <span>Xodimlar & Ustozlar</span>
                </a>
                <?php endif; ?>

                <?php if (can('statistics.manage')): ?>
                <a href="<?= url('/admin/statistics') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/statistics') !== false ? 'active' : '' ?>">
                    <i class="bi bi-bar-chart-line-fill"></i>
                    <span>Statistika</span>
                </a>
                <?php endif; ?>

                <?php if (can('partners.manage')): ?>
                <a href="<?= url('/admin/partners') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/partners') !== false ? 'active' : '' ?>">
                    <i class="bi bi-building"></i>
                    <span>Hamkorlar</span>
                </a>
                <?php endif; ?>

                <div class="sidebar-section-title">Arizalar & Murojaatlar</div>
                <?php if (can('messages.manage')): ?>
                <a href="<?= url('/admin/messages') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/messages') !== false ? 'active' : '' ?>">
                    <i class="bi bi-envelope-paper-fill"></i>
                    <span>Virtual qabulxona</span>
                </a>
                <?php endif; ?>

                <?php if (can('vacancies.manage')): ?>
                <a href="<?= url('/admin/vacancies') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/vacancies') !== false ? 'active' : '' ?>">
                    <i class="bi bi-briefcase-fill"></i>
                    <span>Vakansiyalar</span>
                </a>
                <?php endif; ?>

                <?php if (can('applications.manage')): ?>
                <a href="<?= url('/admin/applications') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/applications') !== false ? 'active' : '' ?>">
                    <i class="bi bi-file-earmark-person-fill"></i>
                    <span>Nomzodlar arizalari</span>
                </a>
                <?php endif; ?>

                <div class="sidebar-section-title">Tizim Sozlamalari</div>
                <?php if (can('media.manage')): ?>
                <a href="<?= url('/admin/media') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/media') !== false ? 'active' : '' ?>">
                    <i class="bi bi-folder2-open"></i>
                    <span>Media kutubxona</span>
                </a>
                <?php endif; ?>

                <?php if (can('users.manage')): ?>
                <a href="<?= url('/admin/users') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/users') !== false ? 'active' : '' ?>">
                    <i class="bi bi-person-fill-gear"></i>
                    <span>Foydalanuvchilar</span>
                </a>
                <?php endif; ?>

                <?php if (can('roles.manage')): ?>
                <a href="<?= url('/admin/roles') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/roles') !== false ? 'active' : '' ?>">
                    <i class="bi bi-shield-check"></i>
                    <span>Rollar va ruxsatlar</span>
                </a>
                <?php endif; ?>

                <?php if (can('settings.manage')): ?>
                <a href="<?= url('/admin/settings') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/settings') !== false ? 'active' : '' ?>">
                    <i class="bi bi-sliders"></i>
                    <span>Sayt sozlamalari</span>
                </a>
                <?php endif; ?>

                <?php if (can('audit_logs.view')): ?>
                <a href="<?= url('/admin/audit-logs') ?>" class="sidebar-nav-item <?= strpos($_SERVER['REQUEST_URI'], '/admin/audit-logs') !== false ? 'active' : '' ?>">
                    <i class="bi bi-clock-history"></i>
                    <span>Audit jurnali</span>
                </a>
                <?php endif; ?>
            </div>

            <div class="sidebar-footer">
                <div>Foydalanuvchi: <strong><?= e(auth()['full_name'] ?? 'Admin') ?></strong></div>
                <div class="text-warning small"><?= e(auth()['role_name'] ?? 'Admin') ?></div>
            </div>
        </aside>

        <!-- Main Body -->
        <div class="admin-main">
            <!-- Topbar -->
            <header class="admin-topbar">
                <div class="d-flex align-items-center gap-3">
                    <button class="btn btn-sm btn-outline-secondary d-lg-none" id="sidebar-toggle-btn">
                        <i class="bi bi-list fs-5"></i>
                    </button>
                    <a href="<?= url('/') ?>" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill d-flex align-items-center gap-2">
                        <i class="bi bi-box-arrow-up-right"></i>
                        <span class="d-none d-sm-inline">Saytni ko'rish</span>
                    </a>
                </div>

                <div class="d-flex align-items-center gap-3">
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center gap-2 text-decoration-none dropdown-toggle text-dark" data-bs-toggle="dropdown">
                            <img src="<?= asset(auth()['avatar'] ?: '/assets/images/avatar-default.png') ?>" alt="Avatar" class="rounded-circle border shadow-sm" style="width: 36px; height: 36px; object-fit: cover;" onerror="this.onerror=null;this.src='<?= asset('/assets/images/avatar-default.png') ?>';">
                            <div class="d-none d-md-block text-start">
                                <span class="d-block fw-bold small"><?= e(auth()['full_name'] ?? 'Admin') ?></span>
                                <span class="d-block text-muted" style="font-size: 0.72rem;"><?= e(auth()['role_name'] ?? 'Role') ?></span>
                            </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                            <li><a class="dropdown-item" href="<?= url('/admin/profile') ?>"><i class="bi bi-person me-2"></i> Profil sozlamalari</a></li>
                            <?php if (can('settings.manage')): ?>
                            <li><a class="dropdown-item" href="<?= url('/admin/settings') ?>"><i class="bi bi-gear me-2"></i> Tizim sozlamalari</a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="<?= url('/admin/logout') ?>"><i class="bi bi-box-arrow-right me-2"></i> Chiqish</a></li>
                        </ul>
                    </div>
                </div>
            </header>

            <!-- Admin Content Container -->
            <main class="admin-content">
                <!-- Flash Alerts -->
                <?php if (has_flash('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show shadow-sm border-0 d-flex align-items-center gap-2" role="alert">
                        <i class="bi bi-check-circle-fill fs-5 text-success"></i>
                        <div><?= e(flash('success')) ?></div>
                        <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if (has_flash('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show shadow-sm border-0 d-flex align-items-center gap-2" role="alert">
                        <i class="bi bi-exclamation-triangle-fill fs-5 text-danger"></i>
                        <div><?= e(flash('error')) ?></div>
                        <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?= $content ?>
            </main>
        </div>
    </div>

    <!-- Vue 3 Global CDN -->
    <script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
    <!-- Bootstrap 5.3 JS Bundle CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom Admin JS -->
    <script src="<?= asset('/assets/js/loader.js') ?>"></script>
    <script src="<?= asset('/assets/js/admin.js') ?>"></script>
</body>
</html>

