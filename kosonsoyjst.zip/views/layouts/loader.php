<!-- Global Initial Page Loader -->
<div id="page-loader">
    <div class="loader-logo-wrap mb-3 position-relative">
        <div class="loader-spinner"></div>
        <img src="<?= asset('/assets/images/logo.png') ?>" alt="Logo" class="loader-seal-img">
    </div>
    <div class="loader-brand">
        <span><?= trans('brand_abbr') ?></span>
    </div>
    <div class="loader-sub"><?= trans('institution_name') ?></div>
</div>

<!-- Global Top Progress Bar (AJAX & Transitions) -->
<div id="top-progress-bar"></div>

