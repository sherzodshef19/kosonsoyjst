<?php
$currentLang = current_lang();
$locales = config('app.locales', [
    'uz' => ['name' => "O'zbekcha", 'flag' => '🇺🇿'],
    'ru' => ['name' => 'Русский', 'flag' => '🇷🇺'],
    'en' => ['name' => 'English', 'flag' => '🇬🇧']
]);
?>

<!-- Topbar -->
<div class="site-topbar d-none d-md-block">
    <div class="container-fluid px-3 px-xl-4 max-w-1440">
        <div class="d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-4">
                <span class="hotline-badge">
                    <i class="bi bi-telephone-inbound-fill me-1"></i> <?= trans('hotline') ?>: <?= e(setting('site_hotline', '1103')) ?>
                </span>
                <span>
                    <i class="bi bi-clock me-1 text-warning"></i> <?= e(setting('working_hours', 'Dushanba - Shanba: 08:30 - 17:30')) ?>
                </span>
                <span>
                    <i class="bi bi-geo-alt me-1 text-danger"></i> <?= e(setting('site_address', "Namangan viloyati, Kosonsoy tumani, Tibbiyot ko'chasi, 12-uy")) ?>
                </span>
            </div>
            <div class="d-flex align-items-center gap-3">
                <!-- Social links -->
                <div class="d-flex gap-2">
                    <?php if (setting('telegram_channel')): ?>
                        <a href="<?= e(setting('telegram_channel')) ?>" target="_blank" title="Telegram"><i class="bi bi-telegram"></i></a>
                    <?php endif; ?>
                    <?php if (setting('instagram_url')): ?>
                        <a href="<?= e(setting('instagram_url')) ?>" target="_blank" title="Instagram"><i class="bi bi-instagram"></i></a>
                    <?php endif; ?>
                    <?php if (setting('facebook_url')): ?>
                        <a href="<?= e(setting('facebook_url')) ?>" target="_blank" title="Facebook"><i class="bi bi-facebook"></i></a>
                    <?php endif; ?>
                </div>

                <!-- Language Switcher -->
                <div class="dropdown">
                    <button class="btn btn-sm btn-outline-light dropdown-toggle py-1 px-3 rounded-pill d-inline-flex align-items-center gap-1" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-globe2 text-warning me-1"></i>
                        <span class="fw-semibold"><?= e($locales[$currentLang]['name'] ?? "O'zbekcha") ?></span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 rounded-3 p-1 mt-2">
                        <?php foreach ($locales as $code => $loc): ?>
                            <li>
                                <a class="dropdown-item d-flex align-items-center justify-content-between py-2 px-3 rounded-2 <?= $currentLang === $code ? 'active fw-bold' : '' ?>" href="<?= url('/lang/' . $code) ?>">
                                    <span class="d-flex align-items-center gap-2">
                                        <span class="badge <?= $code === 'uz' ? 'bg-primary' : ($code === 'ru' ? 'bg-danger' : 'bg-success') ?> rounded-pill px-2 py-1 text-uppercase" style="font-size: 0.68rem;"><?= $code ?></span>
                                        <span><?= e($loc['name']) ?></span>
                                    </span>
                                    <?php if ($currentLang === $code): ?>
                                        <i class="bi bi-check-lg text-primary ms-2"></i>
                                    <?php endif; ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Main Sticky Navbar -->
<nav class="navbar navbar-expand-xl site-navbar sticky-top">
    <div class="container-fluid px-3 px-xl-4 max-w-1440">
        <!-- Official Crest & Brand -->
        <a class="navbar-brand d-flex align-items-center gap-2 text-decoration-none" href="<?= url('/') ?>">
            <div class="brand-crest">
                <img src="<?= asset('/assets/images/logo.png') ?>" alt="Logo" class="brand-crest-img">
            </div>
            <div class="brand-text-block">
                <span class="brand-name-abbr"><?= trans('brand_abbr') ?></span>
                <span class="brand-name-full"><?= trans('institution_name') ?></span>
                <span class="brand-region-badge"><i class="bi bi-geo-alt-fill text-danger me-1"></i><?= trans('region') ?> · <?= trans('district') ?></span>
            </div>
        </a>

        <!-- Mobile Menu Toggle Button -->
        <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarMain">
            <ul class="navbar-nav ms-auto me-xl-3 mb-2 mb-xl-0 align-items-xl-center">
                <li class="nav-item">
                    <a class="nav-link <?= ($_SERVER['REQUEST_URI'] == '/' || $_SERVER['REQUEST_URI'] == '/index.php') ? 'active' : '' ?>" href="<?= url('/') ?>">
                        <?= trans('home') ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/about') !== false ? 'active' : '' ?>" href="<?= url('/about') ?>">
                        <?= trans('about_us') ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/news') !== false ? 'active' : '' ?>" href="<?= url('/news') ?>">
                        <?= trans('news') ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/management') !== false ? 'active' : '' ?>" href="<?= url('/management') ?>">
                        <?= trans('management') ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/statistics') !== false ? 'active' : '' ?>" href="<?= url('/statistics') ?>">
                        <?= trans('statistics') ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/vacancies') !== false ? 'active' : '' ?>" href="<?= url('/vacancies') ?>">
                        <?= trans('vacancies') ?>
                    </a>
                </li>

                <!-- Dropdown Menu for Documents & Gallery -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?= (strpos($_SERVER['REQUEST_URI'], '/documents') !== false || strpos($_SERVER['REQUEST_URI'], '/gallery') !== false) ? 'active' : '' ?>" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <span><?= trans('docs_and_gallery') ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 rounded-3 p-2">
                        <li>
                            <a class="dropdown-item py-2 px-3 rounded-2 <?= strpos($_SERVER['REQUEST_URI'], '/documents') !== false ? 'active' : '' ?>" href="<?= url('/documents') ?>">
                                <i class="bi bi-file-earmark-medical-fill text-primary me-2"></i> <?= trans('documents') ?>
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item py-2 px-3 rounded-2 <?= strpos($_SERVER['REQUEST_URI'], '/gallery') !== false ? 'active' : '' ?>" href="<?= url('/gallery') ?>">
                                <i class="bi bi-images text-warning me-2"></i> <?= trans('gallery') ?>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>

            <div class="d-flex align-items-center mt-3 mt-xl-0">
                <!-- Virtual Reception Button -->
                <a href="<?= url('/reception') ?>" class="btn btn-nav-reception">
                    <i class="bi bi-chat-heart-fill"></i>
                    <span><?= trans('virtual_reception') ?></span>
                </a>
            </div>
        </div>
    </div>
</nav>

