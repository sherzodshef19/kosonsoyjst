<!-- Public Footer -->
<footer class="site-footer">
    <div class="container">
        <div class="row g-4">
            <!-- Col 1: About & Emblem -->
            <div class="col-lg-4 col-md-6">
                <div class="d-flex align-items-center gap-3 mb-3">
                    <img src="<?= asset('/assets/images/logo.png') ?>" alt="Logo" class="rounded-circle shadow-sm" style="width: 52px; height: 52px; object-fit: contain; filter: drop-shadow(0 2px 8px rgba(0,0,0,0.3));">
                    <div>
                        <h4 class="text-white mb-0 fw-bold fs-5"><?= e(setting('site_name', 'Kosonsoy Abu Ali ibn Sino nomidagi JST')) ?></h4>
                        <small class="text-warning"><i class="bi bi-geo-alt-fill me-1"></i><?= trans('region') ?> · <?= trans('district') ?></small>
                    </div>
                </div>
                <p class="small pe-lg-3 lh-base mb-0" style="color: #cbd5e1;">
                    <?= e(setting('site_tagline', "Abu Ali ibn Sino ilmiy merosi asosida zamonaviy tibbiyot, jamoat salomatligi va farmatsevtika yo'nalishlarida yetuk mutaxassislar tayyorlash maskani.")) ?>
                </p>
                <div class="d-flex gap-2 mt-4">
                    <?php if (setting('telegram_channel') || setting('telegram_url')): ?>
                        <a href="<?= e(setting('telegram_channel') ?: setting('telegram_url')) ?>" target="_blank" class="footer-social-btn btn-telegram" title="Telegram" aria-label="Telegram"><i class="bi bi-telegram"></i></a>
                    <?php endif; ?>
                    <?php if (setting('instagram_url')): ?>
                        <a href="<?= e(setting('instagram_url')) ?>" target="_blank" class="footer-social-btn btn-instagram" title="Instagram" aria-label="Instagram"><i class="bi bi-instagram"></i></a>
                    <?php endif; ?>
                    <?php if (setting('facebook_url')): ?>
                        <a href="<?= e(setting('facebook_url')) ?>" target="_blank" class="footer-social-btn btn-facebook" title="Facebook" aria-label="Facebook"><i class="bi bi-facebook"></i></a>
                    <?php endif; ?>
                    <?php if (setting('youtube_url')): ?>
                        <a href="<?= e(setting('youtube_url')) ?>" target="_blank" class="footer-social-btn btn-youtube" title="YouTube" aria-label="YouTube"><i class="bi bi-youtube"></i></a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Col 2: Quick Links -->
            <div class="col-lg-2 col-md-6">
                <h5><?= trans('quick_links') ?></h5>
                <ul class="list-unstyled mb-0 d-flex flex-column gap-2 small">
                    <li><a href="<?= url('/') ?>"><i class="bi bi-chevron-right me-1 text-warning"></i> <?= trans('home') ?></a></li>
                    <li><a href="<?= url('/about') ?>"><i class="bi bi-chevron-right me-1 text-warning"></i> <?= trans('about_us') ?></a></li>
                    <li><a href="<?= url('/news') ?>"><i class="bi bi-chevron-right me-1 text-warning"></i> <?= trans('news') ?></a></li>
                    <li><a href="<?= url('/management') ?>"><i class="bi bi-chevron-right me-1 text-warning"></i> <?= trans('management') ?></a></li>
                    <li><a href="<?= url('/statistics') ?>"><i class="bi bi-chevron-right me-1 text-warning"></i> <?= trans('statistics') ?></a></li>
                    <li><a href="<?= url('/vacancies') ?>"><i class="bi bi-chevron-right me-1 text-warning"></i> <?= trans('vacancies') ?></a></li>
                </ul>
            </div>

            <!-- Col 3: Virtual Reception & Documents -->
            <div class="col-lg-3 col-md-6">
                <h5>Xizmatlar va Portal</h5>
                <ul class="list-unstyled mb-0 d-flex flex-column gap-2 small">
                    <li><a href="<?= url('/reception') ?>"><i class="bi bi-chat-dots-fill me-1 text-warning"></i> <?= trans('virtual_reception') ?></a></li>
                    <li><a href="<?= url('/reception/check') ?>"><i class="bi bi-search me-1 text-warning"></i> <?= trans('check_status') ?></a></li>
                    <li><a href="<?= url('/documents') ?>"><i class="bi bi-file-earmark-pdf me-1 text-warning"></i> <?= trans('documents') ?></a></li>
                    <li><a href="<?= url('/gallery') ?>"><i class="bi bi-images me-1 text-warning"></i> <?= trans('gallery') ?></a></li>
                    <li><a href="https://gov.uz" target="_blank"><i class="bi bi-globe me-1 text-warning"></i> Gov.uz Portali</a></li>
                    <li><a href="https://my.gov.uz" target="_blank"><i class="bi bi-box-arrow-up-right me-1 text-warning"></i> Yagona portal (My.gov.uz)</a></li>
                </ul>
            </div>

            <!-- Col 4: Contacts & Admin -->
            <div class="col-lg-3 col-md-6">
                <h5><?= trans('contact') ?></h5>
                <ul class="list-unstyled mb-0 d-flex flex-column gap-3 small">
                    <li class="d-flex align-items-start gap-2">
                        <i class="bi bi-geo-alt-fill text-warning mt-1"></i>
                        <span><?= e(setting('site_address', "Kosonsoy tumani, Mustaqillik ko'chasi, 45-uy")) ?></span>
                    </li>
                    <li class="d-flex align-items-center gap-2">
                        <i class="bi bi-telephone-fill text-warning"></i>
                        <span><?= e(setting('site_phone', "+998 (69) 652-12-34")) ?></span>
                    </li>
                    <li class="d-flex align-items-center gap-2">
                        <i class="bi bi-envelope-fill text-warning"></i>
                        <span><?= e(setting('site_email', "info@kosonsoykollej.uz")) ?></span>
                    </li>
                </ul>
            </div>
        </div>

        <div class="footer-bottom d-flex flex-column flex-md-row justify-content-between align-items-center text-center text-md-start">
            <p class="mb-2 mb-md-0 footer-copyright">
                &copy; <?= date('Y') ?> <strong class="text-white"><?= e(setting('site_name', 'Kosonsoy Abu Ali ibn Sino nomidagi JST')) ?></strong>. Barcha huquqlar himoyalangan.
            </p>
            <div class="footer-version small">
                <span>Versiya 2.0 | Xavfsiz ta'lim axborot tizimi</span>
            </div>
        </div>
    </div>
</footer>

<!-- Back to top button -->
<a href="#" id="back-to-top" title="Yuqoriga qaytish">
    <i class="bi bi-arrow-up"></i>
</a>

