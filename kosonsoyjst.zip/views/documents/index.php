<div class="py-5 bg-white border-bottom">
    <div class="container text-center">
        <span class="section-tag"><?= trans('documents') ?></span>
        <h1 class="fw-bold text-dark">Rasmiy va Me'yoriy Hujjatlar</h1>
        <p class="text-muted mx-auto" style="max-width: 650px;">
            Kosonsoy Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumi faoliyatini tartibga soluvchi davlat qonunlari, qarorlar, ustav va litsenziyalar
        </p>

        <!-- Category filter -->
        <div class="d-flex justify-content-center gap-2 flex-wrap mt-4">
            <a href="<?= url('/documents') ?>" class="btn btn-sm rounded-pill <?= empty($currentCat) ? 'btn-primary' : 'btn-outline-secondary' ?>">
                Barchasi
            </a>
            <a href="<?= url('/documents?cat=college_charter') ?>" class="btn btn-sm rounded-pill <?= ($currentCat === 'college_charter') ? 'btn-primary' : 'btn-outline-secondary' ?>">
                Texnikum Ustavi
            </a>
            <a href="<?= url('/documents?cat=license') ?>" class="btn btn-sm rounded-pill <?= ($currentCat === 'license') ? 'btn-primary' : 'btn-outline-secondary' ?>">
                Davlat Litsenziyasi
            </a>
            <a href="<?= url('/documents?cat=law') ?>" class="btn btn-sm rounded-pill <?= ($currentCat === 'law') ? 'btn-primary' : 'btn-outline-secondary' ?>">
                Qonunlar
            </a>
            <a href="<?= url('/documents?cat=decree') ?>" class="btn btn-sm rounded-pill <?= ($currentCat === 'decree') ? 'btn-primary' : 'btn-outline-secondary' ?>">
                Qarorlar
            </a>
        </div>
    </div>
</div>

<div class="section-padding">
    <div class="container">
        <?php if (empty($documents)): ?>
            <div class="text-center py-5">
                <i class="bi bi-file-earmark-x fs-1 text-muted d-block mb-3"></i>
                <h4 class="text-muted"><?= trans('no_records') ?></h4>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach ($documents as $doc): ?>
                    <div class="col-lg-6">
                        <div class="bg-white p-4 rounded-4 border shadow-sm h-100 d-flex align-items-center justify-content-between gap-3">
                            <div class="d-flex align-items-center gap-3">
                                <div class="bg-danger bg-opacity-10 text-danger p-3 rounded-3 fs-2">
                                    <i class="bi bi-file-earmark-pdf-fill"></i>
                                </div>
                                <div>
                                    <span class="badge bg-light text-secondary border small mb-1">
                                        <?= e(strtoupper($doc['category'])) ?> <?= !empty($doc['doc_number']) ? ' - ' . e($doc['doc_number']) : '' ?>
                                    </span>
                                    <h5 class="fw-bold mb-1 fs-6">
                                        <?= e(t($doc, 'title')) ?>
                                    </h5>
                                    <div class="text-muted small">
                                        <span><i class="bi bi-calendar3 me-1"></i> <?= $doc['doc_date'] ? format_date($doc['doc_date']) : '' ?></span>
                                        <span class="ms-3"><i class="bi bi-download me-1"></i> <?= (int)$doc['download_count'] ?> marta yuklangan</span>
                                    </div>
                                </div>
                            </div>

                            <a href="<?= url('/documents/download/' . $doc['id']) ?>" class="btn btn-primary-brand btn-sm rounded-pill px-3 flex-shrink-0">
                                <i class="bi bi-download me-1"></i> Yuklash
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

