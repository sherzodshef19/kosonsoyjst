<div class="py-4 bg-white border-bottom">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 small">
                <li class="breadcrumb-item"><a href="<?= url('/') ?>"><?= trans('home') ?></a></li>
                <li class="breadcrumb-item"><a href="<?= url('/news') ?>"><?= trans('news') ?></a></li>
                <li class="breadcrumb-item active text-truncate" style="max-width: 400px;"><?= e(t($news, 'title')) ?></li>
            </ol>
        </nav>
    </div>
</div>

<div class="section-padding">
    <div class="container">
        <div class="row g-5">
            <!-- Article Body -->
            <div class="col-lg-8">
                <article class="bg-white p-4 p-md-5 rounded-4 border shadow-sm">
                    <span class="badge bg-primary px-3 py-1 rounded-pill mb-3">
                        <?= e(t($news, 'cat_name', 'Yangilik')) ?>
                    </span>

                    <h1 class="fw-bold mb-3 fs-2 text-dark"><?= e(t($news, 'title')) ?></h1>

                    <div class="d-flex flex-wrap align-items-center gap-3 text-muted small pb-3 mb-4 border-bottom">
                        <span><i class="bi bi-calendar3 me-1 text-primary"></i> <?= format_date($news['published_at']) ?></span>
                        <span><i class="bi bi-person me-1 text-primary"></i> <?= e($news['author_name'] ?? 'Matbuot xizmati') ?></span>
                        <span><i class="bi bi-eye me-1 text-primary"></i> <?= (int)$news['views_count'] ?> <?= trans('views') ?></span>
                    </div>

                    <?php if (!empty($news['image'])): ?>
                        <div class="mb-4 rounded-4 overflow-hidden shadow-sm">
                            <img src="<?= asset($news['image']) ?>" alt="<?= e(t($news, 'title')) ?>" class="w-100" style="max-height: 480px; object-fit: cover;">
                        </div>
                    <?php endif; ?>

                    <!-- Content -->
                    <div class="news-full-content lh-lg fs-6 text-secondary mb-5">
                        <?= t($news, 'content') ?>
                    </div>

                    <!-- Gallery photos if attached -->
                    <?php if (!empty($gallery)): ?>
                        <div class="mt-4 pt-4 border-top">
                            <h4 class="fw-bold fs-5 mb-3"><i class="bi bi-images text-primary me-2"></i> Fotolavhalar</h4>
                            <div class="row g-3">
                                <?php foreach ($gallery as $img): ?>
                                    <div class="col-sm-6 col-md-4">
                                        <div class="rounded-3 overflow-hidden border shadow-sm">
                                            <img src="<?= asset($img['image_path']) ?>" alt="Foto" class="w-100" style="height: 180px; object-fit: cover;">
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Tags -->
                    <?php if (!empty($tags)): ?>
                        <div class="mt-4 pt-4 border-top d-flex align-items-center gap-2 flex-wrap">
                            <span class="fw-bold small text-dark"><i class="bi bi-tags-fill me-1"></i> Teglar:</span>
                            <?php foreach ($tags as $tag): ?>
                                <span class="badge bg-light text-dark border px-3 py-2 rounded-pill">
                                    #<?= e(t($tag, 'name')) ?>
                                </span>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <!-- Social Share -->
                    <div class="mt-4 pt-4 border-top d-flex flex-wrap align-items-center justify-content-between gap-3">
                        <span class="fw-bold text-dark"><i class="bi bi-share-fill me-2 text-primary"></i> <?= trans('share') ?>:</span>
                        <?php $shareUrl = urlencode(url($_SERVER['REQUEST_URI'])); $shareTitle = urlencode(t($news, 'title')); ?>
                        <div class="d-flex gap-2">
                            <a href="https://t.me/share/url?url=<?= $shareUrl ?>&text=<?= $shareTitle ?>" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill px-3">
                                <i class="bi bi-telegram me-1"></i> Telegram
                            </a>
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?= $shareUrl ?>" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill px-3">
                                <i class="bi bi-facebook me-1"></i> Facebook
                            </a>
                            <a href="https://api.whatsapp.com/send?text=<?= $shareTitle ?>%20<?= $shareUrl ?>" target="_blank" class="btn btn-sm btn-outline-success rounded-pill px-3">
                                <i class="bi bi-whatsapp me-1"></i> WhatsApp
                            </a>
                        </div>
                    </div>
                </article>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Related News -->
                <?php if (!empty($related)): ?>
                    <div class="bg-white p-4 rounded-4 border shadow-sm mb-4">
                        <h5 class="fw-bold mb-3 border-bottom pb-2">Mavzuga doir yangiliklar</h5>
                        <div class="d-flex flex-column gap-3">
                            <?php foreach ($related as $rel): ?>
                                <div class="d-flex gap-3 align-items-center">
                                    <?php if (!empty($rel['image'])): ?>
                                        <img src="<?= asset($rel['image']) ?>" alt="Rasm" class="rounded-3 flex-shrink-0" style="width: 75px; height: 60px; object-fit: cover;">
                                    <?php endif; ?>
                                    <div>
                                        <h6 class="mb-1 small fw-bold">
                                            <a href="<?= url('/news/' . $rel['slug']) ?>" class="text-dark text-decoration-none">
                                                <?= e(t($rel, 'title')) ?>
                                            </a>
                                        </h6>
                                        <span class="text-muted" style="font-size: 0.75rem;">
                                            <i class="bi bi-calendar3 me-1"></i> <?= format_date($rel['published_at']) ?>
                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Reception CTA Box -->
                <div class="bg-primary text-white p-4 rounded-4 shadow-sm" style="background: linear-gradient(135deg, #0b2545 0%, #133e87 100%);">
                    <h5 class="fw-bold mb-2 text-warning"><i class="bi bi-headset me-2"></i> Savolingiz bormi?</h5>
                    <p class="small text-light mb-3">
                        Texnikum rahbariyatiga o'z taklif, ariza yoki shikoyatingizni Virtual qabulxona orqali onlayn yuboring.
                    </p>
                    <a href="<?= url('/reception') ?>" class="btn btn-accent-brand btn-sm w-100">
                        Virtual qabulxonaga o'tish
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

