<div class="py-5 bg-white border-bottom">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-7">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-2 small">
                        <li class="breadcrumb-item"><a href="<?= url('/') ?>"><?= trans('home') ?></a></li>
                        <li class="breadcrumb-item active"><?= trans('news') ?></li>
                    </ol>
                </nav>
                <h1 class="fw-bold mb-0 text-dark"><?= trans('news') ?> va E'lonlar</h1>
            </div>
            <div class="col-md-5 mt-3 mt-md-0">
                <form action="<?= url('/news') ?>" method="GET">
                    <div class="input-group">
                        <input type="text" name="q" class="form-control" placeholder="<?= trans('search_placeholder') ?>" value="<?= e($searchQuery ?? '') ?>">
                        <button class="btn btn-primary" type="submit">
                            <i class="bi bi-search"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Category filter pills -->
        <div class="d-flex gap-2 flex-wrap mt-4">
            <a href="<?= url('/news') ?>" class="btn btn-sm rounded-pill <?= empty($currentCategory) ? 'btn-primary' : 'btn-outline-secondary' ?>">
                <?= trans('all_categories') ?>
            </a>
            <?php foreach ($categories as $cat): ?>
                <a href="<?= url('/news?category=' . $cat['id']) ?>" class="btn btn-sm rounded-pill <?= ($currentCategory == $cat['id']) ? 'btn-primary' : 'btn-outline-secondary' ?>">
                    <?= e(t($cat, 'name')) ?> <span class="badge bg-light text-dark ms-1"><?= (int)$cat['news_count'] ?></span>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<div class="section-padding">
    <div class="container">
        <?php if (empty($news)): ?>
            <div class="text-center py-5">
                <i class="bi bi-newspaper fs-1 text-muted d-block mb-3"></i>
                <h4 class="text-muted"><?= trans('no_records') ?></h4>
                <a href="<?= url('/news') ?>" class="btn btn-outline-primary btn-sm mt-3">Barcha yangiliklar</a>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach ($news as $item): ?>
                    <div class="col-lg-4 col-md-6">
                        <article class="news-card">
                            <div class="news-img-wrapper">
                                <img src="<?= asset($item['image'] ?: '/assets/images/news-default.jpg') ?>" alt="<?= e(t($item, 'title')) ?>" loading="lazy">
                                <span class="news-badge"><?= e(t($item, 'cat_name', 'Yangilik')) ?></span>
                            </div>
                            <div class="news-body">
                                <div class="news-meta">
                                    <span><i class="bi bi-calendar-event me-1"></i> <?= format_date($item['published_at']) ?></span>
                                    <span><i class="bi bi-eye me-1"></i> <?= (int)$item['views_count'] ?></span>
                                </div>
                                <h4 class="news-title">
                                    <a href="<?= url('/news/' . $item['slug']) ?>"><?= e(t($item, 'title')) ?></a>
                                </h4>
                                <p class="news-excerpt">
                                    <?= e(truncate_words(t($item, 'summary') ?: $item['content_uz'], 18)) ?>
                                </p>
                                <a href="<?= url('/news/' . $item['slug']) ?>" class="text-primary fw-bold small text-decoration-none mt-auto">
                                    <?= trans('read_more') ?> <i class="bi bi-arrow-right ms-1"></i>
                                </a>
                            </div>
                        </article>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <?php if ($pagination['total_pages'] > 1): ?>
                <nav class="mt-5 d-flex justify-content-center">
                    <ul class="pagination">
                        <?php if ($pagination['has_prev']): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?= url('/news?page=' . ($pagination['current_page'] - 1) . ($currentCategory ? '&category=' . $currentCategory : '') . ($searchQuery ? '&q=' . urlencode($searchQuery) : '')) ?>">
                                    &laquo;
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php for ($i = 1; $i <= $pagination['total_pages']; $i++): ?>
                            <li class="page-item <?= $i === $pagination['current_page'] ? 'active' : '' ?>">
                                <a class="page-link" href="<?= url('/news?page=' . $i . ($currentCategory ? '&category=' . $currentCategory : '') . ($searchQuery ? '&q=' . urlencode($searchQuery) : '')) ?>">
                                    <?= $i ?>
                                </a>
                            </li>
                        <?php endfor; ?>

                        <?php if ($pagination['has_next']): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?= url('/news?page=' . ($pagination['current_page'] + 1) . ($currentCategory ? '&category=' . $currentCategory : '') . ($searchQuery ? '&q=' . urlencode($searchQuery) : '')) ?>">
                                    &raquo;
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

