<div class="py-5 bg-white border-bottom">
    <div class="container text-center">
        <span class="section-tag"><?= trans('gallery') ?></span>
        <h1 class="fw-bold text-dark">Texnikum Hayoti Fotogalereyasi</h1>
        <p class="text-muted mx-auto" style="max-width: 650px;">
            Kosonsoy Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumida o'tkazilgan simulyatsion darslar, klinik amaliyot va ma'rifiy tadbirlardan fotolavhalar
        </p>
    </div>
</div>

<div class="section-padding">
    <div class="container">
        <?php if (empty($albums)): ?>
            <div class="text-center py-5">
                <i class="bi bi-images fs-1 text-muted d-block mb-3"></i>
                <h4 class="text-muted">Fotogalereyada albomlar mavjud emas.</h4>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach ($albums as $album): ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="bg-white rounded-4 overflow-hidden border shadow-sm h-100 d-flex flex-column">
                            <div class="position-relative overflow-hidden" style="height: 240px;">
                                <img src="<?= asset($album['cover_image']) ?>" alt="<?= e(t($album, 'title')) ?>" class="w-100 h-100 object-fit-cover">
                                <span class="badge bg-dark bg-opacity-75 text-white position-absolute bottom-0 start-0 m-3 px-3 py-1 rounded-pill small">
                                    <i class="bi bi-camera me-1"></i> <?= count($album['images'] ?? []) ?> ta rasm
                                </span>
                            </div>
                            <div class="p-4 d-flex flex-column flex-grow-1">
                                <span class="text-muted small mb-1">
                                    <i class="bi bi-calendar-event me-1"></i> <?= $album['event_date'] ? format_date($album['event_date']) : '' ?>
                                </span>
                                <h5 class="fw-bold text-dark mb-3"><?= e(t($album, 'title')) ?></h5>

                                <!-- Thumbnail previews -->
                                <?php if (!empty($album['images'])): ?>
                                    <div class="d-flex gap-2 mb-3">
                                        <?php foreach (array_slice($album['images'], 0, 3) as $im): ?>
                                            <img src="<?= asset($im['image_path']) ?>" alt="Thumbnail" class="rounded-2 border" style="width: 50px; height: 40px; object-fit: cover;">
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

