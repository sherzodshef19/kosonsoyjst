<div class="section-padding text-center">
    <div class="container py-5">
        <div class="display-1 fw-bold text-danger mb-3">403</div>
        <h2 class="fw-bold mb-3">Ruxsat etilmagan amal!</h2>
        <p class="text-muted mx-auto mb-4" style="max-width: 500px;">
            Sizning foydalanuvchi profilingizda ushbu modul yoki amalni bajarish uchun yetarli ruxsat huquqlari mavjud emas.
        </p>
        <a href="<?= url('/admin') ?>" class="btn btn-outline-primary rounded-pill px-4">
            <i class="bi bi-arrow-left me-1"></i> Boshqaruv paneliga qaytish
        </a>
    </div>
</div>

