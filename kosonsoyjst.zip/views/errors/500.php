<div class="section-padding text-center">
    <div class="container py-5">
        <div class="display-1 fw-bold text-danger mb-3">500</div>
        <h2 class="fw-bold mb-3">Tizimda ichki xatolik yuz berdi</h2>
        <p class="text-muted mx-auto mb-4" style="max-width: 500px;">
            So'rovni bajarish jarayonida kutilmagan server xatoligi yuz berdi. Dasturchilar guruhi bu haqida xabardor qilindi.
        </p>
        <a href="<?= url('/') ?>" class="btn btn-primary-brand rounded-pill px-4">
            <i class="bi bi-house-door-fill me-1"></i> Bosh sahifaga qaytish
        </a>
    </div>
</div>

