<div class="section-padding text-center">
    <div class="container py-5">
        <div class="display-1 fw-bold text-primary mb-3">404</div>
        <h2 class="fw-bold mb-3">Kechirasiz, sahifa topilmadi!</h2>
        <p class="text-muted mx-auto mb-4" style="max-width: 500px;">
            Siz qidirayotgan sahifa o'chirilgan, nomi o'zgartirilgan yoki vaqtincha mavjud bo'lmasligi mumkin.
        </p>
        <a href="<?= url('/') ?>" class="btn btn-primary-brand rounded-pill px-4">
            <i class="bi bi-house-door-fill me-1"></i> Bosh sahifaga qaytish
        </a>
    </div>
</div>

