<div class="py-5 bg-white border-bottom">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-2 small">
                <li class="breadcrumb-item"><a href="<?= url('/') ?>"><?= trans('home') ?></a></li>
                <li class="breadcrumb-item active"><?= e(t($page, 'title')) ?></li>
            </ol>
        </nav>
        <h1 class="fw-bold mb-0 text-dark"><?= e(t($page, 'title')) ?></h1>
    </div>
</div>

<div class="section-padding">
    <div class="container">
        <div class="bg-white p-4 p-md-5 rounded-4 border shadow-sm">
            <?php if (!empty($page['banner_image'])): ?>
                <div class="mb-4 rounded-4 overflow-hidden shadow-sm">
                    <img src="<?= asset($page['banner_image']) ?>" alt="<?= e(t($page, 'title')) ?>" class="w-100" style="max-height: 400px; object-fit: cover;">
                </div>
            <?php endif; ?>

            <div class="page-body-content text-secondary lh-lg fs-6">
                <?= t($page, 'content') ?>
            </div>
        </div>
    </div>
</div>

