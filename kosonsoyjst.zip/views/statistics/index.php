<div class="py-5 bg-white border-bottom">
    <div class="container text-center">
        <span class="section-tag"><?= trans('statistics') ?></span>
        <h1 class="fw-bold text-dark">Kollej Faoliyati Statistikasi</h1>
        <p class="text-muted mx-auto" style="max-width: 600px;">
            Kosonsoy kollejining ta'lim sifati, o'quvchilar soni, bitiruvchilar bandligi va moddiy-texnik bazasi bo'yicha asosiy ko'rsatkichlar
        </p>
    </div>
</div>

<div class="section-padding">
    <div class="container">
        <!-- Dynamic Counter Cards -->
        <div class="row g-4 mb-5">
            <?php foreach ($statistics as $stat): ?>
                <div class="col-lg-4 col-md-6">
                    <div class="bg-white p-4 rounded-4 border shadow-sm d-flex align-items-center gap-4">
                        <div class="rounded-3 p-3 bg-primary bg-opacity-10 text-primary fs-2">
                            <i class="bi <?= e($stat['icon'] ?: 'bi-mortarboard') ?>"></i>
                        </div>
                        <div>
                            <div class="counter-val text-primary fw-bold fs-2" data-target="<?= (int)$stat['count_value'] ?>" data-suffix="<?= e($stat['suffix']) ?>">
                                <?= (int)$stat['count_value'] ?><?= e($stat['suffix']) ?>
                            </div>
                            <div class="text-muted fw-semibold"><?= e(t($stat, 'title')) ?></div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Analytical Insights Grid -->
        <div class="row g-4">
            <div class="col-lg-6">
                <div class="bg-white p-4 p-md-5 rounded-4 border shadow-sm h-100">
                    <h4 class="fw-bold mb-4 text-primary"><i class="bi bi-pie-chart-fill me-2"></i> Tibbiy Ta'lim Yo'nalishlari Bo'yicha Qamrov</h4>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between small fw-bold mb-1">
                            <span>Hamshiralik ishi</span>
                            <span>35%</span>
                        </div>
                        <div class="progress" style="height: 10px;">
                            <div class="progress-bar bg-primary" role="progressbar" style="width: 35%"></div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="d-flex justify-content-between small fw-bold mb-1">
                            <span>Davolash ishi (Feldsherlik)</span>
                            <span>28%</span>
                        </div>
                        <div class="progress" style="height: 10px;">
                            <div class="progress-bar bg-danger" role="progressbar" style="width: 28%"></div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="d-flex justify-content-between small fw-bold mb-1">
                            <span>Farmatsiya (Dorishunoslik)</span>
                            <span>18%</span>
                        </div>
                        <div class="progress" style="height: 10px;">
                            <div class="progress-bar bg-success" role="progressbar" style="width: 18%"></div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="d-flex justify-content-between small fw-bold mb-1">
                            <span>Akusherlik ishi</span>
                            <span>11%</span>
                        </div>
                        <div class="progress" style="height: 10px;">
                            <div class="progress-bar bg-warning" role="progressbar" style="width: 11%"></div>
                        </div>
                    </div>

                    <div>
                        <div class="d-flex justify-content-between small fw-bold mb-1">
                            <span>Stomatologiya va Tibbiy profilaktika</span>
                            <span>8%</span>
                        </div>
                        <div class="progress" style="height: 10px;">
                            <div class="progress-bar bg-info" role="progressbar" style="width: 8%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="bg-white p-4 p-md-5 rounded-4 border shadow-sm h-100">
                    <h4 class="fw-bold mb-4 text-primary"><i class="bi bi-award-fill me-2"></i> Dual Ta'lim va Bandlik Kafolati</h4>
                    <p class="text-secondary mb-4">
                        Kollejimizda joriy etilgan Germaniya dual ta'lim modeli asosida bitiruvchilarning 92 foizi o'qishni tamomlash bilanoq o'zlari amaliyot o'tagan korxonalarda doimiy ish o'rniga ega bo'lmoqdalar.
                    </p>
                    <ul class="list-unstyled d-flex flex-column gap-3">
                        <li class="d-flex align-items-center gap-3">
                            <i class="bi bi-check-circle-fill text-success fs-5"></i>
                            <span>42 dan ortiq yetakchi korxonalar bilan rasmiy amaliyot shartnomalari</span>
                        </li>
                        <li class="d-flex align-items-center gap-3">
                            <i class="bi bi-check-circle-fill text-success fs-5"></i>
                            <span>18 ta zamonaviy kompyuter va mexanika ustaxonalari</span>
                        </li>
                        <li class="d-flex align-items-center gap-3">
                            <i class="bi bi-check-circle-fill text-success fs-5"></i>
                            <span>WorldSkills xalqaro kasbiy standartlariga mos baholash tizimi</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

