<div class="py-5 bg-white border-bottom">
    <div class="container text-center">
        <span class="section-tag"><?= trans('virtual_reception') ?></span>
        <h1 class="fw-bold text-dark">Murojaat Holatini Tekshirish</h1>
        <p class="text-muted mx-auto" style="max-width: 600px;">
            Murojaat yuborilganingizda berilgan maxsus unikal kodni kiriting (Masalan: KK-2026-10492)
        </p>
    </div>
</div>

<div class="section-padding">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <!-- Search Box -->
                <div class="bg-white p-4 rounded-4 border shadow-sm mb-4">
                    <form action="<?= url('/reception/check') ?>" method="GET">
                        <div class="input-group input-group-lg">
                            <span class="input-group-text bg-white border-end-0">
                                <i class="bi bi-search text-muted"></i>
                            </span>
                            <input type="text" name="code" class="form-control border-start-0" placeholder="Unikal murojaat kodi: Masalan KK-2026-10492" value="<?= e($code ?? '') ?>" required>
                            <button class="btn btn-primary px-4 fw-bold" type="submit">
                                Tekshirish
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Results -->
                <?php if ($searched): ?>
                    <?php if ($message): ?>
                        <div class="bg-white p-4 p-md-5 rounded-4 border shadow-sm">
                            <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 pb-3 mb-4 border-bottom">
                                <div>
                                    <span class="text-muted small d-block">Murojaat kodi:</span>
                                    <span class="fs-4 fw-bold text-dark font-monospace"><?= e($message['tracking_code']) ?></span>
                                </div>
                                <div>
                                    <?php 
                                    $stClass = 'bg-secondary';
                                    $stName = $message['status'];
                                    if ($message['status'] === 'NEW') { $stClass = 'bg-primary'; $stName = 'Yangi qabul qilindi'; }
                                    if ($message['status'] === 'IN_PROGRESS') { $stClass = 'bg-warning text-dark'; $stName = "Ko'rib chiqilmoqda"; }
                                    if ($message['status'] === 'ANSWERED') { $stClass = 'bg-success'; $stName = 'Rasmiy javob berildi'; }
                                    if ($message['status'] === 'CLOSED') { $stClass = 'bg-dark'; $stName = 'Murojaat yopilgan'; }
                                    ?>
                                    <span class="badge <?= $stClass ?> px-3 py-2 rounded-pill fs-6">
                                        <i class="bi bi-clock-history me-1"></i> <?= $stName ?>
                                    </span>
                                </div>
                            </div>

                            <div class="row g-3 mb-4 small text-secondary">
                                <div class="col-sm-6">
                                    <strong>Murojaatchi:</strong> <?= e($message['full_name']) ?>
                                </div>
                                <div class="col-sm-6">
                                    <strong>Yuborilgan vaqt:</strong> <?= format_date($message['created_at'], 'd.m.Y H:i') ?>
                                </div>
                                <div class="col-sm-6">
                                    <strong>Murojaat turi:</strong> <span class="badge bg-light text-dark border text-uppercase"><?= e($message['inquiry_type']) ?></span>
                                </div>
                                <div class="col-sm-6">
                                    <strong>Mavzu:</strong> <?= e($message['subject']) ?>
                                </div>
                            </div>

                            <div class="p-3 bg-light rounded-3 mb-4">
                                <strong class="d-block mb-1 text-dark small">Murojaat matni:</strong>
                                <p class="mb-0 text-secondary"><?= nl2br(e($message['message'])) ?></p>
                            </div>

                            <?php if (!empty($message['attachment_file'])): ?>
                                <div class="mb-4">
                                    <a href="<?= asset($message['attachment_file']) ?>" target="_blank" class="btn btn-outline-secondary btn-sm rounded-pill">
                                        <i class="bi bi-paperclip me-1"></i> Biriktirilgan faylni yuklab olish
                                    </a>
                                </div>
                            <?php endif; ?>

                            <!-- Official Responses Timeline -->
                            <div class="mt-4 pt-4 border-top">
                                <h4 class="fw-bold fs-5 mb-3 text-dark"><i class="bi bi-reply-all-fill text-success me-2"></i> Kollej Ma'muriyatining Rasmiy Javobi</h4>

                                <?php if (!empty($message['replies'])): ?>
                                    <div class="d-flex flex-column gap-3">
                                        <?php foreach ($message['replies'] as $reply): ?>
                                            <div class="p-4 rounded-3 border-start border-4 border-success bg-success bg-opacity-10">
                                                <div class="d-flex justify-content-between align-items-center mb-2">
                                                    <span class="fw-bold text-dark"><i class="bi bi-person-badge me-1"></i> <?= e($reply['replied_by_name'] ?? "Kollej mutasaddisi") ?></span>
                                                    <span class="text-muted small"><?= format_date($reply['created_at'], 'd.m.Y H:i') ?></span>
                                                </div>
                                                <div class="text-secondary lh-lg mb-2">
                                                    <?= nl2br(e($reply['reply_text'])) ?>
                                                </div>
                                                <?php if (!empty($reply['reply_file'])): ?>
                                                    <a href="<?= asset($reply['reply_file']) ?>" target="_blank" class="btn btn-success btn-sm rounded-pill mt-2">
                                                        <i class="bi bi-download me-1"></i> Rasmiy javob fayli (PDF)
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-warning mb-0 border-0">
                                        <i class="bi bi-hourglass-split me-2"></i> Murojaatingiz hozirda mutasaddilar tomonidan o'rganilmoqda. Rasmiy javob tayyor bo'lishi bilanoq ushbu sahifada ko'rinadi.
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="text-center bg-white p-5 rounded-4 border shadow-sm">
                            <i class="bi bi-exclamation-octagon text-danger fs-1 d-block mb-3"></i>
                            <h4 class="fw-bold text-dark">Murojaat topilmadi</h4>
                            <p class="text-muted">Kiritilgan kod bo'yicha hech qanday murojaat topilmadi. Kodni qayta tekshirib ko'ring.</p>
                            <a href="<?= url('/reception') ?>" class="btn btn-primary btn-sm rounded-pill px-4">Yangi murojaat yuborish</a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

