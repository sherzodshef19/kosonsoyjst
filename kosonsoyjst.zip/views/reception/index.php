<div class="py-5 bg-white border-bottom">
    <div class="container text-center">
        <span class="section-tag"><?= trans('virtual_reception') ?></span>
        <h1 class="fw-bold text-dark">Kollej Virtual Qabulxonasi</h1>
        <p class="text-muted mx-auto" style="max-width: 650px;">
            Kosonsoy kasb-hunar kolleji rahbariyatiga o'z taklif, ariza, savol yoki shikoyatlaringizni onlayn tarzda to'g'ridan-to'g'ri yuboring.
        </p>
        <div class="mt-3">
            <a href="<?= url('/reception/check') ?>" class="btn btn-outline-primary btn-sm rounded-pill px-4">
                <i class="bi bi-search me-1"></i> Murojaat holatini tekshirish
            </a>
        </div>
    </div>
</div>

<div class="section-padding">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="bg-white p-4 p-md-5 rounded-4 border shadow-sm">
                    <h3 class="fw-bold mb-4 fs-4 text-dark border-bottom pb-3">
                        <i class="bi bi-pencil-square text-primary me-2"></i> Onlayn murojaat shakli
                    </h3>

                    <form action="<?= url('/reception/submit') ?>" method="POST" enctype="multipart/form-data">
                        <?= csrf_field() ?>

                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold small"><?= trans('full_name') ?> *</label>
                                <input type="text" name="full_name" class="form-control" required placeholder="Familiyangiz, Ismingiz, Otangizning ismi" value="<?= e(old('full_name')) ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold small"><?= trans('phone') ?> *</label>
                                <input type="tel" name="phone" class="form-control" required placeholder="+998 (90) 123-45-67" value="<?= e(old('phone')) ?>">
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold small"><?= trans('email') ?> (Ixtiyoriy)</label>
                                <input type="email" name="email" class="form-control" placeholder="pochta@mail.uz" value="<?= e(old('email')) ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold small">Yashash manzili / Tuman</label>
                                <input type="text" name="address" class="form-control" placeholder="Kosonsoy tumani, ..." value="<?= e(old('address')) ?>">
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold small">Murojaat turi *</label>
                                <select name="inquiry_type" class="form-select" required>
                                    <option value="murojaat" <?= old('inquiry_type') === 'murojaat' ? 'selected' : '' ?>>Murojaat / Savol</option>
                                    <option value="ariza" <?= old('inquiry_type') === 'ariza' ? 'selected' : '' ?>>Rasmiy ariza</option>
                                    <option value="taklif" <?= old('inquiry_type') === 'taklif' ? 'selected' : '' ?>>Taklif</option>
                                    <option value="shikoyat" <?= old('inquiry_type') === 'shikoyat' ? 'selected' : '' ?>>Shikoyat</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold small"><?= trans('subject') ?> *</label>
                                <input type="text" name="subject" class="form-control" required placeholder="Murojaatning qisqacha mazmuni" value="<?= e(old('subject')) ?>">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold small"><?= trans('message') ?> *</label>
                            <textarea name="message" class="form-control" rows="5" required placeholder="Murojaatingizni batafsil bayon qiling..."><?= e(old('message')) ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold small">Fayl yoki hujjat ilova qilish (Ixtiyoriy: PDF, DOC, JPG)</label>
                            <input type="file" name="attachment" class="form-control" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png">
                            <div class="form-text small">Hujjat yoki ruxsat etilgan fayl hajmi: ko'pi bilan 10 MB.</div>
                        </div>

                        <!-- Anti-spam Math Captcha -->
                        <div class="mb-4 p-3 bg-light rounded-3 border">
                            <label class="form-label fw-semibold small text-dark d-flex align-items-center gap-2">
                                <i class="bi bi-shield-lock-fill text-warning"></i> Xavfsizlik tekshiruvi (Spamdan himoya) *
                            </label>
                            <div class="d-flex align-items-center gap-3">
                                <span class="badge bg-primary fs-6 px-3 py-2"><?= $captcha_question ?></span>
                                <input type="number" name="captcha" class="form-control" style="max-width: 140px;" placeholder="Javob?" required>
                            </div>
                        </div>

                        <div class="form-check mb-4">
                            <input class="form-check-input" type="checkbox" id="agreeCheck" required checked>
                            <label class="form-check-label small text-muted" for="agreeCheck">
                                Murojaatda ko'rsatilgan ma'lumotlarning haqqoniyligini tasdiqlayman va O'zbekiston Respublikasining "Jismoniy va yuridik shaxslarning murojaatlari to'g'risida"gi Qonuni talablariga roziman.
                            </label>
                        </div>

                        <button type="submit" class="btn btn-accent-brand w-100 py-3 fw-bold fs-6">
                            <i class="bi bi-send-fill me-2"></i> Murojaatni yuborish
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

