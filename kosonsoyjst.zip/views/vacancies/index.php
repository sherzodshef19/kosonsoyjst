<div class="py-5 bg-white border-bottom">
    <div class="container text-center">
        <span class="section-tag"><?= trans('vacancies') ?></span>
        <h1 class="fw-bold text-dark">Ochiq Vakansiyalar va Ish O'rinlari</h1>
        <p class="text-muted mx-auto" style="max-width: 600px;">
            Kosonsoy kasb-hunar kollejining professional jamoasiga qo'shiling va kelajak avlodni tarbiyalashda o'z hissangizni qo'shing
        </p>
    </div>
</div>

<div class="section-padding">
    <div class="container">
        <?php if (empty($vacancies)): ?>
            <div class="text-center py-5">
                <i class="bi bi-briefcase fs-1 text-muted d-block mb-3"></i>
                <h4 class="text-muted">Hozirda faol bo'sh ish o'rinlari mavjud emas.</h4>
                <p class="text-muted">Yangi vakansiyalar e'lon qilinganda saytimizda xabar beriladi.</p>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach ($vacancies as $vac): ?>
                    <div class="col-lg-6">
                        <div class="bg-white p-4 p-md-5 rounded-4 border shadow-sm h-100 d-flex flex-column justify-content-between">
                            <div>
                                <div class="d-flex justify-content-between align-items-start gap-3 mb-2">
                                    <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-1 rounded-pill">
                                        <?= e(t($vac, 'department')) ?>
                                    </span>
                                    <span class="badge bg-light text-secondary border">
                                        <?= $vac['employment_type'] === 'full_time' ? "To'liq stavka" : "Yarim stavka" ?>
                                    </span>
                                </div>
                                <h3 class="fw-bold fs-4 mb-2">
                                    <a href="<?= url('/vacancies/' . $vac['id']) ?>" class="text-dark text-decoration-none">
                                        <?= e(t($vac, 'title')) ?>
                                    </a>
                                </h3>
                                <div class="text-success fw-bold mb-3">
                                    <i class="bi bi-cash-stack me-1"></i> <?= e($vac['salary_text']) ?>
                                </div>
                                <p class="text-muted small mb-4">
                                    <?= e(truncate_words(t($vac, 'requirements'), 22)) ?>
                                </p>
                            </div>

                            <div class="d-flex align-items-center justify-content-between border-top pt-3 mt-auto">
                                <span class="text-muted small">
                                    <i class="bi bi-clock me-1"></i> Muddat: <?= $vac['deadline_date'] ? format_date($vac['deadline_date']) : "Noma'lum" ?>
                                </span>
                                <a href="<?= url('/vacancies/' . $vac['id']) ?>" class="btn btn-primary-brand btn-sm rounded-pill px-4">
                                    <?= trans('apply_now') ?> <i class="bi bi-arrow-right ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

