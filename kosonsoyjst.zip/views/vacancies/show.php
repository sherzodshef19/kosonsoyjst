<div class="py-4 bg-white border-bottom">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 small">
                <li class="breadcrumb-item"><a href="<?= url('/') ?>"><?= trans('home') ?></a></li>
                <li class="breadcrumb-item"><a href="<?= url('/vacancies') ?>"><?= trans('vacancies') ?></a></li>
                <li class="breadcrumb-item active"><?= e(t($vacancy, 'title')) ?></li>
            </ol>
        </nav>
    </div>
</div>

<div class="section-padding">
    <div class="container">
        <div class="row g-5">
            <!-- Vacancy Details -->
            <div class="col-lg-7">
                <div class="bg-white p-4 p-md-5 rounded-4 border shadow-sm">
                    <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-1 rounded-pill mb-2">
                        <?= e(t($vacancy, 'department')) ?>
                    </span>
                    <h1 class="fw-bold mb-3 fs-2 text-dark"><?= e(t($vacancy, 'title')) ?></h1>

                    <div class="d-flex flex-wrap gap-4 text-muted small pb-4 mb-4 border-bottom">
                        <span><i class="bi bi-briefcase text-primary me-1"></i> <?= $vacancy['employment_type'] === 'full_time' ? "To'liq stavka" : "Yarim stavka" ?></span>
                        <span><i class="bi bi-cash-stack text-success me-1"></i> <strong><?= e($vacancy['salary_text']) ?></strong></span>
                        <span><i class="bi bi-calendar-check text-warning me-1"></i> Ariza muddati: <?= $vacancy['deadline_date'] ? format_date($vacancy['deadline_date']) : "Belgilanmagan" ?></span>
                    </div>

                    <h4 class="fw-bold fs-5 mb-3 text-dark"><i class="bi bi-check-square-fill text-primary me-2"></i> Nomzodga qo'yiladigan talablar:</h4>
                    <div class="text-secondary mb-4 lh-lg">
                        <?= nl2br(e(t($vacancy, 'requirements'))) ?>
                    </div>

                    <?php if (!empty($vacancy['responsibilities_uz'])): ?>
                        <h4 class="fw-bold fs-5 mb-3 text-dark"><i class="bi bi-list-task text-primary me-2"></i> Asosiy vazifalar:</h4>
                        <div class="text-secondary mb-4 lh-lg">
                            <?= nl2br(e(t($vacancy, 'responsibilities'))) ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Application Form -->
            <div class="col-lg-5">
                <div class="bg-white p-4 p-md-5 rounded-4 border shadow-sm">
                    <h3 class="fw-bold fs-4 mb-3 text-dark"><i class="bi bi-send-fill text-warning me-2"></i> <?= trans('apply_now') ?></h3>
                    <p class="text-muted small mb-4">
                        Ma'lumotlaringizni to'ldiring va rezyume (CV) faylingizni yuklang.
                    </p>

                    <form action="<?= url('/vacancies/' . $vacancy['id'] . '/apply') ?>" method="POST" enctype="multipart/form-data">
                        <?= csrf_field() ?>

                        <div class="mb-3">
                            <label class="form-label fw-semibold small"><?= trans('full_name') ?> *</label>
                            <input type="text" name="full_name" class="form-control" required placeholder="Masalan: Karimova Dilnoza" value="<?= e(old('full_name')) ?>">
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold small"><?= trans('phone') ?> *</label>
                            <input type="tel" name="phone" class="form-control" required placeholder="+998 (90) 123-45-67" value="<?= e(old('phone')) ?>">
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold small"><?= trans('email') ?> *</label>
                            <input type="email" name="email" class="form-control" required placeholder="nomzod@mail.uz" value="<?= e(old('email')) ?>">
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold small"><?= trans('resume_cv') ?> (PDF, DOCX) *</label>
                            <input type="file" name="cv_file" class="form-control" required accept=".pdf,.doc,.docx">
                            <div class="form-text small">Maksimal hajm: 10MB</div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-semibold small">Qo'shimcha izoh yoki ma'lumot</label>
                            <textarea name="message" class="form-control" rows="3" placeholder="Ish tajribangiz haqida qisqacha..."><?= e(old('message')) ?></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary-brand w-100 py-2">
                            <?= trans('submit_application') ?> <i class="bi bi-send-check ms-1"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

