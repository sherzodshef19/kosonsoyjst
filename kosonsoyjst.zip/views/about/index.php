<div class="py-5 bg-white border-bottom">
    <div class="container text-center">
        <span class="section-tag"><i class="bi bi-geo-alt-fill text-danger me-1"></i>Namangan viloyati · Kosonsoy tumani</span>
        <h1 class="fw-bold text-dark mt-2">Kosonsoy Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumi</h1>
        <p class="text-muted mx-auto" style="max-width: 750px;">
            Buyuk alloma Abu Ali ibn Sino ilmiy merosi asosida zamonaviy tibbiy bilimlar, simulyatsion laboratoriyalar va klinik amaliyotga asoslangan yetakchi ta'lim dargohi
        </p>
    </div>
</div>

<div class="section-padding">
    <div class="container">
        <!-- History & Mission -->
        <div class="row align-items-center g-5 mb-5">
            <div class="col-lg-6">
                <span class="section-tag">Texnikum Tarixi</span>
                <h2 class="fw-bold mb-3 fs-2 text-dark">Boy tibbiy an'analar va zamonaviy sog'liqni saqlash ta'limi</h2>
                <p class="text-secondary lh-lg mb-3">
                    Kosonsoy Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumi Namangan viloyatida o'rta bo'g'in professional tibbiyot mutaxassislarini tayyorlash bo'yicha boy amaliy an'analarga ega nufuzli ta'lim maskanidir. Yillar davomida texnikumimizdan minglab malakali hamshiralar, feldsherlar, farmatsevtlar, akusherlar va laboratoriya diagnostlari yetishib chiqqan.
                </p>
                <p class="text-secondary lh-lg mb-4">
                    Bugungi kunda texnikumda nazariy bilimlar zamonaviy tibbiy simulyatsiya markazlarida robot-manekenlar yordamida mustahkamlanadi. Talabalarimiz Kosonsoy tuman markaziy shifoxonasi, tug'ruq majmuasi, tez tibbiy yordam bo'limi hamda viloyat ko'p tarmoqli tibbiyot markazlarida bevosita bemorlar bilan klinik rotatsiyalarda amaliy tajriba oshiradilar.
                </p>
                <div class="d-flex gap-3">
                    <a href="<?= url('/documents') ?>" class="btn btn-outline-primary rounded-pill px-4">
                        <i class="bi bi-file-earmark-medical me-1"></i> Texnikum Ustavi
                    </a>
                    <a href="<?= url('/reception') ?>" class="btn btn-primary-brand rounded-pill px-4">
                        <i class="bi bi-chat-dots me-1"></i> Virtual qabulxona
                    </a>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="rounded-4 overflow-hidden shadow-lg border">
                    <img src="<?= asset('/assets/images/about-main.jpg') ?>" alt="Kosonsoy Abu Ali ibn Sino JST Binosi" class="w-100" style="height: 420px; object-fit: cover;">
                </div>
            </div>
        </div>

        <!-- Mission & Values Grid -->
        <div class="row g-4 mb-5">
            <div class="col-md-4">
                <div class="bg-white p-4 rounded-4 border shadow-sm h-100">
                    <div class="text-primary fs-1 mb-3"><i class="bi bi-heart-pulse-fill"></i></div>
                    <h4 class="fw-bold fs-5 mb-2">Bizning Missiyamiz</h4>
                    <p class="text-muted small mb-0">
                        O'zbekiston sog'liqni saqlash tizimi uchun yuksak ma'naviyatli, mehr-oqibatli, tezkor va xalqaro tibbiy standartlarga to'liq javob beradigan professional tibbiyot kadrlarini tayyorlash.
                    </p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="bg-white p-4 rounded-4 border shadow-sm h-100">
                    <div class="text-warning fs-1 mb-3"><i class="bi bi-hospital-fill"></i></div>
                    <h4 class="fw-bold fs-5 mb-2">Kelajak Tasavvuri (Vision)</h4>
                    <p class="text-muted small mb-0">
                        Namangan viloyatida zamonaviy simulyatsion tibbiy ta'lim, jamoat salomatligi profilaktikasi va farmatsevtik innovatsiyalar bo'yicha yetakchi namunaviy ta'lim klasteriga aylanish.
                    </p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="bg-white p-4 rounded-4 border shadow-sm h-100">
                    <div class="text-success fs-1 mb-3"><i class="bi bi-shield-check"></i></div>
                    <h4 class="fw-bold fs-5 mb-2">Asosiy Qadriyatlarimiz</h4>
                    <p class="text-muted small mb-0">
                        Inson hayotiga ehtirom, Ibn Sino axloqiy tamoyillari, klinik halollik, bemor xavfsizligi va doimiy uzluksiz kasbiy rivojlanish.
                    </p>
                </div>
            </div>
        </div>

        <!-- Contact & Location Map -->
        <div class="bg-white p-4 p-md-5 rounded-4 border shadow-sm mt-5">
            <div class="row g-4 align-items-center">
                <div class="col-lg-5">
                    <span class="section-tag">Bog'lanish</span>
                    <h3 class="fw-bold mb-4">Biz bilan bog'lanish</h3>
                    
                    <ul class="list-unstyled d-flex flex-column gap-3 text-secondary mb-4">
                        <li class="d-flex align-items-start gap-3">
                            <i class="bi bi-geo-alt-fill text-danger fs-5 mt-1"></i>
                            <div>
                                <strong>Manzil:</strong><br>
                                <?= e(setting('site_address', "Namangan viloyati, Kosonsoy tumani, Mustaqillik ko'chasi, 45-uy")) ?>
                            </div>
                        </li>
                        <li class="d-flex align-items-center gap-3">
                            <i class="bi bi-telephone-fill text-primary fs-5"></i>
                            <div>
                                <strong>Telefon:</strong><br>
                                <?= e(setting('site_phone', "+998 (69) 652-12-34")) ?>
                            </div>
                        </li>
                        <li class="d-flex align-items-center gap-3">
                            <i class="bi bi-clock-fill text-warning fs-5"></i>
                            <div>
                                <strong>Ish tartibi:</strong><br>
                                <?= e(setting('working_hours', "Dushanba - Shanba: 08:30 - 17:30")) ?>
                            </div>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-7">
                    <!-- Interactive Google Map Embed -->
                    <div class="rounded-3 overflow-hidden border shadow-sm" style="height: 320px;">
                        <?php
                        $defaultMap = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d48347.88607148817!2d71.50341773099975!3d41.25870420658428!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38779b5c3ff41147%3A0xe54fb7a72d3f23a4!2z0JrQsNGB0LDQvdGB0LDQuSwg0J3QsNC80LDQvdCz0LDQvdGB0LrQsNGPINC-0LHQu9Cw0YHRgtGMLCDQo9C30LHQtdC60LjRgdGC0LDQvQ!5e0!3m2!1sru!2s!4v1700000000000!5m2!1sru!2s";
                        $mapSrc = setting('google_maps_iframe') ?: $defaultMap;
                        if (strpos($mapSrc, '<iframe') !== false && preg_match('/src=["\']([^"\']+)["\']/i', $mapSrc, $matches)) {
                            $mapSrc = $matches[1];
                        }
                        ?>
                        <iframe 
                            src="<?= e($mapSrc) ?>" 
                            width="100%" 
                            height="100%" 
                            style="border:0;" 
                            allowfullscreen="" 
                            loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade">
                        </iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

