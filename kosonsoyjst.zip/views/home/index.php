<!-- Hero Banner Section -->
<section class="hero-slider-section">
    <div id="heroCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="6000">
        <div class="carousel-indicators">
            <?php foreach ($banners as $index => $banner): ?>
                <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="<?= $index ?>" class="<?= $index === 0 ? 'active' : '' ?>" aria-current="<?= $index === 0 ? 'true' : 'false' ?>"></button>
            <?php endforeach; ?>
        </div>

        <div class="carousel-inner">
            <?php foreach ($banners as $index => $banner): ?>
                <div class="carousel-item <?= $index === 0 ? 'active' : '' ?>">
                    <div class="hero-slide" style="background-image: url('<?= asset($banner['image'] ?: '/assets/images/banner-default.jpg') ?>');">
                        <div class="hero-overlay"></div>
                        <div class="container hero-content">
                            <div class="row align-items-center">
                                <div class="col-lg-9 col-xl-8">
                                    <div class="hero-badge">
                                        <i class="bi bi-heart-pulse-fill text-danger"></i>
                                        <span>Namangan viloyati · Kosonsoy tumani</span>
                                    </div>
                                    <h1 class="hero-title"><?= e(t($banner, 'title')) ?></h1>
                                    <p class="hero-subtitle"><?= e(t($banner, 'subtitle')) ?></p>
                                    <div class="d-flex flex-wrap gap-3">
                                        <?php if (!empty($banner['button_url'])): ?>
                                            <a href="<?= e($banner['button_url']) ?>" class="btn btn-accent-brand d-inline-flex align-items-center gap-2">
                                                <span><?= e(t($banner, 'button_text', trans('read_more'))) ?></span>
                                                <i class="bi bi-arrow-right"></i>
                                            </a>
                                        <?php endif; ?>
                                        <a href="<?= url('/reception') ?>" class="btn btn-outline-light px-4 py-2 rounded-3 fw-semibold">
                                            <i class="bi bi-chat-square-text me-2"></i><?= trans('virtual_reception') ?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </button>
    </div>
</section>

<!-- Floating Quick Actions Bar -->
<section class="py-4" style="margin-top: -45px; position: relative; z-index: 10;">
    <div class="container">
        <div class="row g-3">
            <div class="col-md-3 col-sm-6">
                <a href="#directions" class="quick-action-card text-decoration-none">
                    <div class="quick-icon-box">
                        <i class="bi bi-briefcase-fill"></i>
                    </div>
                    <h5 class="fw-bold fs-6 mb-1 text-dark">Kasbiy yo'nalishlar</h5>
                    <p class="text-muted small mb-0">14 ta zamonaviy mutaxassislik</p>
                </a>
            </div>
            <div class="col-md-3 col-sm-6">
                <a href="<?= url('/reception') ?>" class="quick-action-card text-decoration-none">
                    <div class="quick-icon-box" style="background:#fef3c7; color:#d97706;">
                        <i class="bi bi-chat-dots-fill"></i>
                    </div>
                    <h5 class="fw-bold fs-6 mb-1 text-dark">Virtual qabulxona</h5>
                    <p class="text-muted small mb-0">Onlayn ariza va murojaat</p>
                </a>
            </div>
            <div class="col-md-3 col-sm-6">
                <a href="<?= url('/statistics') ?>" class="quick-action-card text-decoration-none">
                    <div class="quick-icon-box" style="background:#ecfdf5; color:#059669;">
                        <i class="bi bi-graph-up-arrow"></i>
                    </div>
                    <h5 class="fw-bold fs-6 mb-1 text-dark">Texnikum ko'rsatkichlari</h5>
                    <p class="text-muted small mb-0">Raqamlar va natijalar</p>
                </a>
            </div>
            <div class="col-md-3 col-sm-6">
                <a href="<?= url('/documents') ?>" class="quick-action-card text-decoration-none">
                    <div class="quick-icon-box" style="background:#f5f3ff; color:#7c3aed;">
                        <i class="bi bi-file-earmark-check-fill"></i>
                    </div>
                    <h5 class="fw-bold fs-6 mb-1 text-dark">Me'yoriy hujjatlar</h5>
                    <p class="text-muted small mb-0">Litsenziya va ustavlar</p>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Director's Welcome Address Section -->
<section class="section-padding">
    <div class="container">
        <div class="director-section">
            <i class="bi bi-quote director-quote-icon"></i>
            <div class="row align-items-center g-4">
                <div class="col-lg-3 col-md-4 text-center">
                    <img src="<?= asset('/assets/images/director.jpg') ?>" alt="Direktor" class="director-img mb-3">
                    <h5 class="fw-bold mb-1 text-dark"><?= e(setting('director_name', 'Zokirov Anvar Rustamovich')) ?></h5>
                    <p class="text-muted small mb-0"><?= e(setting('director_title', 'Texnikum Direktori, tibbiyot fanlari nomzodi')) ?></p>
                </div>
                <div class="col-lg-9 col-md-8">
                    <span class="section-tag"><?= trans('director_speech') ?></span>
                    <h3 class="fw-bold mb-3">"Kelajak kasbini bugun, sifatli ta'lim orqali egallang!"</h3>
                    <p class="text-muted lead fs-6 mb-4">
                        "<?= e(setting('director_quote_' . current_lang(), setting('director_quote_uz', 'Bizning bosh maqsadimiz — har bir yoshga zamonaviy kasbiy bilimlarni berish, ularni mehnat bozorida yuqori talabga ega raqobatbardosh mutaxassis qilib tarbiyalashdir.'))) ?>"
                    </p>
                    <div class="d-flex flex-wrap align-items-center gap-3">
                        <a href="<?= url('/about') ?>" class="btn btn-outline-primary btn-sm rounded-pill px-3">
                            <i class="bi bi-info-circle me-1"></i> <?= trans('about_us') ?>
                        </a>
                        <a href="<?= url('/management') ?>" class="btn btn-link btn-sm text-primary text-decoration-none fw-semibold">
                            Rahbariyat tarkibi bilan tanishuv <i class="bi bi-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Educational Directions Section -->
<section class="section-padding bg-white" id="directions">
    <div class="container">
        <div class="text-center mb-5">
            <span class="section-tag"><i class="bi bi-heart-pulse-fill text-danger me-1"></i>Mutaxassisliklar</span>
            <h2 class="section-title"><?= trans('directions') ?></h2>
            <p class="section-desc"><?= trans('directions_desc') ?></p>
        </div>

        <div class="row g-4">
            <?php if (!empty($programs)): ?>
                <?php foreach ($programs as $prog): ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="direction-card h-100 p-4 rounded-4 border bg-white shadow-sm hover-lift d-flex flex-column">
                            <div class="direction-icon bg-<?= e($prog['icon_color'] ?: 'primary') ?> <?= in_array($prog['icon_color'], ['warning']) ? 'text-dark' : 'text-white' ?> mb-3 d-inline-flex align-items-center justify-content-center rounded-3" style="width: 52px; height: 52px; font-size: 1.5rem; <?= $prog['icon_color'] === 'teal' ? 'background: #0f766e !important;' : '' ?>">
                                <i class="bi <?= e($prog['icon']) ?>"></i>
                            </div>
                            <h4 class="fw-bold fs-5 mb-2 text-dark"><?= e(t($prog, 'title')) ?></h4>
                            <p class="text-muted small mb-3 lh-base">
                                <?= e(t($prog, 'description')) ?>
                            </p>
                            <div class="d-flex gap-2 flex-wrap mt-auto">
                                <?php if (!empty(t($prog, 'badge_category'))): ?>
                                    <span class="badge bg-light text-primary border"><?= e(t($prog, 'badge_category')) ?></span>
                                <?php endif; ?>
                                <?php if (!empty(t($prog, 'duration'))): ?>
                                    <span class="badge bg-light text-secondary border"><?= e(t($prog, 'duration')) ?></span>
                                <?php endif; ?>
                                <?php if (!empty(t($prog, 'type'))): ?>
                                    <span class="badge bg-light text-success border"><?= e(t($prog, 'type')) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Statistics Counters Section -->
<section class="section-padding bg-dark text-white" style="background: linear-gradient(135deg, #07192f 0%, #0b2545 100%);">
    <div class="container">
        <div class="text-center mb-5">
            <span class="section-tag text-warning"><?= trans('statistics') ?></span>
            <h2 class="section-title text-white"><?= trans('college_stats') ?></h2>
            <p class="text-secondary mx-auto" style="max-width: 600px;">
                Kosonsoy Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumining so'nggi yillardagi ilmiy, kasbiy va amaliy faoliyati bo'yicha asosiy natijalari
            </p>
        </div>

        <div class="row g-4">
            <?php foreach ($statistics as $stat): ?>
                <div class="col-lg-2 col-md-4 col-6">
                    <div class="counter-box">
                        <div class="counter-val" data-target="<?= (int)$stat['count_value'] ?>" data-suffix="<?= e($stat['suffix']) ?>">
                            <?= (int)$stat['count_value'] ?><?= e($stat['suffix']) ?>
                        </div>
                        <div class="counter-label"><?= e(t($stat, 'title')) ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Latest News & Announcements Section -->
<section class="section-padding">
    <div class="container">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end mb-4">
            <div>
                <span class="section-tag"><?= trans('news') ?></span>
                <h2 class="section-title mb-0"><?= trans('latest_news') ?></h2>
            </div>
            <a href="<?= url('/news') ?>" class="btn btn-outline-primary btn-sm rounded-pill mt-3 mt-md-0 fw-semibold px-3">
                <?= trans('view_all') ?> <i class="bi bi-arrow-right"></i>
            </a>
        </div>

        <!-- Featured News Card (if available) -->
        <?php if ($featuredNews): ?>
            <div class="featured-news-card mb-5">
                <div class="row g-0">
                    <div class="col-lg-6">
                        <img src="<?= asset($featuredNews['image'] ?: '/assets/images/news-default.jpg') ?>" alt="<?= e(t($featuredNews, 'title')) ?>" class="featured-news-img">
                    </div>
                    <div class="col-lg-6 d-flex flex-column justify-content-center p-4 p-lg-5">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <span class="badge bg-warning text-dark px-3 py-1 rounded-pill fw-bold">
                                <?= trans('featured_news') ?>
                            </span>
                            <span class="text-muted small">
                                <i class="bi bi-calendar3 me-1"></i> <?= format_date($featuredNews['published_at']) ?>
                            </span>
                        </div>
                        <h3 class="fw-bold mb-3">
                            <a href="<?= url('/news/' . $featuredNews['slug']) ?>" class="text-dark text-decoration-none">
                                <?= e(t($featuredNews, 'title')) ?>
                            </a>
                        </h3>
                        <p class="text-muted mb-4">
                            <?= e(t($featuredNews, 'summary') ?: truncate_words($featuredNews['content_uz'], 30)) ?>
                        </p>
                        <div>
                            <a href="<?= url('/news/' . $featuredNews['slug']) ?>" class="btn btn-primary-brand rounded-pill btn-sm px-4">
                                <?= trans('read_more') ?> <i class="bi bi-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- News Grid -->
        <div class="row g-4">
            <?php foreach (array_slice($latestNews, 0, 3) as $item): ?>
                <div class="col-lg-4 col-md-6">
                    <article class="news-card">
                        <div class="news-img-wrapper">
                            <img src="<?= asset($item['image'] ?: '/assets/images/news-default.jpg') ?>" alt="<?= e(t($item, 'title')) ?>" loading="lazy">
                            <span class="news-badge"><?= e(t($item, 'cat_name', 'Yangiliklar')) ?></span>
                        </div>
                        <div class="news-body">
                            <div class="news-meta">
                                <span><i class="bi bi-calendar-event me-1"></i> <?= format_date($item['published_at']) ?></span>
                                <span><i class="bi bi-eye me-1"></i> <?= (int)$item['views_count'] ?></span>
                            </div>
                            <h4 class="news-title">
                                <a href="<?= url('/news/' . $item['slug']) ?>"><?= e(t($item, 'title')) ?></a>
                            </h4>
                            <p class="news-excerpt">
                                <?= e(truncate_words(t($item, 'summary') ?: $item['content_uz'], 18)) ?>
                            </p>
                            <a href="<?= url('/news/' . $item['slug']) ?>" class="text-primary fw-bold small text-decoration-none mt-auto">
                                <?= trans('read_more') ?> <i class="bi bi-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </article>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Virtual Reception Interactive Check CTA -->
<section class="section-padding bg-light" style="border-top: 1px solid #e2e8f0; border-bottom: 1px solid #e2e8f0;">
    <div class="container">
        <div class="row align-items-center g-4">
            <div class="col-lg-6">
                <span class="section-tag"><?= trans('virtual_reception') ?></span>
                <h2 class="section-title">Savol yoki murojaatingiz bormi?</h2>
                <p class="text-muted mb-4 lead fs-6">
                    Texnikum ma'muriyatiga to'g'ridan-to'g'ri murojaat yo'llang yoki avval yuborilgan arizangiz ijrosi holatini onlayn tarzda tekshiring.
                </p>
                <div class="d-flex flex-wrap gap-3">
                    <a href="<?= url('/reception') ?>" class="btn btn-accent-brand">
                        <i class="bi bi-pencil-square me-1"></i> Murojaat yuborish
                    </a>
                    <a href="<?= url('/reception/check') ?>" class="btn btn-outline-primary">
                        <i class="bi bi-search me-1"></i> Holatni tekshirish
                    </a>
                </div>
            </div>

            <div class="col-lg-6">
                <!-- Vue 3 Quick Status Check Box -->
                <div class="bg-white p-4 rounded-4 shadow-sm border" id="reception-quick-check-app">
                    <h5 class="fw-bold mb-3 d-flex align-items-center gap-2">
                        <i class="bi bi-search text-primary"></i> Murojaat holatini tezkor tekshirish
                    </h5>
                    <form @submit.prevent="checkStatus">
                        <div class="input-group mb-3">
                            <input type="text" v-model="code" class="form-control" placeholder="Murojaat kodi: Masalan KK-2026-10492" required>
                            <button class="btn btn-primary" type="submit" :disabled="loading">
                                <span v-if="loading" class="spinner-border spinner-border-sm me-1"></span>
                                Tekshirish
                            </button>
                        </div>
                    </form>

                    <div v-if="error" class="alert alert-danger py-2 small mb-0">
                        {{ error }}
                    </div>

                    <div v-if="result" class="p-3 bg-light rounded-3 mt-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <strong>{{ result.full_name }}</strong>
                            <span class="badge bg-primary">{{ result.status }}</span>
                        </div>
                        <div class="small text-muted mb-2">Mavzu: {{ result.subject }}</div>
                        <a :href="'/reception/check?code=' + result.tracking_code" class="btn btn-sm btn-outline-secondary w-100">
                            Batafsil ko'rish
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Partners Section -->
<section class="section-padding bg-white">
    <div class="container">
        <div class="text-center mb-5">
            <span class="section-tag"><?= trans('partners') ?></span>
            <h2 class="section-title">Hamkor tibbiyot birlashmalari va klinikalari</h2>
            <p class="section-desc">Talabalarimiz klinik amaliyot o'taydigan va bitiruvchilarimiz ish bilan ta'minlanadigan shifoxonalar hamda tibbiyot markazlari</p>
        </div>

        <div class="row g-3 justify-content-center">
            <?php foreach ($partners as $partner): ?>
                <div class="col-lg-2 col-md-3 col-6">
                    <a href="<?= e($partner['website_url'] ?: '#') ?>" target="_blank" class="partner-logo-item text-decoration-none" title="<?= e($partner['name']) ?>">
                        <img src="<?= asset($partner['logo']) ?>" alt="<?= e($partner['name']) ?>" loading="lazy" onerror="this.onerror=null;this.src='<?= asset('/assets/images/partner-default.svg') ?>';">
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

