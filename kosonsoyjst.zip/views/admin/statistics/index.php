<div class="row g-4">
    <!-- List -->
    <div class="col-lg-8">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title">Statistika Ko'rsatkichlari</h5>
            </div>
            <div class="admin-card-body p-0">
                <div class="table-responsive">
                    <table class="table table-custom table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Ikonka</th>
                                <th>Sarlavha</th>
                                <th>Qiymat</th>
                                <th>Suffiks</th>
                                <th>Tartib</th>
                                <th>Holat</th>
                                <th style="width: 100px;" class="text-end">Amal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($statistics as $stat): ?>
                                <tr>
                                    <td>
                                        <i class="bi <?= e($stat['icon']) ?> fs-5 text-primary"></i>
                                    </td>
                                    <td class="fw-bold text-dark"><?= e($stat['title_uz']) ?></td>
                                    <td class="fs-6 fw-bold text-success"><?= (int)$stat['count_value'] ?></td>
                                    <td><?= e($stat['suffix']) ?></td>
                                    <td><?= (int)$stat['sort_order'] ?></td>
                                    <td>
                                        <span class="badge bg-<?= $stat['is_active'] ? 'success' : 'secondary' ?> badge-status">
                                            <?= $stat['is_active'] ? 'Faol' : 'Nofaol' ?>
                                        </span>
                                    </td>
                                    <td class="text-end">
                                        <button class="btn btn-sm btn-light border py-1 px-2 me-1" data-bs-toggle="modal" data-bs-target="#editModal<?= $stat['id'] ?>">
                                            <i class="bi bi-pencil-fill text-primary"></i>
                                        </button>
                                        <a href="<?= url('/admin/statistics/delete/' . $stat['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 btn-delete-confirm">
                                            <i class="bi bi-trash-fill text-danger"></i>
                                        </a>
                                    </td>
                                </tr>

                                <!-- Edit Modal -->
                                <div class="modal fade" id="editModal<?= $stat['id'] ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="<?= url('/admin/statistics/update/' . $stat['id']) ?>" method="POST">
                                                <?= csrf_field() ?>
                                                <div class="modal-header">
                                                    <h5 class="modal-title fs-6 fw-bold">Ko'rsatkichni tahrirlash</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Sarlavha (O'zbekcha) *</label>
                                                        <input type="text" name="title_uz" class="form-control" value="<?= e($stat['title_uz']) ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Sarlavha (Ruscha)</label>
                                                        <input type="text" name="title_ru" class="form-control" value="<?= e($stat['title_ru'] ?? '') ?>">
                                                    </div>
                                                    <div class="row g-2 mb-3">
                                                        <div class="col-8">
                                                            <label class="form-label small fw-semibold">Raqamli qiymat *</label>
                                                            <input type="number" name="count_value" class="form-control" value="<?= (int)$stat['count_value'] ?>" required>
                                                        </div>
                                                        <div class="col-4">
                                                            <label class="form-label small fw-semibold">Qo'shimcha (+, %)</label>
                                                            <input type="text" name="suffix" class="form-control" value="<?= e($stat['suffix']) ?>">
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Bootstrap Icon klassi</label>
                                                        <input type="text" name="icon" class="form-control" value="<?= e($stat['icon']) ?>" placeholder="bi-mortarboard">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Tartib raqami</label>
                                                        <input type="number" name="sort_order" class="form-control" value="<?= (int)$stat['sort_order'] ?>">
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="actS<?= $stat['id'] ?>" <?= $stat['is_active'] ? 'checked' : '' ?>>
                                                        <label class="form-check-label small fw-semibold" for="actS<?= $stat['id'] ?>">Faol</label>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Yopish</button>
                                                    <button type="submit" class="btn btn-primary btn-sm px-3">Saqlash</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Add Form -->
    <div class="col-lg-4">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title"><i class="bi bi-plus-circle text-primary me-2"></i> Yangi Ko'rsatkich</h5>
            </div>
            <div class="admin-card-body">
                <form action="<?= url('/admin/statistics/store') ?>" method="POST">
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Ko'rsatkich nomi (O'zbekcha) *</label>
                        <input type="text" name="title_uz" class="form-control" required placeholder="Masalan: Bitiruvchilar soni">
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-8">
                            <label class="form-label small fw-semibold">Raqamli qiymat *</label>
                            <input type="number" name="count_value" class="form-control" required placeholder="1200">
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-semibold">Suffiks</label>
                            <input type="text" name="suffix" class="form-control" value="+">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Bootstrap Icon klassi</label>
                        <input type="text" name="icon" class="form-control" value="bi-people-fill" placeholder="bi-people-fill">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Tartib raqami</label>
                        <input type="number" name="sort_order" class="form-control" value="0">
                    </div>

                    <div class="form-check mb-4">
                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="statActive" checked>
                        <label class="form-check-label small fw-semibold" for="statActive">Faol</label>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 rounded-3">
                        <i class="bi bi-plus-lg me-1"></i> Qo'shish
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

