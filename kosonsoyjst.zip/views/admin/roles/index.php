<div class="admin-card">
    <div class="admin-card-header">
        <div>
            <h5 class="admin-card-title mb-1">Rollar va Ruxsatlar Matritsasi</h5>
            <div class="text-muted small">Har bir modul bo'yicha rollarga tegishli ruxsatlarni boshqarish</div>
        </div>
    </div>

    <div class="admin-card-body">
        <ul class="nav nav-tabs mb-4" id="roleTabs">
            <?php foreach ($roles as $idx => $role): ?>
                <li class="nav-item">
                    <button class="nav-link <?= $idx === 0 ? 'active' : '' ?> fw-semibold" data-bs-toggle="tab" data-bs-target="#tab-role-<?= $role['id'] ?>">
                        <?= e($role['display_name']) ?> <span class="badge bg-secondary ms-1"><?= e($role['name']) ?></span>
                    </button>
                </li>
            <?php endforeach; ?>
        </ul>

        <div class="tab-content">
            <?php foreach ($roles as $idx => $role): ?>
                <div class="tab-pane fade <?= $idx === 0 ? 'show active' : '' ?>" id="tab-role-<?= $role['id'] ?>">
                    <div class="p-3 bg-light rounded-3 mb-3 border">
                        <strong class="d-block text-dark"><?= e($role['display_name']) ?>:</strong>
                        <span class="text-muted small"><?= e($role['description']) ?></span>
                        <?php if ($role['name'] === 'SUPER_ADMIN'): ?>
                            <div class="alert alert-info py-2 small mt-2 mb-0">
                                <i class="bi bi-info-circle me-1"></i> Bosh Administrator barcha modullarga avtomatik tarzda to'liq cheklovlarsiz kirish huquqiga ega.
                            </div>
                        <?php endif; ?>
                    </div>

                    <form action="<?= url('/admin/roles/permissions/' . $role['id']) ?>" method="POST">
                        <?= csrf_field() ?>

                        <div class="row g-4 mb-4">
                            <?php foreach ($groupedPerms as $module => $perms): ?>
                                <div class="col-md-6 col-lg-4">
                                    <div class="border rounded-3 p-3 bg-white h-100 shadow-sm">
                                        <h6 class="fw-bold text-primary text-uppercase fs-6 mb-3 border-bottom pb-2">
                                            <?= e($module) ?>
                                        </h6>
                                        <div class="d-flex flex-column gap-2">
                                            <?php foreach ($perms as $p): ?>
                                                <div class="form-check">
                                                    <input 
                                                        class="form-check-input" 
                                                        type="checkbox" 
                                                        name="permissions[]" 
                                                        value="<?= $p['id'] ?>" 
                                                        id="p_<?= $role['id'] ?>_<?= $p['id'] ?>"
                                                        <?= in_array($p['id'], $rolePerms[$role['id']] ?? []) ? 'checked' : '' ?>
                                                        <?= $role['name'] === 'SUPER_ADMIN' ? 'disabled checked' : '' ?>
                                                    >
                                                    <label class="form-check-label small" for="p_<?= $role['id'] ?>_<?= $p['id'] ?>">
                                                        <strong><?= e($p['display_name']) ?></strong>
                                                        <span class="d-block text-muted" style="font-size: 0.72rem;"><?= e($p['name']) ?></span>
                                                    </label>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <?php if ($role['name'] !== 'SUPER_ADMIN'): ?>
                            <button type="submit" class="btn btn-primary rounded-pill px-4">
                                <i class="bi bi-shield-check me-1"></i> Ruxsatlarni saqlash
                            </button>
                        <?php endif; ?>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

