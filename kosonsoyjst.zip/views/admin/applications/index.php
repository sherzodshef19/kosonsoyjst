<div class="admin-card">
    <div class="admin-card-header flex-wrap gap-3">
        <div>
            <h5 class="admin-card-title mb-1">Nomzodlar Arizalari</h5>
            <div class="text-muted small">Bo'sh ish o'rinlari uchun kelib tushgan rezyumelar</div>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= url('/admin/applications/export') ?>" class="btn btn-outline-success btn-sm rounded-pill px-3">
                <i class="bi bi-file-earmark-excel me-1"></i> Excelga yuklab olish (CSV)
            </a>
        </div>
    </div>

    <!-- Filters -->
    <div class="p-3 bg-light border-bottom">
        <form action="<?= url('/admin/applications') ?>" method="GET" class="row g-2 align-items-center">
            <div class="col-md-5">
                <select name="vacancy_id" class="form-select form-select-sm">
                    <option value="">Barcha vakansiyalar</option>
                    <?php foreach ($vacancies as $v): ?>
                        <option value="<?= $v['id'] ?>" <?= ($currentVacancy == $v['id']) ? 'selected' : '' ?>>
                            <?= e($v['title_uz']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <select name="status" class="form-select form-select-sm">
                    <option value="">Barcha statuslar</option>
                    <option value="NEW" <?= $currentStatus === 'NEW' ? 'selected' : '' ?>>Yangi (Ko'rilmagan)</option>
                    <option value="REVIEWING" <?= $currentStatus === 'REVIEWING' ? 'selected' : '' ?>>Ko'rib chiqilmoqda</option>
                    <option value="ACCEPTED" <?= $currentStatus === 'ACCEPTED' ? 'selected' : '' ?>>Qabul qilingan</option>
                    <option value="REJECTED" <?= $currentStatus === 'REJECTED' ? 'selected' : '' ?>>Rad etilgan</option>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-sm btn-secondary w-100">
                    <i class="bi bi-filter me-1"></i> Filtrlash
                </button>
            </div>
        </form>
    </div>

    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-custom table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Nomzod</th>
                        <th>Lavozim</th>
                        <th>Aloqa</th>
                        <th>Rezyume (CV)</th>
                        <th>Holati</th>
                        <th>Yuborilgan sana</th>
                        <th style="width: 100px;" class="text-end">Amal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($applications)): ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted">Arizalar mavjud emas</td></tr>
                    <?php else: ?>
                        <?php foreach ($applications as $app): ?>
                            <tr>
                                <td class="fw-bold text-dark"><?= e($app['full_name']) ?></td>
                                <td class="small text-truncate" style="max-width: 180px;"><?= e($app['vacancy_title']) ?></td>
                                <td class="small">
                                    <div><i class="bi bi-telephone me-1 text-muted"></i> <?= e($app['phone']) ?></div>
                                    <div class="text-muted"><i class="bi bi-envelope me-1"></i> <?= e($app['email']) ?></div>
                                </td>
                                <td>
                                    <a href="<?= asset($app['cv_file']) ?>" target="_blank" class="btn btn-sm btn-outline-primary py-1 px-2 rounded-pill small">
                                        <i class="bi bi-file-earmark-pdf me-1"></i> CV ko'rish
                                    </a>
                                </td>
                                <td>
                                    <?php 
                                    $bCls = 'bg-primary';
                                    if ($app['status'] === 'REVIEWING') $bCls = 'bg-warning text-dark';
                                    if ($app['status'] === 'ACCEPTED') $bCls = 'bg-success';
                                    if ($app['status'] === 'REJECTED') $bCls = 'bg-danger';
                                    ?>
                                    <span class="badge <?= $bCls ?> badge-status"><?= e($app['status']) ?></span>
                                </td>
                                <td class="text-muted small"><?= format_date($app['created_at']) ?></td>
                                <td class="text-end">
                                    <a href="<?= url('/admin/applications/show/' . $app['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 me-1" title="Ko'rish va baholash">
                                        <i class="bi bi-eye-fill text-primary"></i>
                                    </a>
                                    <a href="<?= url('/admin/applications/delete/' . $app['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 btn-delete-confirm" title="O'chirish">
                                        <i class="bi bi-trash-fill text-danger"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

