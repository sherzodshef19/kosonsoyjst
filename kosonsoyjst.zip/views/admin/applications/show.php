<div class="row g-4">
    <div class="col-lg-8">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title">Nomzod Arizasi: <?= e($application['full_name']) ?></h5>
                <a href="<?= url('/admin/applications') ?>" class="btn btn-sm btn-outline-secondary rounded-pill">
                    <i class="bi bi-arrow-left me-1"></i> Ro'yxatga qaytish
                </a>
            </div>
            <div class="admin-card-body">
                <div class="row g-3 mb-4 small text-secondary">
                    <div class="col-md-6">
                        <strong>Vakansiya:</strong> <span class="text-primary fw-bold"><?= e($vacancy['title_uz'] ?? 'Noma\'lum') ?></span>
                    </div>
                    <div class="col-md-6">
                        <strong>Bo'lim:</strong> <?= e($vacancy['department_uz'] ?? '') ?>
                    </div>
                    <div class="col-md-6">
                        <strong>Telefon:</strong> <a href="tel:<?= e($application['phone']) ?>"><?= e($application['phone']) ?></a>
                    </div>
                    <div class="col-md-6">
                        <strong>Email:</strong> <a href="mailto:<?= e($application['email']) ?>"><?= e($application['email']) ?></a>
                    </div>
                    <div class="col-md-6">
                        <strong>Yuborilgan sana:</strong> <?= format_date($application['created_at'], 'd.m.Y H:i') ?>
                    </div>
                    <div class="col-md-6">
                        <strong>Hozirgi holat:</strong> <span class="badge bg-primary"><?= e($application['status']) ?></span>
                    </div>
                </div>

                <div class="p-3 bg-light rounded-3 mb-4">
                    <strong class="d-block mb-1 text-dark small">Nomzod xabari / Qo'shimcha ma'lumot:</strong>
                    <p class="mb-0 text-secondary"><?= nl2br(e($application['message'] ?: 'Qo\'shimcha izoh qoldirilmagan.')) ?></p>
                </div>

                <div class="mb-4">
                    <h6 class="fw-bold mb-2">Yuklangan Rezyume (CV):</h6>
                    <a href="<?= asset($application['cv_file']) ?>" target="_blank" class="btn btn-outline-primary">
                        <i class="bi bi-download me-1"></i> CV faylini ochish va yuklab olish
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Status and Admin Notes -->
    <div class="col-lg-4">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title"><i class="bi bi-gear text-primary me-2"></i> Baholash va Status</h5>
            </div>
            <div class="admin-card-body">
                <form action="<?= url('/admin/applications/status/' . $application['id']) ?>" method="POST">
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Ariza holati</label>
                        <select name="status" class="form-select">
                            <option value="NEW" <?= $application['status'] === 'NEW' ? 'selected' : '' ?>>Yangi (Ko'rilmagan)</option>
                            <option value="REVIEWING" <?= $application['status'] === 'REVIEWING' ? 'selected' : '' ?>>Ko'rib chiqilmoqda (Suhbatga chaqirish)</option>
                            <option value="ACCEPTED" <?= $application['status'] === 'ACCEPTED' ? 'selected' : '' ?>>Qabul qilindi (Ishga olindi)</option>
                            <option value="REJECTED" <?= $application['status'] === 'REJECTED' ? 'selected' : '' ?>>Rad etildi (Mos kelmadi)</option>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="form-label small fw-semibold">HR / Admin qaydlari</label>
                        <textarea name="admin_notes" class="form-control" rows="4" placeholder="Suhbat natijasi, izohlar..."><?= e($application['admin_notes'] ?? '') ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 rounded-3">
                        <i class="bi bi-check2 me-1"></i> Saqlash
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

