<?php
$isEdit = !empty($vacancy);
$action = $isEdit ? url('/admin/vacancies/update/' . $vacancy['id']) : url('/admin/vacancies/store');
?>

<div class="admin-card">
    <div class="admin-card-header">
        <h5 class="admin-card-title"><?= $isEdit ? "Vakansiyani tahrirlash" : "Yangi vakansiya yaratish" ?></h5>
        <a href="<?= url('/admin/vacancies') ?>" class="btn btn-sm btn-outline-secondary rounded-pill">
            <i class="bi bi-arrow-left me-1"></i> Ro'yxatga qaytish
        </a>
    </div>

    <div class="admin-card-body">
        <form action="<?= $action ?>" method="POST">
            <?= csrf_field() ?>

            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Lavozim nomi (O'zbekcha) *</label>
                    <input type="text" name="title_uz" class="form-control" required value="<?= e($vacancy['title_uz'] ?? '') ?>" placeholder="Masalan: Axborot texnologiyalari o'qituvchisi">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Lavozim nomi (Ruscha)</label>
                    <input type="text" name="title_ru" class="form-control" value="<?= e($vacancy['title_ru'] ?? '') ?>">
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Kafedra / Bo'lim (O'zbekcha) *</label>
                    <input type="text" name="department_uz" class="form-control" required value="<?= e($vacancy['department_uz'] ?? '') ?>" placeholder="IT kafedrasi">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Ish tartibi (Bandlik turi) *</label>
                    <select name="employment_type" class="form-select">
                        <option value="full_time" <?= (($vacancy['employment_type'] ?? '') === 'full_time') ? 'selected' : '' ?>>To'liq stavka</option>
                        <option value="part_time" <?= (($vacancy['employment_type'] ?? '') === 'part_time') ? 'selected' : '' ?>>Yarim stavka</option>
                        <option value="internship" <?= (($vacancy['employment_type'] ?? '') === 'internship') ? 'selected' : '' ?>>Stajirovka</option>
                        <option value="contract" <?= (($vacancy['employment_type'] ?? '') === 'contract') ? 'selected' : '' ?>>Shartnoma asosida</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Oylik maosh matni</label>
                    <input type="text" name="salary_text" class="form-control" value="<?= e($vacancy['salary_text'] ?? 'Suhbat asosida') ?>">
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Ariza topshirishning so'nggi muddati</label>
                    <input type="date" name="deadline_date" class="form-control" value="<?= e($vacancy['deadline_date'] ?? '') ?>">
                </div>
                <div class="col-md-4 d-flex align-items-center">
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="vacAct" <?= !empty($vacancy['is_active']) ? 'checked' : ($isEdit ? '' : 'checked') ?>>
                        <label class="form-check-label small fw-semibold" for="vacAct">Vakansiya faol (Arizalar qabul qilinadi)</label>
                    </div>
                </div>

                <div class="col-12">
                    <label class="form-label small fw-semibold">Nomzodga qo'yiladigan talablar (O'zbekcha) *</label>
                    <textarea name="requirements_uz" class="form-control" rows="4" required><?= e($vacancy['requirements_uz'] ?? '') ?></textarea>
                </div>

                <div class="col-12">
                    <label class="form-label small fw-semibold">Asosiy vazifalar (O'zbekcha)</label>
                    <textarea name="responsibilities_uz" class="form-control" rows="4"><?= e($vacancy['responsibilities_uz'] ?? '') ?></textarea>
                </div>
            </div>

            <div class="border-top pt-3 d-flex justify-content-end gap-2">
                <a href="<?= url('/admin/vacancies') ?>" class="btn btn-light border px-4">Bekor qilish</a>
                <button type="submit" class="btn btn-primary px-4 fw-bold">Saqlash</button>
            </div>
        </form>
    </div>
</div>

