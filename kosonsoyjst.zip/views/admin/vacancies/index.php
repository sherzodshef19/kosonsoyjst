<div class="admin-card">
    <div class="admin-card-header flex-wrap gap-3">
        <div>
            <h5 class="admin-card-title mb-1">Vakansiyalar Ro'yxati</h5>
            <div class="text-muted small">Kollejning faol va arxivlangan bo'sh ish o'rinlari</div>
        </div>
        <a href="<?= url('/admin/vacancies/create') ?>" class="btn btn-primary rounded-pill btn-sm px-3">
            <i class="bi bi-briefcase me-1"></i> Yangi vakansiya e'lon qilish
        </a>
    </div>

    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-custom table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Lavozim</th>
                        <th>Kafedra / Bo'lim</th>
                        <th>Ish turi</th>
                        <th>Ish haqi</th>
                        <th>Muddat</th>
                        <th>Arizalar</th>
                        <th>Holati</th>
                        <th style="width: 100px;" class="text-end">Amal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($vacancies)): ?>
                        <tr><td colspan="8" class="text-center py-5 text-muted">Vakansiyalar mavjud emas</td></tr>
                    <?php else: ?>
                        <?php foreach ($vacancies as $vac): ?>
                            <tr>
                                <td class="fw-bold text-dark"><?= e($vac['title_uz']) ?></td>
                                <td class="small text-muted"><?= e($vac['department_uz']) ?></td>
                                <td><span class="badge bg-light text-secondary border"><?= e($vac['employment_type']) ?></span></td>
                                <td class="small text-success fw-bold"><?= e($vac['salary_text']) ?></td>
                                <td class="small text-muted"><?= $vac['deadline_date'] ? format_date($vac['deadline_date']) : '-' ?></td>
                                <td>
                                    <a href="<?= url('/admin/applications?vacancy_id=' . $vac['id']) ?>" class="badge bg-primary text-decoration-none">
                                        <?= (int)($vac['applications_count'] ?? 0) ?> ta ariza
                                    </a>
                                </td>
                                <td>
                                    <span class="badge bg-<?= $vac['is_active'] ? 'success' : 'secondary' ?> badge-status">
                                        <?= $vac['is_active'] ? 'Faol' : 'Yopilgan' ?>
                                    </span>
                                </td>
                                <td class="text-end">
                                    <a href="<?= url('/admin/vacancies/edit/' . $vac['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 me-1">
                                        <i class="bi bi-pencil-fill text-primary"></i>
                                    </a>
                                    <a href="<?= url('/admin/vacancies/delete/' . $vac['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 btn-delete-confirm">
                                        <i class="bi bi-trash-fill text-danger"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

