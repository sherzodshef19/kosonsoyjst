<div class="admin-card">
    <div class="admin-card-header flex-wrap gap-3">
        <div>
            <h5 class="admin-card-title mb-1">Audit Jurnali (Xavfsizlik & Harakatlar Tarixi)</h5>
            <div class="text-muted small">Administratorlar va foydalanuvchilarning barcha tizim harakatlari yozuvi</div>
        </div>
        <?php if (auth()['role_name'] === 'SUPER_ADMIN'): ?>
            <form action="<?= url('/admin/audit-logs/clear') ?>" method="POST" class="d-inline">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-outline-danger btn-sm rounded-pill px-3 btn-delete-confirm" data-message="30 kundan eski audit yozuvlarini tozalashni tasdiqlaysizmi?">
                    <i class="bi bi-trash3 me-1"></i> Eski loglarni tozalash
                </button>
            </form>
        <?php endif; ?>
    </div>

    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-custom table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width: 70px;">ID</th>
                        <th>Foydalanuvchi</th>
                        <th>Amal (Action)</th>
                        <th>Modul</th>
                        <th>Tafsilotlar</th>
                        <th>IP Manzil</th>
                        <th>Vaqt</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted">Audit loglari mavjud emas</td></tr>
                    <?php else: ?>
                        <?php foreach ($logs as $log): ?>
                            <tr>
                                <td class="text-muted small">#<?= (int)$log['id'] ?></td>
                                <td>
                                    <span class="fw-bold small text-dark"><?= e($log['username'] ?? 'Tizim / Mehmon') ?></span>
                                    <?php if (!empty($log['full_name'])): ?>
                                        <div class="text-muted" style="font-size: 0.72rem;"><?= e($log['full_name']) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php 
                                    $actCls = 'bg-primary';
                                    if ($log['action'] === 'DELETE') $actCls = 'bg-danger';
                                    if ($log['action'] === 'UPDATE' || $log['action'] === 'UPDATE_STATUS') $actCls = 'bg-warning text-dark';
                                    if ($log['action'] === 'LOGIN') $actCls = 'bg-info text-dark';
                                    if ($log['action'] === 'LOGOUT') $actCls = 'bg-secondary';
                                    if ($log['action'] === 'CREATE') $actCls = 'bg-success';
                                    ?>
                                    <span class="badge <?= $actCls ?> badge-status"><?= e($log['action']) ?></span>
                                </td>
                                <td><span class="badge bg-light text-secondary border"><?= e($log['module']) ?></span></td>
                                <td class="small text-truncate" style="max-width: 250px;" title="<?= e($log['details'] ?? '') ?>">
                                    <?= e($log['details'] ?? '-') ?>
                                </td>
                                <td><code class="small text-muted"><?= e($log['ip_address'] ?? '127.0.0.1') ?></code></td>
                                <td class="text-muted small"><?= format_date($log['created_at'], 'd.m.Y H:i:s') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination -->
    <?php if ($pagination['total_pages'] > 1): ?>
        <div class="p-3 border-top d-flex justify-content-between align-items-center">
            <span class="text-muted small">Jami yozuvlar: <?= $pagination['total'] ?></span>
            <ul class="pagination pagination-sm mb-0">
                <?php for ($i = 1; $i <= $pagination['total_pages']; $i++): ?>
                    <li class="page-item <?= $i === $pagination['current_page'] ? 'active' : '' ?>">
                        <a class="page-link" href="<?= url('/admin/audit-logs?page=' . $i) ?>">
                            <?= $i ?>
                        </a>
                    </li>
                <?php endfor; ?>
            </ul>
        </div>
    <?php endif; ?>
</div>

