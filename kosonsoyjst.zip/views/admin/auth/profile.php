<div class="row g-4">
    <!-- Col 1: Profile Info -->
    <div class="col-lg-6">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title"><i class="bi bi-person-circle text-primary me-2"></i> Profil Ma'lumotlari</h5>
            </div>
            <div class="admin-card-body">
                <form action="<?= url('/admin/profile/update') ?>" method="POST" enctype="multipart/form-data">
                    <?= csrf_field() ?>

                    <div class="text-center mb-4">
                        <img src="<?= asset($user['avatar'] ?: '/assets/images/avatar-default.png') ?>" id="avatar-preview" alt="Avatar" class="rounded-circle border border-3 border-light shadow-sm mb-2" style="width: 100px; height: 100px; object-fit: cover;">
                        <div>
                            <label class="btn btn-outline-secondary btn-sm rounded-pill">
                                <i class="bi bi-camera me-1"></i> Rasmni o'zgartirish
                                <input type="file" name="avatar" class="d-none" data-preview="avatar-preview" accept="image/*">
                            </label>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Foydalanuvchi nomi</label>
                        <input type="text" class="form-control bg-light" value="<?= e($user['username']) ?>" readonly disabled>
                        <div class="form-text small">Foydalanuvchi nomi o'zgarmasdir.</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">To'liq ism-familiya *</label>
                        <input type="text" name="full_name" class="form-control" value="<?= e($user['full_name']) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Elektron pochta *</label>
                        <input type="email" name="email" class="form-control" value="<?= e($user['email']) ?>" required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold small">Telefon raqam</label>
                        <input type="tel" name="phone" class="form-control" value="<?= e($user['phone'] ?? '') ?>">
                    </div>

                    <button type="submit" class="btn btn-primary rounded-3">
                        <i class="bi bi-check2-circle me-1"></i> Ma'lumotlarni saqlash
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Col 2: Password Change -->
    <div class="col-lg-6">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title"><i class="bi bi-key-fill text-warning me-2"></i> Xavfsizlik va Parolni O'zgartirish</h5>
            </div>
            <div class="admin-card-body">
                <form action="<?= url('/admin/profile/password') ?>" method="POST">
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Amaldagi joriy parol *</label>
                        <input type="password" name="old_password" class="form-control" required placeholder="••••••••">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Yangi parol *</label>
                        <input type="password" name="new_password" class="form-control" required minlength="6" placeholder="Kamida 6 ta belgi">
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold small">Yangi parolni tasdiqlash *</label>
                        <input type="password" name="confirm_password" class="form-control" required minlength="6" placeholder="Yangi parolni qayta kiriting">
                    </div>

                    <button type="submit" class="btn btn-warning rounded-3 fw-semibold">
                        <i class="bi bi-shield-lock me-1"></i> Parolni yangilash
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

