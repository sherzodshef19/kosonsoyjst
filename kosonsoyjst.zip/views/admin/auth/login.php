<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tizimga kirish - Kosonsoy Abu Ali ibn Sino nomidagi JST Admin</title>

    <!-- Favicon & Icons -->
    <link rel="icon" type="image/png" sizes="32x32" href="<?= asset('/assets/images/favicon-32x32.png') ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?= asset('/assets/images/favicon-16x16.png') ?>">
    <link rel="shortcut icon" href="<?= asset('/favicon.ico') ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?= asset('/assets/images/apple-touch-icon.png') ?>">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?= asset('/assets/css/loader.css') ?>">

    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #07192f 0%, #0b2545 50%, #133e87 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1.5rem;
        }
        .login-card {
            background: #ffffff;
            border-radius: 20px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.35);
            width: 100%;
            max-width: 440px;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .login-header {
            background: #f8fafc;
            padding: 2.25rem 2rem 1.75rem 2rem;
            text-align: center;
            border-bottom: 1px solid #e2e8f0;
        }
        .login-body {
            padding: 2.25rem 2rem;
        }
    </style>
</head>
<body>
    <div id="top-progress-bar"></div>

    <div class="login-card">
        <div class="login-header">
            <div class="mb-3">
                <img src="<?= asset('/assets/images/logo.png') ?>" alt="Logo" class="rounded-circle shadow-sm" style="width: 84px; height: 84px; object-fit: contain; filter: drop-shadow(0 4px 12px rgba(11,37,69,0.15));">
            </div>
            <h4 class="fw-bold mb-1 text-dark">KOSONSOY JST</h4>
            <p class="text-muted small mb-0">Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumi</p>
            <span class="badge bg-light text-primary border mt-2">Boshqaruv tizimi</span>
        </div>

        <div class="login-body">
            <?php if (has_flash('error')): ?>
                <div class="alert alert-danger py-2 small d-flex align-items-center gap-2 mb-3">
                    <i class="bi bi-exclamation-circle-fill"></i>
                    <div><?= e(flash('error')) ?></div>
                </div>
            <?php endif; ?>

            <?php if (has_flash('success')): ?>
                <div class="alert alert-success py-2 small d-flex align-items-center gap-2 mb-3">
                    <i class="bi bi-check-circle-fill"></i>
                    <div><?= e(flash('success')) ?></div>
                </div>
            <?php endif; ?>

            <form action="<?= url('/admin/login') ?>" method="POST">
                <?= csrf_field() ?>

                <div class="mb-3">
                    <label class="form-label fw-semibold small text-dark">Foydalanuvchi nomi yoki Email</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light text-muted"><i class="bi bi-person"></i></span>
                        <input type="text" name="username" class="form-control" required placeholder="admin" autofocus>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-semibold small text-dark">Parol</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light text-muted"><i class="bi bi-lock"></i></span>
                        <input type="password" name="password" class="form-control" required placeholder="••••••••">
                    </div>
                </div>

                <button type="submit" class="btn btn-primary w-100 py-2 fw-bold rounded-3 shadow-sm mb-3" style="background:#0b2545; border-color:#0b2545;">
                    <i class="bi bi-box-arrow-in-right me-1"></i> Tizimga kirish
                </button>

                <div class="text-center">
                    <a href="<?= url('/') ?>" class="text-muted small text-decoration-none">
                        <i class="bi bi-arrow-left me-1"></i> Saytga qaytish
                    </a>
                </div>
            </form>
        </div>
    </div>

    <script src="<?= asset('/assets/js/loader.js') ?>"></script>
</body>
</html>

