<div class="admin-card">
    <div class="admin-card-header flex-wrap gap-3">
        <div>
            <h5 class="admin-card-title mb-1">Yangiliklar Ro'yxati</h5>
            <div class="text-muted small">Kollej saytidagi barcha maqolalar va yangiliklar</div>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= url('/admin/news/create') ?>" class="btn btn-primary rounded-pill btn-sm px-3">
                <i class="bi bi-plus-lg me-1"></i> Yangi yangilik qo'shish
            </a>
        </div>
    </div>

    <!-- Filters -->
    <div class="p-3 bg-light border-bottom">
        <form action="<?= url('/admin/news') ?>" method="GET" class="row g-2 align-items-center">
            <div class="col-md-4">
                <input type="text" name="q" class="form-control form-control-sm" placeholder="Sarlavha bo'yicha qidiruv..." value="<?= e($search ?? '') ?>">
            </div>
            <div class="col-md-3">
                <select name="category_id" class="form-select form-select-sm">
                    <option value="">Barcha kategoriyalar</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= ($currentCat == $cat['id']) ? 'selected' : '' ?>>
                            <?= e($cat['name_uz']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <select name="status" class="form-select form-select-sm">
                    <option value="">Barcha statuslar</option>
                    <option value="published" <?= $currentStatus === 'published' ? 'selected' : '' ?>>Chop etilgan</option>
                    <option value="draft" <?= $currentStatus === 'draft' ? 'selected' : '' ?>>Qoralama</option>
                    <option value="archived" <?= $currentStatus === 'archived' ? 'selected' : '' ?>>Arxiv</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-sm btn-secondary w-100"><i class="bi bi-filter me-1"></i> Filtrlash</button>
            </div>
        </form>
    </div>

    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-custom table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width: 60px;">Rasm</th>
                        <th>Sarlavha</th>
                        <th>Kategoriya</th>
                        <th>Ko'rishlar</th>
                        <th>Holati</th>
                        <th>Chop etilgan</th>
                        <th style="width: 120px;" class="text-end">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($news)): ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted">Hech qanday yangilik topilmadi</td></tr>
                    <?php else: ?>
                        <?php foreach ($news as $item): ?>
                            <tr>
                                <td>
                                    <img src="<?= asset($item['image'] ?: '/assets/images/news-default.jpg') ?>" class="rounded-2" style="width: 50px; height: 38px; object-fit: cover;">
                                </td>
                                <td>
                                    <div class="fw-bold text-dark text-truncate" style="max-width: 280px;"><?= e($item['title_uz']) ?></div>
                                    <div class="text-muted small">
                                        <?php if ($item['is_featured']): ?>
                                            <span class="badge bg-warning text-dark me-1" style="font-size:0.68rem;">Asosiy</span>
                                        <?php endif; ?>
                                        <?php if ($item['is_announcement']): ?>
                                            <span class="badge bg-info text-dark me-1" style="font-size:0.68rem;">E'lon</span>
                                        <?php endif; ?>
                                        <?= e($item['slug']) ?>
                                    </div>
                                </td>
                                <td><span class="badge bg-light text-dark border"><?= e($item['cat_name_uz'] ?? 'Kategoriya') ?></span></td>
                                <td class="small"><i class="bi bi-eye me-1 text-muted"></i> <?= (int)$item['views_count'] ?></td>
                                <td>
                                    <?php 
                                    $stCls = 'bg-success';
                                    if ($item['status'] === 'draft') $stCls = 'bg-secondary';
                                    if ($item['status'] === 'archived') $stCls = 'bg-dark';
                                    ?>
                                    <span class="badge <?= $stCls ?> badge-status"><?= e($item['status']) ?></span>
                                </td>
                                <td class="text-muted small"><?= format_date($item['published_at']) ?></td>
                                <td class="text-end">
                                    <a href="<?= url('/news/' . $item['slug']) ?>" target="_blank" class="btn btn-sm btn-light border py-1 px-2 me-1" title="Saytda ko'rish">
                                        <i class="bi bi-box-arrow-up-right"></i>
                                    </a>
                                    <a href="<?= url('/admin/news/edit/' . $item['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 me-1" title="Tahrirlash">
                                        <i class="bi bi-pencil-fill text-primary"></i>
                                    </a>
                                    <a href="<?= url('/admin/news/delete/' . $item['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 btn-delete-confirm" title="O'chirish">
                                        <i class="bi bi-trash-fill text-danger"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination -->
    <?php if ($pagination['total_pages'] > 1): ?>
        <div class="p-3 border-top d-flex justify-content-between align-items-center">
            <span class="text-muted small">Jami: <?= $pagination['total'] ?> ta yangilik</span>
            <ul class="pagination pagination-sm mb-0">
                <?php for ($i = 1; $i <= $pagination['total_pages']; $i++): ?>
                    <li class="page-item <?= $i === $pagination['current_page'] ? 'active' : '' ?>">
                        <a class="page-link" href="<?= url('/admin/news?page=' . $i . ($currentCat ? '&category_id=' . $currentCat : '') . ($currentStatus ? '&status=' . $currentStatus : '') . ($search ? '&q=' . urlencode($search) : '')) ?>">
                            <?= $i ?>
                        </a>
                    </li>
                <?php endfor; ?>
            </ul>
        </div>
    <?php endif; ?>
</div>

