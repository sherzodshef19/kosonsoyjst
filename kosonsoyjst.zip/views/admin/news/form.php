<?php
$isEdit = !empty($news);
$action = $isEdit ? url('/admin/news/update/' . $news['id']) : url('/admin/news/store');
?>

<div class="admin-card">
    <div class="admin-card-header">
        <h5 class="admin-card-title"><?= $isEdit ? "Yangilikni tahrirlash" : "Yangi yangilik yaratish" ?></h5>
        <a href="<?= url('/admin/news') ?>" class="btn btn-sm btn-outline-secondary rounded-pill">
            <i class="bi bi-arrow-left me-1"></i> Ro'yxatga qaytish
        </a>
    </div>

    <div class="admin-card-body">
        <form action="<?= $action ?>" method="POST" enctype="multipart/form-data">
            <?= csrf_field() ?>

            <!-- Language Tabs -->
            <ul class="nav nav-pills mb-4" id="langTabs" role="tablist">
                <li class="nav-item">
                    <button class="nav-link active fw-semibold" id="uz-tab" data-bs-toggle="tab" data-bs-target="#tab-uz" type="button">🇺🇿 O'zbekcha (Asosiy)</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link fw-semibold" id="ru-tab" data-bs-toggle="tab" data-bs-target="#tab-ru" type="button">🇷🇺 Русский</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link fw-semibold" id="en-tab" data-bs-toggle="tab" data-bs-target="#tab-en" type="button">🇬🇧 English</button>
                </li>
            </ul>

            <div class="tab-content border p-3 rounded-3 mb-4 bg-light bg-opacity-50">
                <!-- Uzbek Tab -->
                <div class="tab-pane fade show active" id="tab-uz">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Sarlavha (O'zbekcha) *</label>
                        <input type="text" name="title_uz" class="form-control" required value="<?= e($news['title_uz'] ?? '') ?>" placeholder="Yangilik sarlavhasini kiriting...">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Qisqacha ma'lumot (Anons)</label>
                        <textarea name="summary_uz" class="form-control" rows="2" placeholder="Qisqacha mazmun..."><?= e($news['summary_uz'] ?? '') ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">To'liq matn (HTML / Matn) *</label>
                        <textarea name="content_uz" class="form-control" rows="10" required><?= e($news['content_uz'] ?? '') ?></textarea>
                    </div>
                </div>

                <!-- Russian Tab -->
                <div class="tab-pane fade" id="tab-ru">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Заголовок (Русский)</label>
                        <input type="text" name="title_ru" class="form-control" value="<?= e($news['title_ru'] ?? '') ?>" placeholder="Заголовок новости...">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Краткое описание (Анонс)</label>
                        <textarea name="summary_ru" class="form-control" rows="2"><?= e($news['summary_ru'] ?? '') ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Полный текст новости</label>
                        <textarea name="content_ru" class="form-control" rows="10"><?= e($news['content_ru'] ?? '') ?></textarea>
                    </div>
                </div>

                <!-- English Tab -->
                <div class="tab-pane fade" id="tab-en">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Title (English)</label>
                        <input type="text" name="title_en" class="form-control" value="<?= e($news['title_en'] ?? '') ?>" placeholder="News title in English...">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Summary</label>
                        <textarea name="summary_en" class="form-control" rows="2"><?= e($news['summary_en'] ?? '') ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Full Content</label>
                        <textarea name="content_en" class="form-control" rows="10"><?= e($news['content_en'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>

            <!-- Parameters Grid -->
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <label class="form-label fw-semibold small">Kategoriya *</label>
                    <select name="category_id" class="form-select" required>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>" <?= (($news['category_id'] ?? 0) == $cat['id']) ? 'selected' : '' ?>>
                                <?= e($cat['name_uz']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold small">Holati *</label>
                    <select name="status" class="form-select" required>
                        <option value="published" <?= (($news['status'] ?? 'published') === 'published') ? 'selected' : '' ?>>Chop etilgan</option>
                        <option value="draft" <?= (($news['status'] ?? '') === 'draft') ? 'selected' : '' ?>>Qoralama (Draft)</option>
                        <option value="archived" <?= (($news['status'] ?? '') === 'archived') ? 'selected' : '' ?>>Arxiv</option>
                    </select>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold small">Chop etish sanasi</label>
                    <input type="datetime-local" name="published_at" class="form-control" value="<?= !empty($news['published_at']) ? date('Y-m-d\TH:i', strtotime($news['published_at'])) : date('Y-m-d\TH:i') ?>">
                </div>

                <div class="col-md-6">
                    <label class="form-label fw-semibold small">SEO Slug (Ixtiyoriy)</label>
                    <input type="text" name="slug" class="form-control" value="<?= e($news['slug'] ?? '') ?>" placeholder="avtomatik-yaratiladi">
                </div>

                <div class="col-md-6">
                    <label class="form-label fw-semibold small">Teglar (Tags)</label>
                    <select name="tags[]" class="form-select" multiple size="3">
                        <?php foreach ($tags as $tag): ?>
                            <option value="<?= $tag['id'] ?>" <?= in_array($tag['id'], $newsTags ?? []) ? 'selected' : '' ?>>
                                <?= e($tag['name_uz']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <!-- Image Uploads -->
            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <label class="form-label fw-semibold small">Asosiy muqova rasmi (Cover Image)</label>
                    <input type="file" name="image" class="form-control" accept="image/*" data-preview="news-main-preview">
                    <?php if (!empty($news['image'])): ?>
                        <div class="mt-2">
                            <img src="<?= asset($news['image']) ?>" id="news-main-preview" class="rounded-3 border" style="max-height: 120px;">
                        </div>
                    <?php else: ?>
                        <div class="mt-2">
                            <img src="" id="news-main-preview" class="rounded-3 border d-none" style="max-height: 120px;">
                        </div>
                    <?php endif; ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label fw-semibold small">Ko'p rasmli galereya (Bir nechta tanlash mumkin)</label>
                    <input type="file" name="gallery_images[]" class="form-control" accept="image/*" multiple>
                    <div class="form-text small">Maqola ichida ko'rinadigan qo'shimcha rasmlar.</div>

                    <?php if (!empty($gallery)): ?>
                        <div class="d-flex gap-2 flex-wrap mt-2">
                            <?php foreach ($gallery as $g): ?>
                                <div class="position-relative">
                                    <img src="<?= asset($g['image_path']) ?>" class="rounded-2 border" style="width: 60px; height: 50px; object-fit: cover;">
                                    <a href="<?= url('/admin/news/gallery-delete/' . $g['id']) ?>" class="badge bg-danger position-absolute top-0 end-0 m-1 text-decoration-none" title="O'chirish">&times;</a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Flags -->
            <div class="d-flex gap-4 mb-4">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="is_featured" value="1" id="isFeatured" <?= !empty($news['is_featured']) ? 'checked' : '' ?>>
                    <label class="form-check-label fw-semibold small" for="isFeatured">
                        <i class="bi bi-star-fill text-warning me-1"></i> Asosiy yangilik (Featured News)
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="is_announcement" value="1" id="isAnnouncement" <?= !empty($news['is_announcement']) ? 'checked' : '' ?>>
                    <label class="form-check-label fw-semibold small" for="isAnnouncement">
                        <i class="bi bi-megaphone-fill text-info me-1"></i> Muhim e'lon
                    </label>
                </div>
            </div>

            <div class="border-top pt-3 d-flex justify-content-end gap-2">
                <a href="<?= url('/admin/news') ?>" class="btn btn-light border px-4">Bekor qilish</a>
                <button type="submit" class="btn btn-primary px-4 fw-bold">
                    <i class="bi bi-check2-circle me-1"></i> Saqlash
                </button>
            </div>
        </form>
    </div>
</div>

