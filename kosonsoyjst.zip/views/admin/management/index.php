<div class="admin-card">
    <div class="admin-card-header flex-wrap gap-3">
        <div>
            <h5 class="admin-card-title mb-1">Rahbariyat Ro'yxati</h5>
            <div class="text-muted small">Direktor, o'rinbosarlar va bo'lim boshliqlari</div>
        </div>
        <a href="<?= url('/admin/management/create') ?>" class="btn btn-primary rounded-pill btn-sm px-3">
            <i class="bi bi-person-plus-fill me-1"></i> Yangi rahbar qo'shish
        </a>
    </div>

    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-custom table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width: 60px;">Rasm</th>
                        <th>F.I.Sh</th>
                        <th>Lavozim</th>
                        <th>Kategoriya</th>
                        <th>Telefon / Qabul</th>
                        <th>Holati</th>
                        <th style="width: 100px;" class="text-end">Amal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($management)): ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted">Ma'lumotlar mavjud emas</td></tr>
                    <?php else: ?>
                        <?php foreach ($management as $m): ?>
                            <tr>
                                <td>
                                    <img src="<?= asset($m['image'] ?: '/assets/images/avatar-default.png') ?>" class="rounded-circle" style="width: 45px; height: 45px; object-fit: cover;">
                                </td>
                                <td class="fw-bold text-dark"><?= e($m['full_name_uz']) ?></td>
                                <td class="small"><?= e($m['position_uz']) ?></td>
                                <td><span class="badge bg-light text-primary border text-uppercase"><?= e($m['category']) ?></span></td>
                                <td class="small">
                                    <div><i class="bi bi-telephone text-muted me-1"></i> <?= e($m['phone'] ?? '-') ?></div>
                                    <div class="text-muted" style="font-size:0.75rem;"><i class="bi bi-clock me-1"></i> <?= e($m['reception_days_uz'] ?? '-') ?></div>
                                </td>
                                <td>
                                    <span class="badge bg-<?= $m['is_active'] ? 'success' : 'secondary' ?> badge-status">
                                        <?= $m['is_active'] ? 'Faol' : 'Nofaol' ?>
                                    </span>
                                </td>
                                <td class="text-end">
                                    <a href="<?= url('/admin/management/edit/' . $m['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 me-1" title="Tahrirlash">
                                        <i class="bi bi-pencil-fill text-primary"></i>
                                    </a>
                                    <a href="<?= url('/admin/management/delete/' . $m['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 btn-delete-confirm" title="O'chirish">
                                        <i class="bi bi-trash-fill text-danger"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

