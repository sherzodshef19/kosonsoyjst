<?php
$isEdit = !empty($member);
$action = $isEdit ? url('/admin/management/update/' . $member['id']) : url('/admin/management/store');
?>

<div class="admin-card">
    <div class="admin-card-header">
        <h5 class="admin-card-title"><?= $isEdit ? "Rahbar ma'lumotlarini tahrirlash" : "Yangi rahbar qo'shish" ?></h5>
        <a href="<?= url('/admin/management') ?>" class="btn btn-sm btn-outline-secondary rounded-pill">
            <i class="bi bi-arrow-left me-1"></i> Ro'yxatga qaytish
        </a>
    </div>

    <div class="admin-card-body">
        <form action="<?= $action ?>" method="POST" enctype="multipart/form-data">
            <?= csrf_field() ?>

            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">F.I.Sh (O'zbekcha) *</label>
                    <input type="text" name="full_name_uz" class="form-control" required value="<?= e($member['full_name_uz'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">F.I.Sh (Ruscha)</label>
                    <input type="text" name="full_name_ru" class="form-control" value="<?= e($member['full_name_ru'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">F.I.Sh (Inglizcha)</label>
                    <input type="text" name="full_name_en" class="form-control" value="<?= e($member['full_name_en'] ?? '') ?>">
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Lavozim (O'zbekcha) *</label>
                    <input type="text" name="position_uz" class="form-control" required value="<?= e($member['position_uz'] ?? '') ?>" placeholder="Masalan: Kollej Direktori">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Lavozim (Ruscha)</label>
                    <input type="text" name="position_ru" class="form-control" value="<?= e($member['position_ru'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Lavozim (Inglizcha)</label>
                    <input type="text" name="position_en" class="form-control" value="<?= e($member['position_en'] ?? '') ?>">
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Kategoriya *</label>
                    <select name="category" class="form-select" required>
                        <option value="director" <?= (($member['category'] ?? '') === 'director') ? 'selected' : '' ?>>Direktor</option>
                        <option value="deputy_director" <?= (($member['category'] ?? '') === 'deputy_director') ? 'selected' : '' ?>>Direktor o'rinbosari</option>
                        <option value="department_head" <?= (($member['category'] ?? '') === 'department_head') ? 'selected' : '' ?>>Bo'lim boshlig'i</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Telefon</label>
                    <input type="tel" name="phone" class="form-control" value="<?= e($member['phone'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Elektron pochta</label>
                    <input type="email" name="email" class="form-control" value="<?= e($member['email'] ?? '') ?>">
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Qabul kunlari (O'zbekcha)</label>
                    <input type="text" name="reception_days_uz" class="form-control" value="<?= e($member['reception_days_uz'] ?? '') ?>" placeholder="Dushanba va Chorshanba: 09:00 - 12:00">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Qabul kunlari (Ruscha)</label>
                    <input type="text" name="reception_days_ru" class="form-control" value="<?= e($member['reception_days_ru'] ?? '') ?>">
                </div>

                <div class="col-12">
                    <label class="form-label small fw-semibold">Biografiya va mehnat faoliyati (O'zbekcha)</label>
                    <textarea name="bio_uz" class="form-control" rows="4"><?= e($member['bio_uz'] ?? '') ?></textarea>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Fotosurat</label>
                    <input type="file" name="image" class="form-control" accept="image/*" data-preview="mgmt-preview">
                    <?php if (!empty($member['image'])): ?>
                        <div class="mt-2">
                            <img src="<?= asset($member['image']) ?>" id="mgmt-preview" class="rounded-3 border" style="width: 80px; height: 80px; object-fit: cover;">
                        </div>
                    <?php else: ?>
                        <div class="mt-2">
                            <img src="" id="mgmt-preview" class="rounded-3 border d-none" style="width: 80px; height: 80px; object-fit: cover;">
                        </div>
                    <?php endif; ?>
                </div>

                <div class="col-md-3">
                    <label class="form-label small fw-semibold">Tartib raqami</label>
                    <input type="number" name="sort_order" class="form-control" value="<?= (int)($member['sort_order'] ?? 0) ?>">
                </div>

                <div class="col-md-3 d-flex align-items-center">
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="actM" <?= !empty($member['is_active']) ? 'checked' : ($isEdit ? '' : 'checked') ?>>
                        <label class="form-check-label small fw-semibold" for="actM">Saytda ko'rsatish</label>
                    </div>
                </div>
            </div>

            <div class="border-top pt-3 d-flex justify-content-end gap-2">
                <a href="<?= url('/admin/management') ?>" class="btn btn-light border px-4">Bekor qilish</a>
                <button type="submit" class="btn btn-primary px-4 fw-bold">Saqlash</button>
            </div>
        </form>
    </div>
</div>

