<div class="row g-4">
    <!-- List -->
    <div class="col-lg-8">
        <div class="admin-card">
            <div class="admin-card-header d-flex justify-content-between align-items-center">
                <h5 class="admin-card-title mb-0">Ta'lim yo'nalishlari va mutaxassisliklar</h5>
                <span class="badge bg-primary rounded-pill"><?= count($programs) ?> ta yo'nalish</span>
            </div>
            <div class="admin-card-body p-0">
                <div class="table-responsive">
                    <table class="table table-custom table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th style="width: 60px;">Belgi</th>
                                <th>Yo'nalish nomi</th>
                                <th>Teglar / Muddat</th>
                                <th style="width: 70px;">Tartib</th>
                                <th style="width: 80px;">Holat</th>
                                <th style="width: 110px;" class="text-end">Amallar</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($programs)): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4 text-muted">
                                        Hozircha ta'lim yo'nalishlari qo'shilmagan.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($programs as $prog): ?>
                                    <tr>
                                        <td>
                                            <div class="bg-<?= e($prog['icon_color'] ?: 'primary') ?> text-white rounded-3 d-inline-flex align-items-center justify-content-center shadow-sm" style="width: 42px; height: 42px; font-size: 1.25rem;">
                                                <i class="bi <?= e($prog['icon']) ?>"></i>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fw-bold text-dark fs-6"><?= e($prog['title_uz']) ?></div>
                                            <div class="text-muted small text-truncate" style="max-width: 280px;">
                                                <?= e($prog['description_uz']) ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-wrap gap-1">
                                                <?php if (!empty($prog['badge_category_uz'])): ?>
                                                    <span class="badge bg-light text-primary border" style="font-size: 0.72rem;"><?= e($prog['badge_category_uz']) ?></span>
                                                <?php endif; ?>
                                                <?php if (!empty($prog['duration_uz'])): ?>
                                                    <span class="badge bg-light text-secondary border" style="font-size: 0.72rem;"><?= e($prog['duration_uz']) ?></span>
                                                <?php endif; ?>
                                                <?php if (!empty($prog['type_uz'])): ?>
                                                    <span class="badge bg-light text-success border" style="font-size: 0.72rem;"><?= e($prog['type_uz']) ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="text-center fw-semibold"><?= (int)$prog['sort_order'] ?></td>
                                        <td>
                                            <a href="<?= url('/admin/programs/toggle/' . $prog['id']) ?>" class="badge bg-<?= $prog['is_active'] ? 'success' : 'secondary' ?> text-decoration-none" title="Holatni o'zgartirish">
                                                <?= $prog['is_active'] ? 'Faol' : 'Nofaol' ?>
                                            </a>
                                        </td>
                                        <td class="text-end">
                                            <button class="btn btn-sm btn-light border py-1 px-2 me-1" data-bs-toggle="modal" data-bs-target="#editProg<?= $prog['id'] ?>" title="Tahrirlash">
                                                <i class="bi bi-pencil-fill text-primary"></i>
                                            </button>
                                            <a href="<?= url('/admin/programs/delete/' . $prog['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 btn-delete-confirm" title="O'chirish" onclick="return confirm('Haqiqatan ham bu yo\'nalishni o\'chirmoqchimisiz?');">
                                                <i class="bi bi-trash-fill text-danger"></i>
                                            </a>
                                        </td>
                                    </tr>

                                    <!-- Edit Modal -->
                                    <div class="modal fade" id="editProg<?= $prog['id'] ?>" tabindex="-1">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <form action="<?= url('/admin/programs/update/' . $prog['id']) ?>" method="POST">
                                                    <?= csrf_field() ?>
                                                    <div class="modal-header">
                                                        <h5 class="modal-title fs-6 fw-bold">Yo'nalishni tahrirlash</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row g-3">
                                                            <div class="col-md-12">
                                                                <label class="form-label small fw-semibold">Yo'nalish nomi (O'zbekcha) *</label>
                                                                <input type="text" name="title_uz" class="form-control" value="<?= e($prog['title_uz']) ?>" required>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label class="form-label small fw-semibold">Nomi (Ruscha)</label>
                                                                <input type="text" name="title_ru" class="form-control" value="<?= e($prog['title_ru'] ?? '') ?>">
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label class="form-label small fw-semibold">Nomi (Inglizcha)</label>
                                                                <input type="text" name="title_en" class="form-control" value="<?= e($prog['title_en'] ?? '') ?>">
                                                            </div>
                                                            <div class="col-12">
                                                                <label class="form-label small fw-semibold">Qisqacha tavsif (O'zbekcha)</label>
                                                                <textarea name="description_uz" class="form-control" rows="3"><?= e($prog['description_uz'] ?? '') ?></textarea>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label class="form-label small fw-semibold">Tavsif (Ruscha)</label>
                                                                <textarea name="description_ru" class="form-control" rows="2"><?= e($prog['description_ru'] ?? '') ?></textarea>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label class="form-label small fw-semibold">Tavsif (Inglizcha)</label>
                                                                <textarea name="description_en" class="form-control" rows="2"><?= e($prog['description_en'] ?? '') ?></textarea>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label class="form-label small fw-semibold">Belgi (Bootstrap Icon) *</label>
                                                                <input type="text" name="icon" class="form-control" value="<?= e($prog['icon']) ?>" placeholder="bi-heart-pulse-fill">
                                                                <small class="text-muted">Masalan: bi-heart-pulse-fill, bi-capsule, bi-bandaid-fill</small>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label class="form-label small fw-semibold">Belgi rangi</label>
                                                                <select name="icon_color" class="form-select">
                                                                    <option value="primary" <?= $prog['icon_color'] === 'primary' ? 'selected' : '' ?>>Moviy (Primary)</option>
                                                                    <option value="danger" <?= $prog['icon_color'] === 'danger' ? 'selected' : '' ?>>Qizil (Danger)</option>
                                                                    <option value="success" <?= $prog['icon_color'] === 'success' ? 'selected' : '' ?>>Yashil (Success)</option>
                                                                    <option value="warning" <?= $prog['icon_color'] === 'warning' ? 'selected' : '' ?>>Sariq/Zarrin (Warning)</option>
                                                                    <option value="info" <?= $prog['icon_color'] === 'info' ? 'selected' : '' ?>>Ko'k/Zangori (Info)</option>
                                                                    <option value="secondary" <?= $prog['icon_color'] === 'secondary' ? 'selected' : '' ?>>Kulrang (Secondary)</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label class="form-label small fw-semibold">Soha tegi (Kategoriya)</label>
                                                                <input type="text" name="badge_category_uz" class="form-control" value="<?= e($prog['badge_category_uz'] ?? 'Tibbiyot') ?>">
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label class="form-label small fw-semibold">O'qish muddati</label>
                                                                <input type="text" name="duration_uz" class="form-control" value="<?= e($prog['duration_uz'] ?? '3 yil') ?>" placeholder="3 yil">
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label class="form-label small fw-semibold">Ta'lim shakli / Turi</label>
                                                                <input type="text" name="type_uz" class="form-control" value="<?= e($prog['type_uz'] ?? 'Grant / Shartnoma') ?>">
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label class="form-label small fw-semibold">Tartib raqami</label>
                                                                <input type="number" name="sort_order" class="form-control" value="<?= (int)$prog['sort_order'] ?>">
                                                            </div>
                                                            <div class="col-md-6 d-flex align-items-center mt-4">
                                                                <div class="form-check form-switch">
                                                                    <input class="form-check-input" type="checkbox" name="is_active" id="editActive<?= $prog['id'] ?>" <?= $prog['is_active'] ? 'checked' : '' ?>>
                                                                    <label class="form-check-label fw-semibold" for="editActive<?= $prog['id'] ?>">Saytda ko'rsatish (Faol)</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Bekor qilish</button>
                                                        <button type="submit" class="btn btn-primary btn-sm">Saqlash</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Form -->
    <div class="col-lg-4">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title mb-0">Yangi yo'nalish qo'shish</h5>
            </div>
            <div class="admin-card-body">
                <form action="<?= url('/admin/programs/store') ?>" method="POST">
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Yo'nalish nomi *</label>
                        <input type="text" name="title_uz" class="form-control" required placeholder="Masalan: Hamshiralik ishi">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Qisqacha tavsif *</label>
                        <textarea name="description_uz" class="form-control" rows="3" required placeholder="Kasb haqida qisqacha ma'lumot..."></textarea>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Belgi (Icon)</label>
                            <input type="text" name="icon" class="form-control" value="bi-heart-pulse-fill" placeholder="bi-heart-pulse-fill">
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Rangi</label>
                            <select name="icon_color" class="form-select">
                                <option value="primary" selected>Moviy</option>
                                <option value="danger">Qizil</option>
                                <option value="success">Yashil</option>
                                <option value="warning">Sariq</option>
                                <option value="info">Zangori</option>
                            </select>
                        </div>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Soha tegi</label>
                            <input type="text" name="badge_category_uz" class="form-control" value="Tibbiyot" placeholder="Tibbiyot">
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold">O'qish muddati</label>
                            <input type="text" name="duration_uz" class="form-control" value="3 yil" placeholder="3 yil">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Ta'lim shakli</label>
                        <input type="text" name="type_uz" class="form-control" value="Grant / Shartnoma" placeholder="Grant / Shartnoma">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Tartib raqami</label>
                        <input type="number" name="sort_order" class="form-control" value="0">
                    </div>

                    <div class="mb-4 form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_active" id="newActive" checked>
                        <label class="form-check-label fw-semibold" for="newActive">Faol holatda saqlash</label>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 py-2">
                        <i class="bi bi-plus-circle me-1"></i> Saqlash va qo'shish
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

