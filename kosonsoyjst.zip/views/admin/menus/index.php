<div class="row g-4">
    <!-- Menu List -->
    <div class="col-lg-8">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title">Sayt Menyulari</h5>
            </div>
            <div class="admin-card-body p-0">
                <div class="table-responsive">
                    <table class="table table-custom table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Nomi</th>
                                <th>URL Manzili</th>
                                <th>Joylashuvi</th>
                                <th>Tartib</th>
                                <th>Holat</th>
                                <th style="width: 100px;" class="text-end">Amal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($menus as $m): ?>
                                <tr>
                                    <td class="fw-bold text-dark"><?= e($m['title_uz']) ?></td>
                                    <td><code class="small text-muted"><?= e($m['url']) ?></code></td>
                                    <td><span class="badge bg-light text-primary border text-uppercase"><?= e($m['location']) ?></span></td>
                                    <td><?= (int)$m['sort_order'] ?></td>
                                    <td>
                                        <span class="badge bg-<?= $m['is_active'] ? 'success' : 'secondary' ?> badge-status">
                                            <?= $m['is_active'] ? 'Faol' : 'Nofaol' ?>
                                        </span>
                                    </td>
                                    <td class="text-end">
                                        <button class="btn btn-sm btn-light border py-1 px-2 me-1" data-bs-toggle="modal" data-bs-target="#editMenu<?= $m['id'] ?>">
                                            <i class="bi bi-pencil-fill text-primary"></i>
                                        </button>
                                        <a href="<?= url('/admin/menus/delete/' . $m['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 btn-delete-confirm">
                                            <i class="bi bi-trash-fill text-danger"></i>
                                        </a>
                                    </td>
                                </tr>

                                <!-- Edit Menu Modal -->
                                <div class="modal fade" id="editMenu<?= $m['id'] ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="<?= url('/admin/menus/update/' . $m['id']) ?>" method="POST">
                                                <?= csrf_field() ?>
                                                <div class="modal-header">
                                                    <h5 class="modal-title fs-6 fw-bold">Menyu bandini tahrirlash</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Nomi (O'zbekcha) *</label>
                                                        <input type="text" name="title_uz" class="form-control" value="<?= e($m['title_uz']) ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Nomi (Ruscha)</label>
                                                        <input type="text" name="title_ru" class="form-control" value="<?= e($m['title_ru'] ?? '') ?>">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Nomi (Inglizcha)</label>
                                                        <input type="text" name="title_en" class="form-control" value="<?= e($m['title_en'] ?? '') ?>">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Havola (URL) *</label>
                                                        <input type="text" name="url" class="form-control" value="<?= e($m['url']) ?>" required>
                                                    </div>
                                                    <div class="row g-2 mb-3">
                                                        <div class="col-6">
                                                            <label class="form-label small fw-semibold">Joylashuvi</label>
                                                            <select name="location" class="form-select">
                                                                <option value="header" <?= $m['location'] === 'header' ? 'selected' : '' ?>>Header</option>
                                                                <option value="footer" <?= $m['location'] === 'footer' ? 'selected' : '' ?>>Footer</option>
                                                                <option value="quick_links" <?= $m['location'] === 'quick_links' ? 'selected' : '' ?>>Tezkor havolalar</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-6">
                                                            <label class="form-label small fw-semibold">Ochilish turi</label>
                                                            <select name="target" class="form-select">
                                                                <option value="_self" <?= $m['target'] === '_self' ? 'selected' : '' ?>>Shu sahifada (_self)</option>
                                                                <option value="_blank" <?= $m['target'] === '_blank' ? 'selected' : '' ?>>Yangi oynada (_blank)</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Tartib raqami</label>
                                                        <input type="number" name="sort_order" class="form-control" value="<?= (int)$m['sort_order'] ?>">
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="actM<?= $m['id'] ?>" <?= $m['is_active'] ? 'checked' : '' ?>>
                                                        <label class="form-check-label small fw-semibold" for="actM<?= $m['id'] ?>">Faol</label>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Yopish</button>
                                                    <button type="submit" class="btn btn-primary btn-sm px-3">Saqlash</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Add Form -->
    <div class="col-lg-4">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title"><i class="bi bi-plus-circle text-primary me-2"></i> Yangi Menyu Bandi</h5>
            </div>
            <div class="admin-card-body">
                <form action="<?= url('/admin/menus/store') ?>" method="POST">
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Nomi (O'zbekcha) *</label>
                        <input type="text" name="title_uz" class="form-control" required placeholder="Masalan: Biz haqimizda">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Havola (URL) *</label>
                        <input type="text" name="url" class="form-control" required placeholder="/about yoki https://...">
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Joylashuvi</label>
                            <select name="location" class="form-select">
                                <option value="header">Header</option>
                                <option value="footer">Footer</option>
                                <option value="quick_links">Tezkor</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Tartib</label>
                            <input type="number" name="sort_order" class="form-control" value="0">
                        </div>
                    </div>

                    <div class="form-check mb-4">
                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="menuAct" checked>
                        <label class="form-check-label small fw-semibold" for="menuAct">Faol</label>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 rounded-3">
                        <i class="bi bi-plus-lg me-1"></i> Qo'shish
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

