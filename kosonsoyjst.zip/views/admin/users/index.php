<div class="row g-4">
    <!-- Users List -->
    <div class="col-lg-8">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title">Foydalanuvchilar (Administratorlar)</h5>
            </div>
            <div class="admin-card-body p-0">
                <div class="table-responsive">
                    <table class="table table-custom table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th style="width: 50px;">Avatar</th>
                                <th>Ism-familiya</th>
                                <th>Login / Email</th>
                                <th>Roli</th>
                                <th>Holat</th>
                                <th style="width: 100px;" class="text-end">Amal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $u): ?>
                                <tr>
                                    <td>
                                        <img src="<?= asset($u['avatar'] ?: '/assets/images/avatar-default.png') ?>" class="rounded-circle" style="width: 38px; height: 38px; object-fit: cover;">
                                    </td>
                                    <td class="fw-bold text-dark"><?= e($u['full_name']) ?></td>
                                    <td class="small">
                                        <div class="font-monospace text-primary fw-semibold"><?= e($u['username']) ?></div>
                                        <div class="text-muted"><?= e($u['email']) ?></div>
                                    </td>
                                    <td>
                                        <span class="badge bg-primary bg-opacity-10 text-primary border">
                                            <?= e($u['role_title']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?= $u['status'] === 'active' ? 'success' : 'secondary' ?> badge-status">
                                            <?= $u['status'] ?>
                                        </span>
                                    </td>
                                    <td class="text-end">
                                        <button class="btn btn-sm btn-light border py-1 px-2 me-1" data-bs-toggle="modal" data-bs-target="#editUserModal<?= $u['id'] ?>">
                                            <i class="bi bi-pencil-fill text-primary"></i>
                                        </button>
                                        <?php if ($u['id'] !== auth()['id']): ?>
                                            <a href="<?= url('/admin/users/delete/' . $u['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 btn-delete-confirm">
                                                <i class="bi bi-trash-fill text-danger"></i>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>

                                <!-- Edit Modal -->
                                <div class="modal fade" id="editUserModal<?= $u['id'] ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="<?= url('/admin/users/update/' . $u['id']) ?>" method="POST">
                                                <?= csrf_field() ?>
                                                <div class="modal-header">
                                                    <h5 class="modal-title fs-6 fw-bold">Foydalanuvchini tahrirlash</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">To'liq ism-familiya *</label>
                                                        <input type="text" name="full_name" class="form-control" value="<?= e($u['full_name']) ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Foydalanuvchi nomi (Login) *</label>
                                                        <input type="text" name="username" class="form-control" value="<?= e($u['username']) ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Elektron pochta *</label>
                                                        <input type="email" name="email" class="form-control" value="<?= e($u['email']) ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Roli *</label>
                                                        <select name="role_id" class="form-select">
                                                            <?php foreach ($roles as $r): ?>
                                                                <option value="<?= $r['id'] ?>" <?= $u['role_id'] == $r['id'] ? 'selected' : '' ?>>
                                                                    <?= e($r['display_name']) ?>
                                                                </option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Yangi parol (Bo'sh qoldirilsa o'zgarmaydi)</label>
                                                        <input type="password" name="password" class="form-control" placeholder="••••••••">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Holati</label>
                                                        <select name="status" class="form-select">
                                                            <option value="active" <?= $u['status'] === 'active' ? 'selected' : '' ?>>Faol</option>
                                                            <option value="inactive" <?= $u['status'] === 'inactive' ? 'selected' : '' ?>>Bloklangan</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Yopish</button>
                                                    <button type="submit" class="btn btn-primary btn-sm px-3">Saqlash</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Add Form -->
    <div class="col-lg-4">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title"><i class="bi bi-person-plus text-primary me-2"></i> Yangi Foydalanuvchi</h5>
            </div>
            <div class="admin-card-body">
                <form action="<?= url('/admin/users/store') ?>" method="POST">
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">To'liq ism-familiya *</label>
                        <input type="text" name="full_name" class="form-control" required placeholder="Masalan: Sobirov Alisher">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Login (Username) *</label>
                        <input type="text" name="username" class="form-control" required placeholder="alisher">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Elektron pochta *</label>
                        <input type="email" name="email" class="form-control" required placeholder="alisher@kosonsoykollej.uz">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Parol *</label>
                        <input type="password" name="password" class="form-control" required minlength="6" placeholder="Kamida 6 belgi">
                    </div>

                    <div class="mb-4">
                        <label class="form-label small fw-semibold">Foydalanuvchi roli *</label>
                        <select name="role_id" class="form-select" required>
                            <?php foreach ($roles as $r): ?>
                                <option value="<?= $r['id'] ?>" <?= $r['name'] === 'EDITOR' ? 'selected' : '' ?>>
                                    <?= e($r['display_name']) ?> (<?= e($r['name']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 rounded-3">
                        <i class="bi bi-person-plus-fill me-1"></i> Foydalanuvchini yaratish
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

