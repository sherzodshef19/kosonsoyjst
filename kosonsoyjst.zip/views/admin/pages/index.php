<div class="admin-card">
    <div class="admin-card-header flex-wrap gap-3">
        <div>
            <h5 class="admin-card-title mb-1">Sayt Sahifalari</h5>
            <div class="text-muted small">Maxsus statik va dinamik sahifalar boshqaruvi</div>
        </div>
        <a href="<?= url('/admin/pages/create') ?>" class="btn btn-primary rounded-pill btn-sm px-3">
            <i class="bi bi-plus-lg me-1"></i> Yangi sahifa yaratish
        </a>
    </div>

    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-custom table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Sarlavha (O'zbekcha)</th>
                        <th>Slug (URL)</th>
                        <th>Holati</th>
                        <th>Yaratilgan sana</th>
                        <th style="width: 120px;" class="text-end">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($pages)): ?>
                        <tr><td colspan="5" class="text-center py-5 text-muted">Sahifalar mavjud emas</td></tr>
                    <?php else: ?>
                        <?php foreach ($pages as $p): ?>
                            <tr>
                                <td class="fw-bold text-dark"><?= e($p['title_uz']) ?></td>
                                <td class="text-muted small"><code>/pages/<?= e($p['slug']) ?></code></td>
                                <td>
                                    <span class="badge bg-<?= $p['is_active'] ? 'success' : 'secondary' ?> badge-status">
                                        <?= $p['is_active'] ? 'Faol' : 'Nofaol' ?>
                                    </span>
                                </td>
                                <td class="text-muted small"><?= format_date($p['created_at']) ?></td>
                                <td class="text-end">
                                    <a href="<?= url('/pages/' . $p['slug']) ?>" target="_blank" class="btn btn-sm btn-light border py-1 px-2 me-1" title="Saytda ko'rish">
                                        <i class="bi bi-box-arrow-up-right"></i>
                                    </a>
                                    <a href="<?= url('/admin/pages/edit/' . $p['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 me-1" title="Tahrirlash">
                                        <i class="bi bi-pencil-fill text-primary"></i>
                                    </a>
                                    <a href="<?= url('/admin/pages/delete/' . $p['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 btn-delete-confirm" title="O'chirish">
                                        <i class="bi bi-trash-fill text-danger"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

