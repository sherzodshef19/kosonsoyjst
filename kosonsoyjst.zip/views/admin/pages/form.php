<?php
$isEdit = !empty($page);
$action = $isEdit ? url('/admin/pages/update/' . $page['id']) : url('/admin/pages/store');
?>

<div class="admin-card">
    <div class="admin-card-header">
        <h5 class="admin-card-title"><?= $isEdit ? "Sahifani tahrirlash" : "Yangi sahifa yaratish" ?></h5>
        <a href="<?= url('/admin/pages') ?>" class="btn btn-sm btn-outline-secondary rounded-pill">
            <i class="bi bi-arrow-left me-1"></i> Ro'yxatga qaytish
        </a>
    </div>

    <div class="admin-card-body">
        <form action="<?= $action ?>" method="POST" enctype="multipart/form-data">
            <?= csrf_field() ?>

            <!-- Language Tabs -->
            <ul class="nav nav-pills mb-4" id="pageLangTabs" role="tablist">
                <li class="nav-item">
                    <button class="nav-link active fw-semibold" data-bs-toggle="tab" data-bs-target="#tab-page-uz" type="button">🇺🇿 O'zbekcha</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link fw-semibold" data-bs-toggle="tab" data-bs-target="#tab-page-ru" type="button">🇷🇺 Русский</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link fw-semibold" data-bs-toggle="tab" data-bs-target="#tab-page-en" type="button">🇬🇧 English</button>
                </li>
            </ul>

            <div class="tab-content border p-3 rounded-3 mb-4 bg-light bg-opacity-50">
                <div class="tab-pane fade show active" id="tab-page-uz">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Sahifa sarlavhasi (O'zbekcha) *</label>
                        <input type="text" name="title_uz" class="form-control" required value="<?= e($page['title_uz'] ?? '') ?>" placeholder="Masalan: Kollej Tarixi">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Sahifa matni (HTML / Matn) *</label>
                        <textarea name="content_uz" class="form-control" rows="12" required><?= e($page['content_uz'] ?? '') ?></textarea>
                    </div>
                </div>

                <div class="tab-pane fade" id="tab-page-ru">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Заголовок страницы (Русский)</label>
                        <input type="text" name="title_ru" class="form-control" value="<?= e($page['title_ru'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Контент страницы</label>
                        <textarea name="content_ru" class="form-control" rows="12"><?= e($page['content_ru'] ?? '') ?></textarea>
                    </div>
                </div>

                <div class="tab-pane fade" id="tab-page-en">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Page Title (English)</label>
                        <input type="text" name="title_en" class="form-control" value="<?= e($page['title_en'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Page Content</label>
                        <textarea name="content_en" class="form-control" rows="12"><?= e($page['content_en'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">URL Slug (Ixtiyoriy)</label>
                    <input type="text" name="slug" class="form-control" value="<?= e($page['slug'] ?? '') ?>" placeholder="kollej-tarixi">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Banner rasmi</label>
                    <input type="file" name="banner_image" class="form-control" accept="image/*">
                    <?php if (!empty($page['banner_image'])): ?>
                        <div class="mt-2">
                            <img src="<?= asset($page['banner_image']) ?>" class="rounded-3 border" style="max-height: 80px;">
                        </div>
                    <?php endif; ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Meta Title</label>
                    <input type="text" name="meta_title" class="form-control" value="<?= e($page['meta_title'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Meta Description</label>
                    <input type="text" name="meta_description" class="form-control" value="<?= e($page['meta_description'] ?? '') ?>">
                </div>

                <div class="col-12">
                    <div class="form-check mt-2">
                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="actP" <?= !empty($page['is_active']) ? 'checked' : ($isEdit ? '' : 'checked') ?>>
                        <label class="form-check-label small fw-semibold" for="actP">Sahifa faol va ommaga ko'rinadi</label>
                    </div>
                </div>
            </div>

            <div class="border-top pt-3 d-flex justify-content-end gap-2">
                <a href="<?= url('/admin/pages') ?>" class="btn btn-light border px-4">Bekor qilish</a>
                <button type="submit" class="btn btn-primary px-4 fw-bold">Saqlash</button>
            </div>
        </form>
    </div>
</div>

