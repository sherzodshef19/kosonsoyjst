<!-- Admin Dashboard Overview -->
<div class="row g-4 mb-4">
    <!-- Stat 1: News -->
    <div class="col-xl-3 col-sm-6">
        <div class="admin-stat-card">
            <div>
                <div class="stat-number"><?= $stats['news_count'] ?></div>
                <div class="stat-title">Jami Yangiliklar</div>
            </div>
            <div class="stat-icon-bubble bubble-primary">
                <i class="bi bi-newspaper"></i>
            </div>
        </div>
    </div>

    <!-- Stat 2: Inquiries -->
    <div class="col-xl-3 col-sm-6">
        <div class="admin-stat-card">
            <div>
                <div class="stat-number text-primary"><?= $stats['messages_count'] ?></div>
                <div class="stat-title">Murojaatlar (<?= $stats['messages_new'] ?> yangi)</div>
            </div>
            <div class="stat-icon-bubble bubble-warning">
                <i class="bi bi-envelope-paper-fill"></i>
            </div>
        </div>
    </div>

    <!-- Stat 3: Vacancies & Applications -->
    <div class="col-xl-3 col-sm-6">
        <div class="admin-stat-card">
            <div>
                <div class="stat-number text-success"><?= $stats['applications_count'] ?></div>
                <div class="stat-title">Nomzodlar arizasi (<?= $stats['applications_new'] ?> yangi)</div>
            </div>
            <div class="stat-icon-bubble bubble-success">
                <i class="bi bi-file-earmark-person-fill"></i>
            </div>
        </div>
    </div>

    <!-- Stat 4: Documents -->
    <div class="col-xl-3 col-sm-6">
        <div class="admin-stat-card">
            <div>
                <div class="stat-number text-danger"><?= $stats['documents_count'] ?></div>
                <div class="stat-title">Me'yoriy hujjatlar</div>
            </div>
            <div class="stat-icon-bubble bubble-danger">
                <i class="bi bi-file-earmark-pdf-fill"></i>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Recent Virtual Reception Messages -->
    <div class="col-lg-6">
        <div class="admin-card h-100">
            <div class="admin-card-header">
                <h5 class="admin-card-title"><i class="bi bi-chat-left-dots text-primary me-2"></i> So'nggi Murojaatlar</h5>
                <a href="<?= url('/admin/messages') ?>" class="btn btn-sm btn-outline-primary rounded-pill">Barchasi</a>
            </div>
            <div class="admin-card-body p-0">
                <div class="table-responsive">
                    <table class="table table-custom table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Kod</th>
                                <th>Murojaatchi</th>
                                <th>Mavzu</th>
                                <th>Holati</th>
                                <th>Amal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recentMessages)): ?>
                                <tr><td colspan="5" class="text-center py-4 text-muted">Murojaatlar yo'q</td></tr>
                            <?php else: ?>
                                <?php foreach ($recentMessages as $msg): ?>
                                    <tr>
                                        <td class="font-monospace small fw-bold"><?= e($msg['tracking_code']) ?></td>
                                        <td>
                                            <div class="fw-bold small"><?= e($msg['full_name']) ?></div>
                                            <div class="text-muted" style="font-size:0.75rem;"><?= e($msg['phone']) ?></div>
                                        </td>
                                        <td class="small text-truncate" style="max-width: 140px;"><?= e($msg['subject']) ?></td>
                                        <td>
                                            <span class="badge bg-<?= $msg['status'] === 'NEW' ? 'primary' : ($msg['status'] === 'ANSWERED' ? 'success' : 'warning') ?> badge-status">
                                                <?= e($msg['status']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="<?= url('/admin/messages/show/' . $msg['id']) ?>" class="btn btn-sm btn-light border py-1 px-2" title="Ko'rish">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Applications -->
    <div class="col-lg-6">
        <div class="admin-card h-100">
            <div class="admin-card-header">
                <h5 class="admin-card-title"><i class="bi bi-briefcase text-success me-2"></i> So'nggi Vakansiya Arizalari</h5>
                <a href="<?= url('/admin/applications') ?>" class="btn btn-sm btn-outline-primary rounded-pill">Barchasi</a>
            </div>
            <div class="admin-card-body p-0">
                <div class="table-responsive">
                    <table class="table table-custom table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Nomzod</th>
                                <th>Lavozim</th>
                                <th>Holati</th>
                                <th>Amal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recentApplications)): ?>
                                <tr><td colspan="4" class="text-center py-4 text-muted">Arizalar mavjud emas</td></tr>
                            <?php else: ?>
                                <?php foreach ($recentApplications as $app): ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold small"><?= e($app['full_name']) ?></div>
                                            <div class="text-muted" style="font-size:0.75rem;"><?= e($app['phone']) ?></div>
                                        </td>
                                        <td class="small text-truncate" style="max-width: 150px;"><?= e($app['vacancy_title']) ?></td>
                                        <td>
                                            <span class="badge bg-<?= $app['status'] === 'NEW' ? 'primary' : ($app['status'] === 'ACCEPTED' ? 'success' : 'secondary') ?> badge-status">
                                                <?= e($app['status']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="<?= url('/admin/applications/show/' . $app['id']) ?>" class="btn btn-sm btn-light border py-1 px-2" title="Ko'rish">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mt-1">
    <!-- Recent News -->
    <div class="col-lg-8">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title"><i class="bi bi-newspaper text-info me-2"></i> So'nggi Qo'shilgan Yangiliklar</h5>
                <a href="<?= url('/admin/news/create') ?>" class="btn btn-sm btn-primary rounded-pill"><i class="bi bi-plus"></i> Yangi yangilik</a>
            </div>
            <div class="admin-card-body p-0">
                <div class="table-responsive">
                    <table class="table table-custom table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Rasm</th>
                                <th>Sarlavha</th>
                                <th>Kategoriya</th>
                                <th>Ko'rishlar</th>
                                <th>Sana</th>
                                <th>Amal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentNews as $n): ?>
                                <tr>
                                    <td>
                                        <img src="<?= asset($n['image'] ?: '/assets/images/news-default.jpg') ?>" class="rounded-2" style="width: 45px; height: 35px; object-fit: cover;">
                                    </td>
                                    <td class="fw-semibold small text-truncate" style="max-width: 220px;"><?= e($n['title_uz']) ?></td>
                                    <td><span class="badge bg-light text-dark border"><?= e($n['cat_name'] ?? 'Kategoriya') ?></span></td>
                                    <td class="small"><i class="bi bi-eye text-muted me-1"></i> <?= (int)$n['views_count'] ?></td>
                                    <td class="text-muted small"><?= format_date($n['published_at']) ?></td>
                                    <td>
                                        <a href="<?= url('/admin/news/edit/' . $n['id']) ?>" class="btn btn-sm btn-light border py-1 px-2"><i class="bi bi-pencil"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Audit Logs Summary -->
    <div class="col-lg-4">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title"><i class="bi bi-clock-history text-secondary me-2"></i> Tizim Harakatlari</h5>
                <a href="<?= url('/admin/audit-logs') ?>" class="btn btn-sm btn-link text-decoration-none p-0 small">Barchasi</a>
            </div>
            <div class="admin-card-body">
                <div class="d-flex flex-column gap-3 small">
                    <?php foreach ($recentLogs as $log): ?>
                        <div class="border-bottom pb-2">
                            <div class="d-flex justify-content-between text-muted" style="font-size:0.75rem;">
                                <strong><?= e($log['username'] ?? 'Tizim') ?></strong>
                                <span><?= format_date($log['created_at'], 'H:i d.m') ?></span>
                            </div>
                            <div class="fw-semibold text-dark"><?= e($log['action']) ?> - <?= e($log['module']) ?></div>
                            <?php if (!empty($log['details'])): ?>
                                <div class="text-secondary small text-truncate"><?= e($log['details']) ?></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

