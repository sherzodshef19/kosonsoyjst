<?php
$isEdit = !empty($album);
$action = $isEdit ? url('/admin/gallery/update/' . $album['id']) : url('/admin/gallery/store');
?>

<div class="admin-card">
    <div class="admin-card-header">
        <h5 class="admin-card-title"><?= $isEdit ? "Albomni tahrirlash" : "Yangi fotogalereya albomi yaratish" ?></h5>
        <a href="<?= url('/admin/gallery') ?>" class="btn btn-sm btn-outline-secondary rounded-pill">
            <i class="bi bi-arrow-left me-1"></i> Ro'yxatga qaytish
        </a>
    </div>

    <div class="admin-card-body">
        <form action="<?= $action ?>" method="POST" enctype="multipart/form-data">
            <?= csrf_field() ?>

            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Albom nomi (O'zbekcha) *</label>
                    <input type="text" name="title_uz" class="form-control" required value="<?= e($album['title_uz'] ?? '') ?>" placeholder="Kollej sport musobaqalari">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Albom nomi (Ruscha)</label>
                    <input type="text" name="title_ru" class="form-control" value="<?= e($album['title_ru'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Albom nomi (Inglizcha)</label>
                    <input type="text" name="title_en" class="form-control" value="<?= e($album['title_en'] ?? '') ?>">
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Tadbir sanasi</label>
                    <input type="date" name="event_date" class="form-control" value="<?= e($album['event_date'] ?? date('Y-m-d')) ?>">
                </div>
                <div class="col-md-6 d-flex align-items-center">
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="actG" <?= !empty($album['is_active']) ? 'checked' : ($isEdit ? '' : 'checked') ?>>
                        <label class="form-check-label small fw-semibold" for="actG">Albomni saytda ko'rsatish</label>
                    </div>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Muqova rasmi (Cover Image) <?= $isEdit ? '' : '*' ?></label>
                    <input type="file" name="cover_image" class="form-control" accept="image/*" <?= $isEdit ? '' : 'required' ?> data-preview="gal-preview">
                    <?php if (!empty($album['cover_image'])): ?>
                        <div class="mt-2">
                            <img src="<?= asset($album['cover_image']) ?>" id="gal-preview" class="rounded-3 border" style="max-height: 100px;">
                        </div>
                    <?php else: ?>
                        <div class="mt-2">
                            <img src="" id="gal-preview" class="rounded-3 border d-none" style="max-height: 100px;">
                        </div>
                    <?php endif; ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Albomga rasmlar yuklash (Bir nechta tanlang)</label>
                    <input type="file" name="images[]" class="form-control" accept="image/*" multiple>
                    <div class="form-text small">Ushbu albom ichida chiqadigan rasmlar.</div>
                </div>
            </div>

            <!-- Existing album photos -->
            <?php if (!empty($album['images'])): ?>
                <div class="border-top pt-3 mb-4">
                    <h6 class="fw-bold mb-3">Albomdagi mavjud rasmlar:</h6>
                    <div class="row g-2">
                        <?php foreach ($album['images'] as $img): ?>
                            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                                <div class="position-relative border rounded-3 overflow-hidden shadow-sm">
                                    <img src="<?= asset($img['image_path']) ?>" class="w-100" style="height: 100px; object-fit: cover;">
                                    <a href="<?= url('/admin/gallery/image-delete/' . $img['id']) ?>" class="badge bg-danger position-absolute top-0 end-0 m-1 text-decoration-none btn-delete-confirm" title="O'chirish">&times;</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="border-top pt-3 d-flex justify-content-end gap-2">
                <a href="<?= url('/admin/gallery') ?>" class="btn btn-light border px-4">Bekor qilish</a>
                <button type="submit" class="btn btn-primary px-4 fw-bold">Saqlash</button>
            </div>
        </form>
    </div>
</div>

