<div class="admin-card">
    <div class="admin-card-header flex-wrap gap-3">
        <div>
            <h5 class="admin-card-title mb-1">Fotogalereya Albomlari</h5>
            <div class="text-muted small">Kollej tadbirlari va hayotidan fotolavhalar albomlari</div>
        </div>
        <a href="<?= url('/admin/gallery/create') ?>" class="btn btn-primary rounded-pill btn-sm px-3">
            <i class="bi bi-camera-fill me-1"></i> Yangi albom yaratish
        </a>
    </div>

    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-custom table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width: 70px;">Muqova</th>
                        <th>Albom nomi</th>
                        <th>Rasmlar soni</th>
                        <th>Sana</th>
                        <th>Holati</th>
                        <th style="width: 100px;" class="text-end">Amal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($albums)): ?>
                        <tr><td colspan="6" class="text-center py-5 text-muted">Fotogalereyada albomlar yo'q</td></tr>
                    <?php else: ?>
                        <?php foreach ($albums as $a): ?>
                            <tr>
                                <td>
                                    <img src="<?= asset($a['cover_image']) ?>" class="rounded-2" style="width: 60px; height: 45px; object-fit: cover;">
                                </td>
                                <td class="fw-bold text-dark"><?= e($a['title_uz']) ?></td>
                                <td>
                                    <span class="badge bg-light text-primary border">
                                        <i class="bi bi-image me-1"></i> <?= count($a['images'] ?? []) ?> ta rasm
                                    </span>
                                </td>
                                <td class="text-muted small"><?= $a['event_date'] ? format_date($a['event_date']) : '-' ?></td>
                                <td>
                                    <span class="badge bg-<?= $a['is_active'] ? 'success' : 'secondary' ?> badge-status">
                                        <?= $a['is_active'] ? 'Faol' : 'Nofaol' ?>
                                    </span>
                                </td>
                                <td class="text-end">
                                    <a href="<?= url('/admin/gallery/edit/' . $a['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 me-1">
                                        <i class="bi bi-pencil-fill text-primary"></i>
                                    </a>
                                    <a href="<?= url('/admin/gallery/delete/' . $a['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 btn-delete-confirm">
                                        <i class="bi bi-trash-fill text-danger"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

