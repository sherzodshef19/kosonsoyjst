<div class="admin-card">
    <div class="admin-card-header flex-wrap gap-3">
        <div>
            <h5 class="admin-card-title mb-1">Rasmiy Me'yoriy Hujjatlar</h5>
            <div class="text-muted small">Qonunlar, qarorlar, kollej ustavi va litsenziyalari</div>
        </div>
        <a href="<?= url('/admin/documents/create') ?>" class="btn btn-primary rounded-pill btn-sm px-3">
            <i class="bi bi-file-earmark-plus me-1"></i> Yangi hujjat yuklash
        </a>
    </div>

    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-custom table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Hujjat nomi</th>
                        <th>Kategoriya</th>
                        <th>Raqam / Sana</th>
                        <th>Fayl hajmi</th>
                        <th>Yuklanishlar</th>
                        <th>Holati</th>
                        <th style="width: 100px;" class="text-end">Amal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($documents)): ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted">Hujjatlar mavjud emas</td></tr>
                    <?php else: ?>
                        <?php foreach ($documents as $doc): ?>
                            <tr>
                                <td class="fw-bold text-dark">
                                    <i class="bi bi-file-earmark-pdf-fill text-danger me-2"></i>
                                    <?= e($doc['title_uz']) ?>
                                </td>
                                <td><span class="badge bg-light text-primary border text-uppercase"><?= e($doc['category']) ?></span></td>
                                <td class="small">
                                    <div><?= e($doc['doc_number'] ?? '-') ?></div>
                                    <div class="text-muted"><?= $doc['doc_date'] ? format_date($doc['doc_date']) : '-' ?></div>
                                </td>
                                <td class="small text-muted"><?= e($doc['file_size'] ?? '-') ?></td>
                                <td class="small"><i class="bi bi-download text-muted me-1"></i> <?= (int)$doc['download_count'] ?></td>
                                <td>
                                    <span class="badge bg-<?= $doc['is_active'] ? 'success' : 'secondary' ?> badge-status">
                                        <?= $doc['is_active'] ? 'Faol' : 'Nofaol' ?>
                                    </span>
                                </td>
                                <td class="text-end">
                                    <a href="<?= url('/admin/documents/edit/' . $doc['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 me-1">
                                        <i class="bi bi-pencil-fill text-primary"></i>
                                    </a>
                                    <a href="<?= url('/admin/documents/delete/' . $doc['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 btn-delete-confirm">
                                        <i class="bi bi-trash-fill text-danger"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

