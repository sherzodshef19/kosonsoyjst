<?php
$isEdit = !empty($doc);
$action = $isEdit ? url('/admin/documents/update/' . $doc['id']) : url('/admin/documents/store');
?>

<div class="admin-card">
    <div class="admin-card-header">
        <h5 class="admin-card-title"><?= $isEdit ? "Hujjatni tahrirlash" : "Yangi rasmiy hujjat yuklash" ?></h5>
        <a href="<?= url('/admin/documents') ?>" class="btn btn-sm btn-outline-secondary rounded-pill">
            <i class="bi bi-arrow-left me-1"></i> Ro'yxatga qaytish
        </a>
    </div>

    <div class="admin-card-body">
        <form action="<?= $action ?>" method="POST" enctype="multipart/form-data">
            <?= csrf_field() ?>

            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Hujjat nomi (O'zbekcha) *</label>
                    <input type="text" name="title_uz" class="form-control" required value="<?= e($doc['title_uz'] ?? '') ?>" placeholder="Kollej Davlat Ustavi">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Hujjat nomi (Ruscha)</label>
                    <input type="text" name="title_ru" class="form-control" value="<?= e($doc['title_ru'] ?? '') ?>">
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Kategoriya *</label>
                    <select name="category" class="form-select" required>
                        <option value="college_charter" <?= (($doc['category'] ?? '') === 'college_charter') ? 'selected' : '' ?>>Kollej Ustavi</option>
                        <option value="license" <?= (($doc['category'] ?? '') === 'license') ? 'selected' : '' ?>>Davlat Litsenziyasi</option>
                        <option value="law" <?= (($doc['category'] ?? '') === 'law') ? 'selected' : '' ?>>Qonun</option>
                        <option value="decree" <?= (($doc['category'] ?? '') === 'decree') ? 'selected' : '' ?>>Prezident/Hukumat Qarori</option>
                        <option value="certificate" <?= (($doc['category'] ?? '') === 'certificate') ? 'selected' : '' ?>>Sertifikat</option>
                        <option value="other" <?= (($doc['category'] ?? '') === 'other') ? 'selected' : '' ?>>Boshqa</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Hujjat raqami</label>
                    <input type="text" name="doc_number" class="form-control" value="<?= e($doc['doc_number'] ?? '') ?>" placeholder="№ 12-U">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Qabul qilingan sana</label>
                    <input type="date" name="doc_date" class="form-control" value="<?= e($doc['doc_date'] ?? '') ?>">
                </div>

                <div class="col-md-8">
                    <label class="form-label small fw-semibold">Hujjat fayli (PDF, DOCX) <?= $isEdit ? '' : '*' ?></label>
                    <input type="file" name="file" class="form-control" accept=".pdf,.doc,.docx" <?= $isEdit ? '' : 'required' ?>>
                    <?php if (!empty($doc['file_path'])): ?>
                        <div class="form-text small mt-1">
                            Amaldagi fayl: <a href="<?= asset($doc['file_path']) ?>" target="_blank"><?= basename($doc['file_path']) ?></a>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="col-md-4 d-flex align-items-center">
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="actDoc" <?= !empty($doc['is_active']) ? 'checked' : ($isEdit ? '' : 'checked') ?>>
                        <label class="form-check-label small fw-semibold" for="actDoc">Faol va yuklab olinadi</label>
                    </div>
                </div>
            </div>

            <div class="border-top pt-3 d-flex justify-content-end gap-2">
                <a href="<?= url('/admin/documents') ?>" class="btn btn-light border px-4">Bekor qilish</a>
                <button type="submit" class="btn btn-primary px-4 fw-bold">Saqlash</button>
            </div>
        </form>
    </div>
</div>

