<div class="admin-card">
    <div class="admin-card-header">
        <div>
            <h5 class="admin-card-title mb-1">Sayt Sozlamalari</h5>
            <div class="text-muted small">Global konfiguratsiya, aloqa ma'lumotlari, Telegram bot va SEO sozlamalari</div>
        </div>
    </div>

    <div class="admin-card-body">
        <form action="<?= url('/admin/settings/update') ?>" method="POST" enctype="multipart/form-data">
            <?= csrf_field() ?>

            <!-- Tabs Navigation -->
            <ul class="nav nav-pills mb-4" id="settingTabs">
                <li class="nav-item">
                    <button class="nav-link active fw-semibold" data-bs-toggle="tab" data-bs-target="#tab-general" type="button"><i class="bi bi-gear-fill me-1"></i> Asosiy</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link fw-semibold" data-bs-toggle="tab" data-bs-target="#tab-contacts" type="button"><i class="bi bi-telephone-fill me-1"></i> Aloqa & Manzillar</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link fw-semibold" data-bs-toggle="tab" data-bs-target="#tab-social" type="button"><i class="bi bi-share-fill me-1"></i> Ijtimoiy Tarmoqlar</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link fw-semibold" data-bs-toggle="tab" data-bs-target="#tab-telegram" type="button"><i class="bi bi-telegram me-1"></i> Telegram Integratsiya</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link fw-semibold" data-bs-toggle="tab" data-bs-target="#tab-homepage" type="button"><i class="bi bi-quote me-1"></i> Direktor Murojaati</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link fw-semibold" data-bs-toggle="tab" data-bs-target="#tab-seo" type="button"><i class="bi bi-search me-1"></i> SEO Meta</button>
                </li>
            </ul>

            <div class="tab-content border p-4 rounded-3 bg-light bg-opacity-50 mb-4">
                <!-- General Tab -->
                <div class="tab-pane fade show active" id="tab-general">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Muassasa nomi (Sayt nomi) *</label>
                            <input type="text" name="site_name" class="form-control" value="<?= e($settings['site_name'] ?? 'Kosonsoy Kolleji') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Sayt shiori (Tagline)</label>
                            <input type="text" name="site_tagline" class="form-control" value="<?= e($settings['site_tagline'] ?? '') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Texnik ishlar rejimi (Maintenance mode)</label>
                            <select name="maintenance_mode" class="form-select">
                                <option value="0" <?= (($settings['maintenance_mode'] ?? '0') === '0') ? 'selected' : '' ?>>O'chirilgan (Sayt ochiq)</option>
                                <option value="1" <?= (($settings['maintenance_mode'] ?? '0') === '1') ? 'selected' : '' ?>>Yoqilgan (Vaqtincha yopiq)</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Contacts Tab -->
                <div class="tab-pane fade" id="tab-contacts">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Asosiy telefon raqam</label>
                            <input type="text" name="site_phone" class="form-control" value="<?= e($settings['site_phone'] ?? '') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Ishonch telefoni (Hotline)</label>
                            <input type="text" name="site_hotline" class="form-control" value="<?= e($settings['site_hotline'] ?? '1199') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Elektron pochta</label>
                            <input type="email" name="site_email" class="form-control" value="<?= e($settings['site_email'] ?? '') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Ish vaqti tartibi</label>
                            <input type="text" name="working_hours" class="form-control" value="<?= e($settings['working_hours'] ?? '') ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-semibold">Rasmiy yuridik manzil</label>
                            <input type="text" name="site_address" class="form-control" value="<?= e($settings['site_address'] ?? '') ?>">
                        </div>

                        <div class="col-12 mt-4 pt-3 border-top">
                            <label class="form-label fw-bold text-dark d-flex align-items-center gap-2">
                                <i class="bi bi-geo-alt-fill text-danger fs-5"></i>
                                <span>Google Maps Xarita kodi (Location Embed)</span>
                            </label>
                            <p class="text-muted small mb-2">
                                Google Xaritalar (Google Maps) orqali texnikum lokatsiyasini oching &rarr; <strong>"Ulashish" (Поделиться)</strong> &rarr; <strong>"Xaritani joylashtirish" (Встраивание карт)</strong> &rarr; <strong>"HTML-kodni nusxalash"</strong> tugmasini bosing va olingan kodni yoki havola (src)ni quyidagi maydonga joylashtiring:
                            </p>
                            <textarea name="google_maps_iframe" id="googleMapsInput" class="form-control font-monospace small" rows="3" placeholder="<iframe src=&quot;https://www.google.com/maps/embed?pb=...&quot; ...></iframe> yoki https://www.google.com/maps/embed?pb=..."><?= e($settings['google_maps_iframe'] ?? '') ?></textarea>
                            <div class="form-text small text-secondary mt-1">
                                <i class="bi bi-info-circle me-1"></i> To'liq <code>&lt;iframe ...&gt;</code> tegi yoki to'g'ridan-to‘g‘ri <code>https://www.google.com/maps/embed?...</code> manzilini kiritishingiz mumkin. Tizim uni avtomatik ravishda moslashtiradi.
                            </div>
                        </div>

                        <?php if (!empty($settings['google_maps_iframe'])): ?>
                            <div class="col-12 mt-3">
                                <div class="card border rounded-3 p-3 bg-white shadow-sm">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <span class="small fw-bold text-dark"><i class="bi bi-eye text-primary me-1"></i> Xaritaning joriy ko'rinishi (Oldindan ko'rish):</span>
                                        <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-2 py-1">Faol ulandi</span>
                                    </div>
                                    <div class="rounded-2 overflow-hidden border" style="height: 280px;">
                                        <iframe src="<?= e($settings['google_maps_iframe']) ?>" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Social Tab -->
                <div class="tab-pane fade" id="tab-social">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold"><i class="bi bi-telegram text-primary me-1"></i> Telegram kanali</label>
                            <input type="url" name="telegram_channel" class="form-control" value="<?= e($settings['telegram_channel'] ?? '') ?>" placeholder="https://t.me/...">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold"><i class="bi bi-instagram text-danger me-1"></i> Instagram sahifasi</label>
                            <input type="url" name="instagram_url" class="form-control" value="<?= e($settings['instagram_url'] ?? '') ?>" placeholder="https://instagram.com/...">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold"><i class="bi bi-facebook text-primary me-1"></i> Facebook sahifasi</label>
                            <input type="url" name="facebook_url" class="form-control" value="<?= e($settings['facebook_url'] ?? '') ?>" placeholder="https://facebook.com/...">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold"><i class="bi bi-youtube text-danger me-1"></i> YouTube kanali</label>
                            <input type="url" name="youtube_url" class="form-control" value="<?= e($settings['youtube_url'] ?? '') ?>" placeholder="https://youtube.com/...">
                        </div>
                    </div>
                </div>

                <!-- Telegram Integration Tab -->
                <div class="tab-pane fade" id="tab-telegram">
                    <div class="alert alert-info py-2 small mb-4">
                        <i class="bi bi-info-circle me-1"></i> Ushbu bot orqali yangi kelib tushgan murojaatlar va rezyumelar haqida ma'muriyat Telegram kanaliga yoki shaxsiy chatiga tezkor bildirishnoma keladi.
                    </div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Telegram Bot Token</label>
                            <input type="text" name="telegram_bot_token" class="form-control font-monospace" value="<?= e($settings['telegram_bot_token'] ?? '') ?>" placeholder="123456789:ABCdefGhIjkLmNoPqRsTuVwXyZ">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Admin Chat ID / Channel ID</label>
                            <input type="text" name="telegram_chat_id" class="form-control font-monospace" value="<?= e($settings['telegram_chat_id'] ?? '') ?>" placeholder="-100123456789 yoki 123456789">
                        </div>
                        <div class="col-md-6">
                            <div class="form-check mt-3">
                                <input class="form-check-input" type="checkbox" name="telegram_notifications_enabled" value="1" id="tgEnable" <?= (($settings['telegram_notifications_enabled'] ?? '0') === '1') ? 'checked' : '' ?>>
                                <label class="form-check-label small fw-semibold" for="tgEnable">Telegram bildirishnomalarni yoqish</label>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Director Speech Tab -->
                <div class="tab-pane fade" id="tab-homepage">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Direktor F.I.Sh</label>
                            <input type="text" name="director_name" class="form-control" value="<?= e($settings['director_name'] ?? 'Qodirov Azizbek Karimovich') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Direktor unvoni / lavozimi</label>
                            <input type="text" name="director_title" class="form-control" value="<?= e($settings['director_title'] ?? 'Kollej Direktori, PhD') ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-semibold">Direktor murojaati matni (O'zbekcha)</label>
                            <textarea name="director_quote_uz" class="form-control" rows="3"><?= e($settings['director_quote_uz'] ?? '') ?></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-semibold">Direktor murojaati matni (Ruscha)</label>
                            <textarea name="director_quote_ru" class="form-control" rows="3"><?= e($settings['director_quote_ru'] ?? '') ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- SEO Tab -->
                <div class="tab-pane fade" id="tab-seo">
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label small fw-semibold">Asosiy Meta Sarlavha (Default Title)</label>
                            <input type="text" name="meta_title_default" class="form-control" value="<?= e($settings['meta_title_default'] ?? '') ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-semibold">Meta Tavsif (Meta Description)</label>
                            <textarea name="meta_desc_default" class="form-control" rows="3"><?= e($settings['meta_desc_default'] ?? '') ?></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-semibold">Kalit so'zlar (Keywords)</label>
                            <input type="text" name="meta_keywords_default" class="form-control" value="<?= e($settings['meta_keywords_default'] ?? '') ?>">
                        </div>
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center">
                <button type="button" class="btn btn-outline-info rounded-pill px-3" onclick="document.getElementById('test-tg-form').submit();">
                    <i class="bi bi-telegram me-1"></i> Telegram xabarini sinab ko'rish
                </button>
                <button type="submit" class="btn btn-primary rounded-pill px-4 fw-bold">
                    <i class="bi bi-check2-circle me-1"></i> Barcha sozlamalarni saqlash
                </button>
            </div>
        </form>

        <form id="test-tg-form" action="<?= url('/admin/settings/test-telegram') ?>" method="POST" class="d-none">
            <?= csrf_field() ?>
        </form>
    </div>
</div>

