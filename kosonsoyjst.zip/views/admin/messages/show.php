<div class="row g-4">
    <!-- Message Details & Official Replies -->
    <div class="col-lg-8">
        <div class="admin-card mb-4">
            <div class="admin-card-header">
                <h5 class="admin-card-title">Murojaat Tafsilotlari: <code><?= e($message['tracking_code']) ?></code></h5>
                <a href="<?= url('/admin/messages') ?>" class="btn btn-sm btn-outline-secondary rounded-pill">
                    <i class="bi bi-arrow-left me-1"></i> Ro'yxatga qaytish
                </a>
            </div>
            <div class="admin-card-body">
                <div class="row g-3 mb-4 small text-secondary">
                    <div class="col-md-6">
                        <strong>F.I.Sh:</strong> <span class="text-dark fw-bold"><?= e($message['full_name']) ?></span>
                    </div>
                    <div class="col-md-6">
                        <strong>Telefon:</strong> <a href="tel:<?= e($message['phone']) ?>"><?= e($message['phone']) ?></a>
                    </div>
                    <div class="col-md-6">
                        <strong>Email:</strong> <?= e($message['email'] ?: 'Mavjud emas') ?>
                    </div>
                    <div class="col-md-6">
                        <strong>Manzil:</strong> <?= e($message['address'] ?: 'Ko\'rsatilmagan') ?>
                    </div>
                    <div class="col-md-6">
                        <strong>Turi:</strong> <span class="badge bg-light text-dark border text-uppercase"><?= e($message['inquiry_type']) ?></span>
                    </div>
                    <div class="col-md-6">
                        <strong>Yuborilgan vaqt:</strong> <?= format_date($message['created_at'], 'd.m.Y H:i') ?>
                    </div>
                </div>

                <div class="p-3 bg-light rounded-3 mb-4">
                    <strong class="d-block mb-1 text-dark small">Mavzu: <?= e($message['subject']) ?></strong>
                    <p class="mb-0 text-secondary"><?= nl2br(e($message['message'])) ?></p>
                </div>

                <?php if (!empty($message['attachment_file'])): ?>
                    <div class="mb-4">
                        <a href="<?= asset($message['attachment_file']) ?>" target="_blank" class="btn btn-outline-primary btn-sm rounded-pill">
                            <i class="bi bi-paperclip me-1"></i> Biriktirilgan faylni yuklab olish
                        </a>
                    </div>
                <?php endif; ?>

                <!-- Replies History -->
                <div class="mt-4 pt-4 border-top">
                    <h5 class="fw-bold mb-3 fs-6"><i class="bi bi-chat-left-text text-success me-2"></i> Yuborilgan rasmiy javoblar</h5>
                    <?php if (!empty($message['replies'])): ?>
                        <div class="d-flex flex-column gap-3 mb-4">
                            <?php foreach ($message['replies'] as $rep): ?>
                                <div class="p-3 rounded-3 bg-light border-start border-4 border-success">
                                    <div class="d-flex justify-content-between small text-muted mb-2">
                                        <strong><?= e($rep['replied_by_name'] ?? 'Mutasaddi') ?></strong>
                                        <span><?= format_date($rep['created_at'], 'd.m.Y H:i') ?></span>
                                    </div>
                                    <p class="mb-1 text-secondary"><?= nl2br(e($rep['reply_text'])) ?></p>
                                    <?php if (!empty($rep['reply_file'])): ?>
                                        <a href="<?= asset($rep['reply_file']) ?>" target="_blank" class="badge bg-success text-decoration-none mt-2">
                                            <i class="bi bi-file-earmark me-1"></i> Ilova qilingan fayl
                                        </a>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-secondary py-2 small mb-4">Hali rasmiy javob yuborilmagan.</div>
                    <?php endif; ?>
                </div>

                <!-- Reply Form -->
                <div class="mt-4 pt-4 border-top">
                    <h5 class="fw-bold mb-3 fs-6"><i class="bi bi-reply-fill text-primary me-2"></i> Yangi rasmiy javob yo'llash</h5>
                    <form action="<?= url('/admin/messages/reply/' . $message['id']) ?>" method="POST" enctype="multipart/form-data">
                        <?= csrf_field() ?>

                        <div class="mb-3">
                            <label class="form-label small fw-semibold">Javob matni *</label>
                            <textarea name="reply_text" class="form-control" rows="4" required placeholder="Fuqaroga rasmiy javob xati mazmunini kiriting..."></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-semibold">Rasmiy javob fayli (PDF, DOCX - Ixtiyoriy)</label>
                            <input type="file" name="reply_file" class="form-control" accept=".pdf,.doc,.docx">
                        </div>

                        <button type="submit" class="btn btn-success rounded-3">
                            <i class="bi bi-send-check me-1"></i> Javobni saqlash va yuborish
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Status Change -->
    <div class="col-lg-4">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title"><i class="bi bi-sliders text-primary me-2"></i> Murojaat Statusi</h5>
            </div>
            <div class="admin-card-body">
                <form action="<?= url('/admin/messages/status/' . $message['id']) ?>" method="POST">
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Holati</label>
                        <select name="status" class="form-select">
                            <option value="NEW" <?= $message['status'] === 'NEW' ? 'selected' : '' ?>>Yangi (Ko'rilmagan)</option>
                            <option value="IN_PROGRESS" <?= $message['status'] === 'IN_PROGRESS' ? 'selected' : '' ?>>Ko'rib chiqilmoqda</option>
                            <option value="ANSWERED" <?= $message['status'] === 'ANSWERED' ? 'selected' : '' ?>>Javob berilgan</option>
                            <option value="CLOSED" <?= $message['status'] === 'CLOSED' ? 'selected' : '' ?>>Yopilgan (Ijrosi yakunlangan)</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 rounded-3">
                        <i class="bi bi-check2 me-1"></i> Statusni yangilash
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

