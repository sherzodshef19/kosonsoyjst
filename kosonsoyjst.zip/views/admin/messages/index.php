<div class="admin-card">
    <div class="admin-card-header flex-wrap gap-3">
        <div>
            <h5 class="admin-card-title mb-1">Virtual Qabulxona Murojaatlari</h5>
            <div class="text-muted small">Fuqarolar va o'quvchilardan onlayn kelib tushgan murojaatlar</div>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= url('/admin/messages/export') ?>" class="btn btn-outline-success btn-sm rounded-pill px-3">
                <i class="bi bi-file-earmark-excel me-1"></i> Excelga yuklab olish (CSV)
            </a>
        </div>
    </div>

    <!-- Filters -->
    <div class="p-3 bg-light border-bottom">
        <form action="<?= url('/admin/messages') ?>" method="GET" class="row g-2 align-items-center">
            <div class="col-md-4">
                <input type="text" name="q" class="form-control form-control-sm" placeholder="Kod, F.I.Sh yoki mavzu bo'yicha..." value="<?= e($search ?? '') ?>">
            </div>
            <div class="col-md-3">
                <select name="status" class="form-select form-select-sm">
                    <option value="">Barcha holatlar</option>
                    <option value="NEW" <?= ($currentStatus === 'NEW') ? 'selected' : '' ?>>Yangi (Ko'rilmagan)</option>
                    <option value="IN_PROGRESS" <?= ($currentStatus === 'IN_PROGRESS') ? 'selected' : '' ?>>Ko'rib chiqilmoqda</option>
                    <option value="ANSWERED" <?= ($currentStatus === 'ANSWERED') ? 'selected' : '' ?>>Javob berilgan</option>
                    <option value="CLOSED" <?= ($currentStatus === 'CLOSED') ? 'selected' : '' ?>>Yopilgan</option>
                </select>
            </div>
            <div class="col-md-3">
                <select name="type" class="form-select form-select-sm">
                    <option value="">Barcha turlar</option>
                    <option value="murojaat" <?= ($currentType === 'murojaat') ? 'selected' : '' ?>>Murojaat / Savol</option>
                    <option value="ariza" <?= ($currentType === 'ariza') ? 'selected' : '' ?>>Ariza</option>
                    <option value="taklif" <?= ($currentType === 'taklif') ? 'selected' : '' ?>>Taklif</option>
                    <option value="shikoyat" <?= ($currentType === 'shikoyat') ? 'selected' : '' ?>>Shikoyat</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-sm btn-secondary w-100">
                    <i class="bi bi-filter me-1"></i> Filtrlash
                </button>
            </div>
        </form>
    </div>

    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-custom table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Kod</th>
                        <th>Murojaatchi</th>
                        <th>Turi</th>
                        <th>Mavzu</th>
                        <th>Holati</th>
                        <th>Sana</th>
                        <th style="width: 100px;" class="text-end">Amal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($messages)): ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted">Hech qanday murojaat topilmadi</td></tr>
                    <?php else: ?>
                        <?php foreach ($messages as $msg): ?>
                            <tr>
                                <td class="font-monospace small fw-bold text-primary"><?= e($msg['tracking_code']) ?></td>
                                <td>
                                    <div class="fw-bold text-dark small"><?= e($msg['full_name']) ?></div>
                                    <div class="text-muted" style="font-size:0.75rem;"><i class="bi bi-telephone me-1"></i> <?= e($msg['phone']) ?></div>
                                </td>
                                <td><span class="badge bg-light text-secondary border text-uppercase"><?= e($msg['inquiry_type']) ?></span></td>
                                <td class="small text-truncate" style="max-width: 220px;"><?= e($msg['subject']) ?></td>
                                <td>
                                    <?php 
                                    $stCls = 'bg-primary';
                                    if ($msg['status'] === 'IN_PROGRESS') $stCls = 'bg-warning text-dark';
                                    if ($msg['status'] === 'ANSWERED') $stCls = 'bg-success';
                                    if ($msg['status'] === 'CLOSED') $stCls = 'bg-secondary';
                                    ?>
                                    <span class="badge <?= $stCls ?> badge-status"><?= e($msg['status']) ?></span>
                                </td>
                                <td class="text-muted small"><?= format_date($msg['created_at']) ?></td>
                                <td class="text-end">
                                    <a href="<?= url('/admin/messages/show/' . $msg['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 me-1" title="Ko'rish va javob berish">
                                        <i class="bi bi-eye-fill text-primary"></i>
                                    </a>
                                    <a href="<?= url('/admin/messages/delete/' . $msg['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 btn-delete-confirm" title="O'chirish">
                                        <i class="bi bi-trash-fill text-danger"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

