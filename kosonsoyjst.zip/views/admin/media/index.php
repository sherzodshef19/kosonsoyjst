<div class="admin-card">
    <div class="admin-card-header flex-wrap gap-3">
        <div>
            <h5 class="admin-card-title mb-1">Fayllar Kutubxonasi (Media Manager)</h5>
            <div class="text-muted small">Serverga yuklangan barcha rasmlar, hujjatlar va media fayllar</div>
        </div>
        <form action="<?= url('/admin/media/upload') ?>" method="POST" enctype="multipart/form-data" class="d-flex gap-2">
            <?= csrf_field() ?>
            <input type="file" name="file" class="form-control form-control-sm" required>
            <button type="submit" class="btn btn-primary btn-sm rounded-pill px-3 flex-shrink-0">
                <i class="bi bi-cloud-arrow-up-fill me-1"></i> Yuklash
            </button>
        </form>
    </div>

    <div class="admin-card-body">
        <?php if (empty($media)): ?>
            <div class="text-center py-5 text-muted">
                <i class="bi bi-folder2-open fs-1 d-block mb-3"></i>
                Kutubxonada fayllar mavjud emas.
            </div>
        <?php else: ?>
            <div class="row g-3">
                <?php foreach ($media as $item): ?>
                    <div class="col-6 col-md-3 col-lg-2">
                        <div class="border rounded-3 p-2 bg-light text-center position-relative h-100 d-flex flex-column justify-content-between">
                            <div class="mb-2">
                                <?php if (in_array(strtolower($item['file_type']), ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'])): ?>
                                    <img src="<?= asset($item['file_path']) ?>" class="rounded-2 w-100" style="height: 100px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="d-flex align-items-center justify-content-center bg-white rounded-2" style="height: 100px;">
                                        <i class="bi bi-file-earmark-text fs-1 text-primary"></i>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="text-truncate small fw-semibold text-dark mb-1" title="<?= e($item['original_name']) ?>">
                                <?= e($item['original_name']) ?>
                            </div>

                            <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                <button class="btn btn-sm btn-light border py-0 px-2 small" onclick="navigator.clipboard.writeText('<?= asset($item['file_path']) ?>'); alert('Fayl havolasi nusxalandi!');" title="Havolani nusxalash">
                                    <i class="bi bi-clipboard"></i>
                                </button>
                                <a href="<?= asset($item['file_path']) ?>" target="_blank" class="btn btn-sm btn-light border py-0 px-2 small" title="Ochish">
                                    <i class="bi bi-box-arrow-up-right"></i>
                                </a>
                                <a href="<?= url('/admin/media/delete/' . $item['id']) ?>" class="btn btn-sm btn-light border py-0 px-2 small text-danger btn-delete-confirm" title="O'chirish">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

