<div class="row g-4">
    <!-- List -->
    <div class="col-lg-8">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title">Hamkor Tashkilotlar</h5>
            </div>
            <div class="admin-card-body p-0">
                <div class="table-responsive">
                    <table class="table table-custom table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th style="width: 70px;">Logo</th>
                                <th>Tashkilot nomi</th>
                                <th>Veb-sayt</th>
                                <th>Tartib</th>
                                <th>Holat</th>
                                <th style="width: 100px;" class="text-end">Amal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($partners as $p): ?>
                                <tr>
                                    <td>
                                        <img src="<?= asset($p['logo']) ?>" alt="<?= e($p['name']) ?>" class="rounded-2 border p-1 bg-white shadow-sm" style="width: 65px; height: 38px; object-fit: contain;" onerror="this.onerror=null;this.src='<?= asset('/assets/images/partner-default.svg') ?>';">
                                    </td>
                                    <td class="fw-bold text-dark"><?= e($p['name']) ?></td>
                                    <td>
                                        <?php if (!empty($p['website_url'])): ?>
                                            <a href="<?= e($p['website_url']) ?>" target="_blank" class="small text-decoration-none">
                                                <i class="bi bi-link-45deg"></i> <?= e($p['website_url']) ?>
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted small">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= (int)$p['sort_order'] ?></td>
                                    <td>
                                        <span class="badge bg-<?= $p['is_active'] ? 'success' : 'secondary' ?> badge-status">
                                            <?= $p['is_active'] ? 'Faol' : 'Nofaol' ?>
                                        </span>
                                    </td>
                                    <td class="text-end">
                                        <button class="btn btn-sm btn-light border py-1 px-2 me-1" data-bs-toggle="modal" data-bs-target="#editPartner<?= $p['id'] ?>">
                                            <i class="bi bi-pencil-fill text-primary"></i>
                                        </button>
                                        <a href="<?= url('/admin/partners/delete/' . $p['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 btn-delete-confirm">
                                            <i class="bi bi-trash-fill text-danger"></i>
                                        </a>
                                    </td>
                                </tr>

                                <!-- Edit Partner Modal -->
                                <div class="modal fade" id="editPartner<?= $p['id'] ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="<?= url('/admin/partners/update/' . $p['id']) ?>" method="POST" enctype="multipart/form-data">
                                                <?= csrf_field() ?>
                                                <div class="modal-header">
                                                    <h5 class="modal-title fs-6 fw-bold">Hamkorni tahrirlash</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Tashkilot nomi *</label>
                                                        <input type="text" name="name" class="form-control" value="<?= e($p['name']) ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Veb-sayt havolasi</label>
                                                        <input type="url" name="website_url" class="form-control" value="<?= e($p['website_url'] ?? '') ?>">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Logotip (O'zgartirish uchun)</label>
                                                        <input type="file" name="logo" class="form-control" accept="image/*">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Tartib raqami</label>
                                                        <input type="number" name="sort_order" class="form-control" value="<?= (int)$p['sort_order'] ?>">
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="actP<?= $p['id'] ?>" <?= $p['is_active'] ? 'checked' : '' ?>>
                                                        <label class="form-check-label small fw-semibold" for="actP<?= $p['id'] ?>">Faol ko'rsatish</label>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Yopish</button>
                                                    <button type="submit" class="btn btn-primary btn-sm px-3">Saqlash</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Add Form -->
    <div class="col-lg-4">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title"><i class="bi bi-building-add text-primary me-2"></i> Yangi Hamkor</h5>
            </div>
            <div class="admin-card-body">
                <form action="<?= url('/admin/partners/store') ?>" method="POST" enctype="multipart/form-data">
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Tashkilot / Korxona nomi *</label>
                        <input type="text" name="name" class="form-control" required placeholder="Masalan: Artel Electronics">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Veb-sayt havolasi</label>
                        <input type="url" name="website_url" class="form-control" placeholder="https://...">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Logotip rasmi (PNG, SVG, WebP)</label>
                        <input type="file" name="logo" class="form-control" accept="image/*">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Tartib raqami</label>
                        <input type="number" name="sort_order" class="form-control" value="0">
                    </div>

                    <div class="form-check mb-4">
                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="partnerAct" checked>
                        <label class="form-check-label small fw-semibold" for="partnerAct">Faol</label>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 rounded-3">
                        <i class="bi bi-plus-lg me-1"></i> Qo'shish
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

