<?php
$isEdit = !empty($employee);
$action = $isEdit ? url('/admin/employees/update/' . $employee['id']) : url('/admin/employees/store');
?>

<div class="admin-card">
    <div class="admin-card-header">
        <h5 class="admin-card-title"><?= $isEdit ? "Xodim ma'lumotlarini tahrirlash" : "Yangi xodim qo'shish" ?></h5>
        <a href="<?= url('/admin/employees') ?>" class="btn btn-sm btn-outline-secondary rounded-pill">
            <i class="bi bi-arrow-left me-1"></i> Ro'yxatga qaytish
        </a>
    </div>

    <div class="admin-card-body">
        <form action="<?= $action ?>" method="POST" enctype="multipart/form-data">
            <?= csrf_field() ?>

            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">F.I.Sh (O'zbekcha) *</label>
                    <input type="text" name="full_name_uz" class="form-control" required value="<?= e($employee['full_name_uz'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">F.I.Sh (Ruscha)</label>
                    <input type="text" name="full_name_ru" class="form-control" value="<?= e($employee['full_name_ru'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">F.I.Sh (Inglizcha)</label>
                    <input type="text" name="full_name_en" class="form-control" value="<?= e($employee['full_name_en'] ?? '') ?>">
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Kafedra / Bo'lim (O'zbekcha) *</label>
                    <input type="text" name="department_uz" class="form-control" required value="<?= e($employee['department_uz'] ?? '') ?>" placeholder="Axborot texnologiyalari kafedrasi">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Mutaxassislik (O'zbekcha) *</label>
                    <input type="text" name="specialty_uz" class="form-control" required value="<?= e($employee['specialty_uz'] ?? '') ?>" placeholder="Dasturlash va kompyuter grafikasi">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Ilmiy unvon / Toifasi</label>
                    <input type="text" name="degree_uz" class="form-control" value="<?= e($employee['degree_uz'] ?? '') ?>" placeholder="Oliy toifali o'qituvchi">
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Telefon</label>
                    <input type="tel" name="phone" class="form-control" value="<?= e($employee['phone'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Elektron pochta</label>
                    <input type="email" name="email" class="form-control" value="<?= e($employee['email'] ?? '') ?>">
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Fotosurat</label>
                    <input type="file" name="image" class="form-control" accept="image/*" data-preview="emp-preview">
                    <?php if (!empty($employee['image'])): ?>
                        <div class="mt-2">
                            <img src="<?= asset($employee['image']) ?>" id="emp-preview" class="rounded-3 border" style="width: 80px; height: 80px; object-fit: cover;">
                        </div>
                    <?php else: ?>
                        <div class="mt-2">
                            <img src="" id="emp-preview" class="rounded-3 border d-none" style="width: 80px; height: 80px; object-fit: cover;">
                        </div>
                    <?php endif; ?>
                </div>

                <div class="col-md-3">
                    <label class="form-label small fw-semibold">Tartib raqami</label>
                    <input type="number" name="sort_order" class="form-control" value="<?= (int)($employee['sort_order'] ?? 0) ?>">
                </div>

                <div class="col-md-3 d-flex align-items-center">
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="actE" <?= !empty($employee['is_active']) ? 'checked' : ($isEdit ? '' : 'checked') ?>>
                        <label class="form-check-label small fw-semibold" for="actE">Faol ko'rsatish</label>
                    </div>
                </div>
            </div>

            <div class="border-top pt-3 d-flex justify-content-end gap-2">
                <a href="<?= url('/admin/employees') ?>" class="btn btn-light border px-4">Bekor qilish</a>
                <button type="submit" class="btn btn-primary px-4 fw-bold">Saqlash</button>
            </div>
        </form>
    </div>
</div>

