<div class="admin-card">
    <div class="admin-card-header flex-wrap gap-3">
        <div>
            <h5 class="admin-card-title mb-1">Xodimlar va O'qituvchilar</h5>
            <div class="text-muted small">Kollejning barcha kafedra o'qituvchilari va mutaxassislari</div>
        </div>
        <a href="<?= url('/admin/employees/create') ?>" class="btn btn-primary rounded-pill btn-sm px-3">
            <i class="bi bi-person-plus-fill me-1"></i> Yangi o'qituvchi qo'shish
        </a>
    </div>

    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-custom table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width: 50px;">Rasm</th>
                        <th>F.I.Sh</th>
                        <th>Kafedra / Bo'lim</th>
                        <th>Mutaxassislik</th>
                        <th>Toifasi</th>
                        <th>Telefon</th>
                        <th>Holati</th>
                        <th style="width: 100px;" class="text-end">Amal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($employees)): ?>
                        <tr><td colspan="8" class="text-center py-5 text-muted">Xodimlar ro'yxati bo'sh</td></tr>
                    <?php else: ?>
                        <?php foreach ($employees as $emp): ?>
                            <tr>
                                <td>
                                    <img src="<?= asset($emp['image'] ?: '/assets/images/avatar-default.png') ?>" class="rounded-circle" style="width: 40px; height: 40px; object-fit: cover;">
                                </td>
                                <td class="fw-bold text-dark"><?= e($emp['full_name_uz']) ?></td>
                                <td class="small text-muted"><?= e($emp['department_uz']) ?></td>
                                <td class="small"><?= e($emp['specialty_uz']) ?></td>
                                <td><span class="badge bg-light text-primary border"><?= e($emp['degree_uz'] ?? '-') ?></span></td>
                                <td class="small text-muted"><?= e($emp['phone'] ?? '-') ?></td>
                                <td>
                                    <span class="badge bg-<?= $emp['is_active'] ? 'success' : 'secondary' ?> badge-status">
                                        <?= $emp['is_active'] ? 'Faol' : 'Nofaol' ?>
                                    </span>
                                </td>
                                <td class="text-end">
                                    <a href="<?= url('/admin/employees/edit/' . $emp['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 me-1">
                                        <i class="bi bi-pencil-fill text-primary"></i>
                                    </a>
                                    <a href="<?= url('/admin/employees/delete/' . $emp['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 btn-delete-confirm">
                                        <i class="bi bi-trash-fill text-danger"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

