<div class="row g-4">
    <!-- Category List -->
    <div class="col-lg-8">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title">Yangilik Kategoriyalari</h5>
            </div>
            <div class="admin-card-body p-0">
                <div class="table-responsive">
                    <table class="table table-custom table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Nomi (O'zbekcha)</th>
                                <th>Slug</th>
                                <th>Maqolalar soni</th>
                                <th>Tartib</th>
                                <th>Holat</th>
                                <th style="width: 100px;" class="text-end">Amal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($categories as $cat): ?>
                                <tr>
                                    <td class="fw-bold text-dark"><?= e($cat['name_uz']) ?></td>
                                    <td class="text-muted small"><?= e($cat['slug']) ?></td>
                                    <td><span class="badge bg-light text-primary border"><?= (int)$cat['news_count'] ?> ta</span></td>
                                    <td><?= (int)$cat['sort_order'] ?></td>
                                    <td>
                                        <span class="badge bg-<?= $cat['is_active'] ? 'success' : 'secondary' ?> badge-status">
                                            <?= $cat['is_active'] ? 'Faol' : 'Nofaol' ?>
                                        </span>
                                    </td>
                                    <td class="text-end">
                                        <button class="btn btn-sm btn-light border py-1 px-2 me-1" data-bs-toggle="modal" data-bs-target="#editModal<?= $cat['id'] ?>">
                                            <i class="bi bi-pencil-fill text-primary"></i>
                                        </button>
                                        <a href="<?= url('/admin/categories/delete/' . $cat['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 btn-delete-confirm">
                                            <i class="bi bi-trash-fill text-danger"></i>
                                        </a>
                                    </td>
                                </tr>

                                <!-- Edit Modal -->
                                <div class="modal fade" id="editModal<?= $cat['id'] ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="<?= url('/admin/categories/update/' . $cat['id']) ?>" method="POST">
                                                <?= csrf_field() ?>
                                                <div class="modal-header">
                                                    <h5 class="modal-title fs-6 fw-bold">Kategoriyani tahrirlash</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Nomi (O'zbekcha) *</label>
                                                        <input type="text" name="name_uz" class="form-control" value="<?= e($cat['name_uz']) ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Nomi (Ruscha)</label>
                                                        <input type="text" name="name_ru" class="form-control" value="<?= e($cat['name_ru'] ?? '') ?>">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Nomi (Inglizcha)</label>
                                                        <input type="text" name="name_en" class="form-control" value="<?= e($cat['name_en'] ?? '') ?>">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-semibold">Tartib raqami</label>
                                                        <input type="number" name="sort_order" class="form-control" value="<?= (int)$cat['sort_order'] ?>">
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="act<?= $cat['id'] ?>" <?= $cat['is_active'] ? 'checked' : '' ?>>
                                                        <label class="form-check-label small fw-semibold" for="act<?= $cat['id'] ?>">Faol</label>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Yopish</button>
                                                    <button type="submit" class="btn btn-primary btn-sm px-3">Saqlash</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Add Form -->
    <div class="col-lg-4">
        <div class="admin-card">
            <div class="admin-card-header">
                <h5 class="admin-card-title"><i class="bi bi-plus-circle text-primary me-2"></i> Yangi Kategoriya</h5>
            </div>
            <div class="admin-card-body">
                <form action="<?= url('/admin/categories/store') ?>" method="POST">
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Kategoriya nomi (O'zbekcha) *</label>
                        <input type="text" name="name_uz" class="form-control" required placeholder="Masalan: E'lonlar">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Nomi (Ruscha)</label>
                        <input type="text" name="name_ru" class="form-control" placeholder="Объявления">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Nomi (Inglizcha)</label>
                        <input type="text" name="name_en" class="form-control" placeholder="Announcements">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Tartib raqami</label>
                        <input type="number" name="sort_order" class="form-control" value="0">
                    </div>

                    <div class="form-check mb-4">
                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="catActive" checked>
                        <label class="form-check-label small fw-semibold" for="catActive">Faol</label>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 rounded-3">
                        <i class="bi bi-plus-lg me-1"></i> Qo'shish
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

