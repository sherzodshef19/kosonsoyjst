<div class="admin-card">
    <div class="admin-card-header flex-wrap gap-3">
        <div>
            <h5 class="admin-card-title mb-1">Bosh Sahifa Slayderi (Bannerlar)</h5>
            <div class="text-muted small">Bosh sahifa yuqori qismidagi katta slaydlar</div>
        </div>
        <a href="<?= url('/admin/banners/create') ?>" class="btn btn-primary rounded-pill btn-sm px-3">
            <i class="bi bi-plus-lg me-1"></i> Yangi banner qo'shish
        </a>
    </div>

    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-custom table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width: 100px;">Rasm</th>
                        <th>Sarlavha</th>
                        <th>Quyi sarlavha</th>
                        <th>Tugma havolasi</th>
                        <th>Tartib</th>
                        <th>Holati</th>
                        <th style="width: 100px;" class="text-end">Amal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($banners)): ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted">Bannerlar mavjud emas</td></tr>
                    <?php else: ?>
                        <?php foreach ($banners as $b): ?>
                            <tr>
                                <td>
                                    <img src="<?= asset($b['image']) ?>" alt="<?= e($b['title_uz']) ?>" class="rounded-2 border shadow-sm" style="width: 90px; height: 50px; object-fit: cover;" onerror="this.onerror=null;this.src='<?= asset('/assets/images/banner-default.jpg') ?>';">
                                </td>
                                <td class="fw-bold text-dark text-truncate" style="max-width: 250px;"><?= e($b['title_uz']) ?></td>
                                <td class="small text-muted text-truncate" style="max-width: 220px;"><?= e($b['subtitle_uz']) ?></td>
                                <td class="small"><code><?= e($b['button_url'] ?? '-') ?></code></td>
                                <td><?= (int)$b['sort_order'] ?></td>
                                <td>
                                    <span class="badge bg-<?= $b['is_active'] ? 'success' : 'secondary' ?> badge-status">
                                        <?= $b['is_active'] ? 'Faol' : 'Nofaol' ?>
                                    </span>
                                </td>
                                <td class="text-end">
                                    <a href="<?= url('/admin/banners/edit/' . $b['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 me-1">
                                        <i class="bi bi-pencil-fill text-primary"></i>
                                    </a>
                                    <a href="<?= url('/admin/banners/delete/' . $b['id']) ?>" class="btn btn-sm btn-light border py-1 px-2 btn-delete-confirm">
                                        <i class="bi bi-trash-fill text-danger"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

