<?php
$isEdit = !empty($banner);
$action = $isEdit ? url('/admin/banners/update/' . $banner['id']) : url('/admin/banners/store');
?>

<div class="admin-card">
    <div class="admin-card-header">
        <h5 class="admin-card-title"><?= $isEdit ? "Bannerni tahrirlash" : "Yangi banner qo'shish" ?></h5>
        <a href="<?= url('/admin/banners') ?>" class="btn btn-sm btn-outline-secondary rounded-pill">
            <i class="bi bi-arrow-left me-1"></i> Ro'yxatga qaytish
        </a>
    </div>

    <div class="admin-card-body">
        <form action="<?= $action ?>" method="POST" enctype="multipart/form-data">
            <?= csrf_field() ?>

            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Sarlavha (O'zbekcha) *</label>
                    <input type="text" name="title_uz" class="form-control" required value="<?= e($banner['title_uz'] ?? '') ?>" placeholder="Kosonsoy Kollejiga Xush Kelibsiz!">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Sarlavha (Ruscha)</label>
                    <input type="text" name="title_ru" class="form-control" value="<?= e($banner['title_ru'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Sarlavha (Inglizcha)</label>
                    <input type="text" name="title_en" class="form-control" value="<?= e($banner['title_en'] ?? '') ?>">
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Quyi sarlavha (O'zbekcha)</label>
                    <textarea name="subtitle_uz" class="form-control" rows="2"><?= e($banner['subtitle_uz'] ?? '') ?></textarea>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Quyi sarlavha (Ruscha)</label>
                    <textarea name="subtitle_ru" class="form-control" rows="2"><?= e($banner['subtitle_ru'] ?? '') ?></textarea>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">Quyi sarlavha (Inglizcha)</label>
                    <textarea name="subtitle_en" class="form-control" rows="2"><?= e($banner['subtitle_en'] ?? '') ?></textarea>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Tugma matni (O'zbekcha)</label>
                    <input type="text" name="button_text_uz" class="form-control" value="<?= e($banner['button_text_uz'] ?? 'Batafsil') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Tugma havolasi (URL)</label>
                    <input type="text" name="button_url" class="form-control" value="<?= e($banner['button_url'] ?? '/#directions') ?>">
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Banner rasmi <?= $isEdit ? '' : '*' ?> (1920x800 tavsiya etiladi)</label>
                    <input type="file" name="image" class="form-control" accept="image/*" <?= $isEdit ? '' : 'required' ?> data-preview="banner-preview">
                    <?php if (!empty($banner['image'])): ?>
                        <div class="mt-2">
                            <img src="<?= asset($banner['image']) ?>" id="banner-preview" class="rounded-3 border" style="max-height: 100px;">
                        </div>
                    <?php else: ?>
                        <div class="mt-2">
                            <img src="" id="banner-preview" class="rounded-3 border d-none" style="max-height: 100px;">
                        </div>
                    <?php endif; ?>
                </div>

                <div class="col-md-3">
                    <label class="form-label small fw-semibold">Tartib raqami</label>
                    <input type="number" name="sort_order" class="form-control" value="<?= (int)($banner['sort_order'] ?? 0) ?>">
                </div>

                <div class="col-md-3 d-flex align-items-center">
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="actB" <?= !empty($banner['is_active']) ? 'checked' : ($isEdit ? '' : 'checked') ?>>
                        <label class="form-check-label small fw-semibold" for="actB">Faol slayd</label>
                    </div>
                </div>
            </div>

            <div class="border-top pt-3 d-flex justify-content-end gap-2">
                <a href="<?= url('/admin/banners') ?>" class="btn btn-light border px-4">Bekor qilish</a>
                <button type="submit" class="btn btn-primary px-4 fw-bold">Saqlash</button>
            </div>
        </form>
    </div>
</div>

