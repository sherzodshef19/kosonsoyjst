<div class="py-5 bg-white border-bottom">
    <div class="container text-center">
        <span class="section-tag"><?= trans('management') ?></span>
        <h1 class="fw-bold text-dark"><?= trans('management') ?> va Pedagogik Jamoa</h1>
        <p class="text-muted mx-auto" style="max-width: 650px;">
            Kosonsoy Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumining malakali rahbarlari, shifokor-pedagoglari va yetakchi mutaxassislari
        </p>
    </div>
</div>

<div class="section-padding">
    <div class="container">
        <!-- Director Card -->
        <?php if (!empty($directors)): ?>
            <div class="mb-5">
                <h3 class="fw-bold mb-4 pb-2 border-bottom text-primary">Texnikum Rahbari</h3>
                <div class="row justify-content-center">
                    <?php foreach ($directors as $dir): ?>
                        <div class="col-lg-8">
                            <div class="bg-white p-4 p-md-5 rounded-4 border shadow-sm">
                                <div class="row align-items-center g-4">
                                    <div class="col-md-4 text-center">
                                        <img src="<?= asset($dir['image'] ?: '/assets/images/avatar-default.png') ?>" alt="<?= e(t($dir, 'full_name')) ?>" class="rounded-circle shadow-sm border border-4 border-light mb-3" style="width: 170px; height: 170px; object-fit: cover;">
                                        <h5 class="fw-bold mb-1"><?= e(t($dir, 'full_name')) ?></h5>
                                        <span class="badge bg-warning text-dark px-3 py-1 rounded-pill"><?= e(t($dir, 'position')) ?></span>
                                    </div>
                                    <div class="col-md-8">
                                        <p class="text-secondary mb-4"><?= e(t($dir, 'bio')) ?></p>
                                        <ul class="list-unstyled small mb-0 d-flex flex-column gap-2 text-muted">
                                            <?php if (!empty($dir['phone'])): ?>
                                                <li><i class="bi bi-telephone-fill text-primary me-2"></i> <strong>Telefon:</strong> <?= e($dir['phone']) ?></li>
                                            <?php endif; ?>
                                            <?php if (!empty($dir['email'])): ?>
                                                <li><i class="bi bi-envelope-fill text-primary me-2"></i> <strong>Email:</strong> <?= e($dir['email']) ?></li>
                                            <?php endif; ?>
                                            <?php if (!empty($dir['reception_days_uz'])): ?>
                                                <li><i class="bi bi-clock-fill text-warning me-2"></i> <strong>Qabul vaqti:</strong> <?= e(t($dir, 'reception_days')) ?></li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Deputies -->
        <?php if (!empty($deputies)): ?>
            <div class="mb-5">
                <h3 class="fw-bold mb-4 pb-2 border-bottom text-primary">Direktor O'rinbosarlari</h3>
                <div class="row g-4">
                    <?php foreach ($deputies as $dep): ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="mgmt-card h-100">
                                <img src="<?= asset($dep['image'] ?: '/assets/images/avatar-default.png') ?>" alt="<?= e(t($dep, 'full_name')) ?>" class="mgmt-avatar">
                                <h5 class="fw-bold mb-1"><?= e(t($dep, 'full_name')) ?></h5>
                                <div class="text-primary small fw-semibold mb-3"><?= e(t($dep, 'position')) ?></div>
                                <p class="text-muted small mb-3"><?= e(truncate_words(t($dep, 'bio'), 18)) ?></p>
                                <div class="border-top pt-3 text-start small text-muted">
                                    <?php if (!empty($dep['phone'])): ?>
                                        <div class="mb-1"><i class="bi bi-telephone text-primary me-1"></i> <?= e($dep['phone']) ?></div>
                                    <?php endif; ?>
                                    <?php if (!empty($dep['reception_days_uz'])): ?>
                                        <div><i class="bi bi-clock text-warning me-1"></i> <?= e(t($dep, 'reception_days')) ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Teachers & Staff -->
        <?php if (!empty($employees)): ?>
            <div class="mt-5">
                <h3 class="fw-bold mb-4 pb-2 border-bottom text-primary">O'qituvchilar va Maxsus Fanlar Ustozlari</h3>
                <div class="row g-4">
                    <?php foreach ($employees as $emp): ?>
                        <div class="col-md-6 col-lg-3">
                            <div class="bg-white p-3 rounded-4 border text-center h-100 shadow-sm">
                                <img src="<?= asset($emp['image'] ?: '/assets/images/avatar-default.png') ?>" alt="<?= e(t($emp, 'full_name')) ?>" class="rounded-circle mb-3 border border-3 border-light shadow-sm" style="width: 100px; height: 100px; object-fit: cover;">
                                <h6 class="fw-bold mb-1"><?= e(t($emp, 'full_name')) ?></h6>
                                <div class="badge bg-light text-primary border mb-2"><?= e(t($emp, 'degree')) ?></div>
                                <div class="small text-muted mb-1"><strong>Kafedra:</strong> <?= e(t($emp, 'department')) ?></div>
                                <div class="small text-muted"><strong>Mutaxassislik:</strong> <?= e(t($emp, 'specialty')) ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

