<?php
declare(strict_types=1);

use Core\Env;
use Core\CSRF;
use Core\Session;
use Core\Auth;
use Core\Database;

if (!function_exists('env')) {
    function env(string $key, $default = null)
    {
        return Env::get($key, $default);
    }
}

if (!function_exists('config')) {
    function config(string $key, $default = null)
    {
        static $configs = [];
        $parts = explode('.', $key);
        $file = $parts[0] ?? '';

        if (!isset($configs[$file])) {
            $path = (defined('ROOT_DIR') ? ROOT_DIR : dirname(__DIR__)) . '/config/' . $file . '.php';
            if (file_exists($path)) {
                $configs[$file] = require $path;
            } else {
                $configs[$file] = [];
            }
        }

        if (count($parts) === 1) {
            return $configs[$file] ?? $default;
        }

        $current = $configs[$file];
        for ($i = 1; $i < count($parts); $i++) {
            $segment = $parts[$i];
            if (is_array($current) && array_key_exists($segment, $current)) {
                $current = $current[$segment];
            } else {
                return $default;
            }
        }

        return $current;
    }
}

if (!function_exists('url')) {
    function url(string $path = ''): string
    {
        $base = rtrim((string)Env::get('APP_URL', 'http://kosonsoyjst'), '/');
        $path = '/' . ltrim($path, '/');
        return $base . $path;
    }
}

if (!function_exists('asset')) {
    function asset(string $path): string
    {
        $path = '/' . ltrim($path, '/');
        return url($path);
    }
}

if (!function_exists('e')) {
    function e($value): string
    {
        return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('csrf_token')) {
    function csrf_token(): string
    {
        return CSRF::token();
    }
}

if (!function_exists('csrf_field')) {
    function csrf_field(): string
    {
        return CSRF::field();
    }
}

if (!function_exists('old')) {
    function old(string $key, $default = '')
    {
        $old = Session::getFlash('_old_input', []);
        return $old[$key] ?? $default;
    }
}

if (!function_exists('flash')) {
    function flash(string $key, $default = null)
    {
        return Session::flash($key, $default);
    }
}

if (!function_exists('has_flash')) {
    function has_flash(string $key): bool
    {
        return Session::hasFlash($key);
    }
}

if (!function_exists('auth')) {
    function auth(): ?array
    {
        return Auth::user();
    }
}

if (!function_exists('can')) {
    function can(string $permission): bool
    {
        return Auth::can($permission);
    }
}

if (!function_exists('has_role')) {
    function has_role($roles): bool
    {
        return Auth::hasRole($roles);
    }
}

if (!function_exists('current_lang')) {
    function current_lang(): string
    {
        $lang = $_GET['lang'] ?? $_COOKIE['site_lang'] ?? Session::get('locale', 'uz');
        if (!in_array($lang, ['uz', 'ru', 'en'], true)) {
            $lang = 'uz';
        }
        return $lang;
    }
}

/**
 * Returns localized field e.g. title_uz, title_ru, title_en
 */
if (!function_exists('t')) {
    function t(?array $row, string $fieldBase, string $default = ''): string
    {
        if (empty($row)) {
            return $default;
        }

        $lang = current_lang();
        $targetField = "{$fieldBase}_{$lang}";

        if (!empty($row[$targetField])) {
            return (string)$row[$targetField];
        }

        // Fallback to Uzbek
        $uzField = "{$fieldBase}_uz";
        if (!empty($row[$uzField])) {
            return (string)$row[$uzField];
        }

        // Fallback to original base field if exists
        if (!empty($row[$fieldBase])) {
            return (string)$row[$fieldBase];
        }

        return $default;
    }
}

/**
 * Translate static interface labels
 */
if (!function_exists('trans')) {
    function trans(string $key, array $replace = []): string
    {
        static $dictionaries = [];
        $lang = current_lang();

        if (!isset($dictionaries[$lang])) {
            $baseDir = defined('ROOT_DIR') ? ROOT_DIR : dirname(__DIR__);
            $dictFile = $baseDir . "/resources/lang/{$lang}.php";
            if (file_exists($dictFile)) {
                $dictionaries[$lang] = require $dictFile;
            } else {
                $dictionaries[$lang] = [];
            }
        }

        $line = $dictionaries[$lang][$key] ?? $key;
        foreach ($replace as $k => $v) {
            $line = str_replace(':' . $k, (string)$v, $line);
        }
        return $line;
    }
}

if (!function_exists('format_date')) {
    function format_date(?string $datetime, string $format = 'd.m.Y'): string
    {
        if (empty($datetime)) {
            return '';
        }
        $ts = strtotime($datetime);
        return $ts ? date($format, $ts) : '';
    }
}

if (!function_exists('slugify')) {
    function slugify(string $text): string
    {
        // Replace non letter or digits by -
        $text = preg_replace('~[^\pL\d]+~u', '-', $text);
        // Transliterate Cyrillic to Latin if needed
        $cyr = ['а','б','в','г','д','е','ё','ж','з','и','й','к','л','м','н','о','п','р','с','т','у','ф','х','ц','ч','ш','щ','ъ','ы','ь','э','ю','я','ў','қ','ғ','ҳ'];
        $lat = ['a','b','v','g','d','e','yo','zh','z','i','y','k','l','m','n','o','p','r','s','t','u','f','kh','ts','ch','sh','shch','','y','','e','yu','ya','o','q','g','h'];
        $text = str_replace($cyr, $lat, mb_strtolower($text, 'UTF-8'));
        $text = trim($text, '-');
        $text = preg_replace('~-+~', '-', $text);
        $text = strtolower($text);

        return empty($text) ? 'item-' . time() : $text;
    }
}

if (!function_exists('truncate_words')) {
    function truncate_words(string $text, int $limit = 25, string $end = '...'): string
    {
        $clean = strip_tags($text);
        $words = preg_split('/\s+/u', trim($clean));
        if (count($words) <= $limit) {
            return $clean;
        }
        return implode(' ', array_slice($words, 0, $limit)) . $end;
    }
}

if (!function_exists('setting')) {
    function setting(string $key, string $default = ''): string
    {
        static $settings = null;
        if ($settings === null) {
            try {
                $db = Database::getInstance();
                $rows = $db->query("SELECT key_name, key_value FROM site_settings");
                $settings = [];
                foreach ($rows as $r) {
                    $settings[$r['key_name']] = (string)$r['key_value'];
                }
            } catch (\Throwable $e) {
                $settings = [];
            }
        }

        $lang = current_lang();
        if ($lang !== 'uz') {
            $localizedKey = "{$key}_{$lang}";
            if (!empty($settings[$localizedKey])) {
                return (string)$settings[$localizedKey];
            }
        }

        return (string)($settings[$key] ?? $default);
    }
}
