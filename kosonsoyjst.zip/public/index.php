<?php
declare(strict_types=1);

/**
 * KOSONSOY KOLLEJI - Official Web Platform
 * Front Controller & Application Bootstrapper
 */

define('ROOT_DIR', dirname(__DIR__));
define('PUBLIC_DIR', __DIR__);

// Handle PHP CLI built-in web server static files
if (php_sapi_name() === 'cli-server') {
    $urlPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    $file = __DIR__ . $urlPath;
    if ($urlPath !== '/' && file_exists($file) && !is_dir($file)) {
        return false;
    }
}

// 1. PSR-4 Class Autoloader
spl_autoload_register(function (string $class) {
    $prefixes = [
        'Core\\'        => ROOT_DIR . '/core/',
        'Controllers\\' => ROOT_DIR . '/controllers/',
        'Models\\'      => ROOT_DIR . '/models/',
        'Services\\'    => ROOT_DIR . '/services/',
        'Middleware\\'  => ROOT_DIR . '/middleware/',
        'Api\\'         => ROOT_DIR . '/api/'
    ];

    foreach ($prefixes as $prefix => $baseDir) {
        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) !== 0) {
            continue;
        }

        $relativeClass = substr($class, $len);
        $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// 2. Global Helpers
require_once ROOT_DIR . '/helpers/helpers.php';

// 3. Bootstrap Application
$app = Core\App::bootstrap(ROOT_DIR);
$router = $app->getRouter();

// 4. Load Route Definitions
require_once ROOT_DIR . '/routes/web.php';
require_once ROOT_DIR . '/routes/api.php';

// 5. Run Application & Dispatch HTTP Request
$app->run();
