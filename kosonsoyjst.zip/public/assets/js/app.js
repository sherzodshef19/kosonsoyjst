/**
 * Frontend Application Script
 * KOSONSOY KOLLEJI
 * Vue 3 CDN + Vanilla JS Interactions
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. Sticky Navbar Scroll Effect
    const navbar = document.querySelector('.site-navbar');
    const backToTop = document.getElementById('back-to-top');

    window.addEventListener('scroll', function () {
        if (window.scrollY > 40) {
            navbar && navbar.classList.add('scrolled');
        } else {
            navbar && navbar.classList.remove('scrolled');
        }

        if (window.scrollY > 300) {
            backToTop && backToTop.classList.add('show');
        } else {
            backToTop && backToTop.classList.remove('show');
        }
    });

    if (backToTop) {
        backToTop.addEventListener('click', function (e) {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // 2. Animated Counter for Statistics
    const counters = document.querySelectorAll('.counter-val');
    if (counters.length > 0 && 'IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries, obs) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const el = entry.target;
                    const target = parseInt(el.getAttribute('data-target') || el.innerText, 10);
                    const suffix = el.getAttribute('data-suffix') || '';
                    let current = 0;
                    const step = Math.ceil(target / 40);

                    const timer = setInterval(() => {
                        current += step;
                        if (current >= target) {
                            el.innerText = target + suffix;
                            clearInterval(timer);
                        } else {
                            el.innerText = current + suffix;
                        }
                    }, 30);

                    obs.unobserve(el);
                }
            });
        }, { threshold: 0.2 });

        counters.forEach(c => observer.observe(c));
    }

    // 3. Vue 3 Global Application for Virtual Reception Quick Check if mounted
    if (document.getElementById('reception-quick-check-app') && window.Vue) {
        const { createApp, ref } = window.Vue;

        createApp({
            setup() {
                const code = ref('');
                const loading = ref(false);
                const result = ref(null);
                const error = ref('');

                const checkStatus = async () => {
                    if (!code.value.trim()) {
                        error.value = "Murojaat kodini kiriting";
                        return;
                    }

                    loading.value = true;
                    error.value = '';
                    result.value = null;

                    try {
                        const res = await fetch('/api/v1/inquiry/status?code=' + encodeURIComponent(code.value.trim()));
                        const data = await res.json();

                        if (data.success && data.data) {
                            result.value = data.data;
                        } else {
                            error.value = data.error || "Bunday kodli murojaat topilmadi.";
                        }
                    } catch (err) {
                        error.value = "Server bilan bog'lanishda xatolik yuz berdi.";
                    } finally {
                        loading.value = false;
                    }
                };

                return {
                    code,
                    loading,
                    result,
                    error,
                    checkStatus
                };
            }
        }).mount('#reception-quick-check-app');
    }
});

