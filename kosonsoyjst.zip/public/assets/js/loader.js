/**
 * Global Loader & Transition Controller
 * KOSONSOY KOLLEJI
 */

(function () {
    'use strict';

    const Loader = {
        progressBar: null,
        progressTimer: null,
        activeRequests: 0,

        init: function () {
            this.progressBar = document.getElementById('top-progress-bar');

            // Dismiss Initial Page Loader
            window.addEventListener('load', () => {
                this.hidePageLoader();
            });

            // Safety timeout: Never leave user stuck on loader
            setTimeout(() => {
                this.hidePageLoader();
            }, 3000);

            // Setup global fetch listener for progress bar
            this.hookFetch();
            this.hookForms();
        },

        hidePageLoader: function () {
            const pageLoader = document.getElementById('page-loader');
            if (pageLoader && !pageLoader.classList.contains('loaded')) {
                pageLoader.classList.add('loaded');
                setTimeout(() => {
                    if (pageLoader.parentNode) {
                        pageLoader.style.display = 'none';
                    }
                }, 450);
            }
        },

        startProgress: function () {
            if (!this.progressBar) return;
            this.activeRequests++;
            this.progressBar.classList.add('active');
            this.progressBar.style.width = '30%';

            clearInterval(this.progressTimer);
            this.progressTimer = setInterval(() => {
                let current = parseFloat(this.progressBar.style.width) || 30;
                if (current < 85) {
                    this.progressBar.style.width = (current + Math.random() * 10) + '%';
                }
            }, 200);
        },

        finishProgress: function () {
            if (!this.progressBar) return;
            this.activeRequests = Math.max(0, this.activeRequests - 1);

            if (this.activeRequests === 0) {
                clearInterval(this.progressTimer);
                this.progressBar.style.width = '100%';
                setTimeout(() => {
                    this.progressBar.classList.remove('active');
                    this.progressBar.style.width = '0%';
                }, 300);
            }
        },

        setButtonLoading: function (button, isLoading) {
            if (!button) return;
            if (isLoading) {
                button.classList.add('btn-loading');
                button.setAttribute('disabled', 'disabled');
            } else {
                button.classList.remove('btn-loading');
                button.removeAttribute('disabled');
            }
        },

        hookFetch: function () {
            const originalFetch = window.fetch;
            const self = this;

            window.fetch = async function (...args) {
                self.startProgress();
                try {
                    const response = await originalFetch.apply(this, args);
                    self.finishProgress();
                    return response;
                } catch (error) {
                    self.finishProgress();
                    throw error;
                }
            };
        },

        hookForms: function () {
            document.addEventListener('submit', (e) => {
                const form = e.target;
                if (form && !form.hasAttribute('data-no-loader')) {
                    const submitBtn = form.querySelector('button[type="submit"]');
                    if (submitBtn) {
                        this.setButtonLoading(submitBtn, true);
                    }
                    this.startProgress();
                }
            });
        }
    };

    window.GlobalLoader = Loader;
    document.addEventListener('DOMContentLoaded', () => {
        Loader.init();
    });
})();

