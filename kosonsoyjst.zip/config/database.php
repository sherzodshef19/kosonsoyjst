<?php
declare(strict_types=1);

use Core\Env;

return [
    'host' => Env::get('DB_HOST', '127.0.0.1'),
    'port' => (int)Env::get('DB_PORT', 3306),
    'database' => Env::get('DB_NAME', 'kosonsoyjst'),
    'username' => Env::get('DB_USER', 'root'),
    'password' => Env::get('DB_PASS', ''),
    'charset' => Env::get('DB_CHARSET', 'utf8mb4')
];

