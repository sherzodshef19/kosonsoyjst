<?php
declare(strict_types=1);

use Core\Env;

return [
    'bot_token' => Env::get('TELEGRAM_BOT_TOKEN', ''),
    'chat_id' => Env::get('TELEGRAM_CHAT_ID', ''),
    'enabled' => (bool)Env::get('TELEGRAM_NOTIFICATIONS', false)
];

