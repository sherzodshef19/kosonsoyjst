<?php
declare(strict_types=1);

use Core\Env;

return [
    'name' => Env::get('APP_NAME', 'Kosonsoy Kolleji'),
    'env' => Env::get('APP_ENV', 'production'),
    'debug' => (bool)Env::get('APP_DEBUG', true),
    'url' => rtrim(Env::get('APP_URL', 'http://kosonsoyjst'), '/'),
    'timezone' => Env::get('APP_TIMEZONE', 'Asia/Tashkent'),
    'locale' => 'uz',
    'locales' => [
        'uz' => [
            'name' => "O'zbekcha",
            'flag' => '🇺🇿',
            'code' => 'uz'
        ],
        'ru' => [
            'name' => 'Русский',
            'flag' => '🇷🇺',
            'code' => 'ru'
        ],
        'en' => [
            'name' => 'English',
            'flag' => '🇬🇧',
            'code' => 'en'
        ]
    ]
];

