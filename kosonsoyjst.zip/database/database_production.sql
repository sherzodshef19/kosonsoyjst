-- ============================================================
-- Kosonsoy Abu Ali ibn Sino nomidagi JST Rasmiy Veb-Sayti
-- Production Database Dump for cPanel / phpMyAdmin
-- Date: 2026-11-16 20:24:26
-- PHP Version: 8.1.9
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------
-- Table structure for `audit_logs`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `record_id` int(10) unsigned DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_al_user` (`user_id`),
  KEY `idx_al_module` (`module`),
  KEY `idx_al_created` (`created_at`),
  CONSTRAINT `fk_al_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `audit_logs`
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('1', '1', 'LOGIN', 'auth', '1', 'Foydalanuvchi tizimga kirdi', '127.0.0.1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; ru-RU) WindowsPowerShell/5.1.19041.6456', '2026-11-16 19:16:49');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('2', '1', 'LOGIN', 'auth', '1', 'Foydalanuvchi tizimga kirdi', '127.0.0.1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; ru-RU) WindowsPowerShell/5.1.19041.6456', '2026-11-16 19:17:09');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('3', '1', 'LOGIN', 'auth', '1', 'Foydalanuvchi tizimga kirdi', '127.0.0.1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; ru-RU) WindowsPowerShell/5.1.19041.6456', '2026-11-16 19:36:24');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('4', '1', 'LOGIN', 'auth', '1', 'Foydalanuvchi tizimga kirdi', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '2026-11-16 19:39:37');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('5', '1', 'UPDATE', 'news', '4', 'Yangilik yangilandi: DIQQAT: 2026/2027 o\'quv yili uchun Abu Ali ibn Sino texnikumiga qabul boshlandi!', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '2026-11-16 19:40:06');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('6', '1', 'LOGOUT', 'auth', '1', 'Foydalanuvchi tizimdan chiqdi', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '2026-11-16 19:40:12');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('7', '1', 'LOGIN', 'auth', '1', 'Foydalanuvchi tizimga kirdi', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '2026-11-16 19:41:20');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('8', '1', 'DELETE', 'users', '2', 'Foydalanuvchi o\'chirildi', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '2026-11-16 19:57:41');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('9', '1', 'DELETE', 'users', '3', 'Foydalanuvchi o\'chirildi', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '2026-11-16 19:58:36');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('10', '1', 'LOGOUT', 'auth', '1', 'Foydalanuvchi tizimdan chiqdi', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '2026-11-16 20:17:09');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('11', '1', 'LOGIN', 'auth', '1', 'Foydalanuvchi tizimga kirdi', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '2026-11-16 20:17:49');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('12', '1', 'UPDATE', 'news', '3', 'Yangilik yangilandi: Kosonsoy tuman Tibbiyot birlashmasi bilan klinik amaliyot memorandumi imzolandi', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '2026-11-16 20:18:07');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('13', '1', 'UPDATE_SETTINGS', 'settings', NULL, 'Sayt sozlamalari yangilandi', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '2026-11-16 20:21:17');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('14', '1', 'UPDATE_SETTINGS', 'settings', NULL, 'Sayt sozlamalari yangilandi', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '2026-11-16 20:21:32');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES ('15', '1', 'UPDATE_SETTINGS', 'settings', NULL, 'Sayt sozlamalari yangilandi', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36', '2026-11-16 20:22:29');

-- ------------------------------------------------------------
-- Table structure for `banners`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `banners`;
CREATE TABLE `banners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title_uz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtitle_uz` text COLLATE utf8mb4_unicode_ci,
  `subtitle_ru` text COLLATE utf8mb4_unicode_ci,
  `subtitle_en` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `button_text_uz` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button_text_ru` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button_text_en` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_banner_sort` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `banners`
INSERT INTO `banners` (`id`, `title_uz`, `title_ru`, `title_en`, `subtitle_uz`, `subtitle_ru`, `subtitle_en`, `image`, `button_text_uz`, `button_text_ru`, `button_text_en`, `button_url`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'Abu Ali ibn Sino vorislari – zamonaviy tibbiyot yetakchilari!', 'Наследники Абу Али ибн Сино – лидеры современной медицины!', 'Heirs of Abu Ali ibn Sino – Leaders of Modern Medicine!', 'Namangan viloyati Kosonsoy Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumiga 2026/2027 o\'quv yili uchun qabul jarayonlari boshlandi.', 'Начался прием документов на 2026/2027 учебный год в Косонсайский техникум общественного здоровья имени Абу Али ибн Сино.', 'Admission has started for the 2026/2027 academic year at Kosonsoy Abu Ali ibn Sino Technical School of Public Health.', '/assets/images/banner-1.jpg', 'Ta\'lim yo\'nalishlari', 'Направления обучения', 'Specialties', '/about', '1', '1', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `banners` (`id`, `title_uz`, `title_ru`, `title_en`, `subtitle_uz`, `subtitle_ru`, `subtitle_en`, `image`, `button_text_uz`, `button_text_ru`, `button_text_en`, `button_url`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('2', 'Zamonaviy simulyatsion o\'quv markazi va klinik amaliyot', 'Современный симуляционный учебный центр и клиническая практика', 'Modern Simulation Training Center and Clinical Practice', 'Talabalarimiz tuman va viloyatning yetakchi tibbiyot birlashmalari hamda markaziy shifoxonalarida bevosita amaliy tajriba oshiradilar.', 'Наши студенты проходят клиническую практику в ведущих больницах и медицинских объединениях области.', 'Our students gain hands-on clinical experience in leading regional hospitals and medical centers.', '/assets/images/banner-2.jpg', 'Virtual qabulxona', 'Виртуальная приемная', 'Virtual Reception', '/reception', '2', '1', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `banners` (`id`, `title_uz`, `title_ru`, `title_en`, `subtitle_uz`, `subtitle_ru`, `subtitle_en`, `image`, `button_text_uz`, `button_text_ru`, `button_text_en`, `button_url`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('3', 'Xalqaro standartlar asosida o\'rta bo\'g\'in tibbiyot xodimlari tayyorlash', 'Подготовка среднего медицинского персонала по международным стандартам', 'Training Mid-Level Medical Staff According to International Standards', 'Hamshiralik ishi, davolash ishi, farmatsiya, akusherlik va laboratoriya diagnostikasi yo\'nalishlarida yetuk mutaxassislar tayyorlaymiz.', 'Мы готовим высококвалифицированных специалистов в области сестринского дела, фармации, лечебного дела и лабораторной диагностики.', 'We train competent professionals in nursing, pharmacy, paramedical practice, and medical laboratory diagnostics.', '/assets/images/banner-3.jpg', 'Vakansiyalar', 'Вакансии', 'Vacancies', '/vacancies', '3', '1', '2026-11-16 19:23:25', '2026-11-16 19:23:25');

-- ------------------------------------------------------------
-- Table structure for `documents`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `documents`;
CREATE TABLE `documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title_uz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `doc_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `doc_date` date DEFAULT NULL,
  `category` enum('law','decree','college_charter','license','certificate','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `download_count` int(10) unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_doc_cat` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `documents`
INSERT INTO `documents` (`id`, `title_uz`, `title_ru`, `title_en`, `doc_number`, `doc_date`, `category`, `file_path`, `file_size`, `download_count`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('1', 'Kosonsoy Abu Ali ibn Sino nomidagi JST Ustavi va Litsenziyasi', 'Устав и Лицензия Косонсайского техникума имени Абу Али ибн Сино', 'Charter and License of Kosonsoy Abu Ali ibn Sino Technical School', 'SSV-104-K', '2026-01-10', 'college_charter', '/uploads/documents/sample-nizom.pdf', '2.4 MB', '340', '1', '0', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `documents` (`id`, `title_uz`, `title_ru`, `title_en`, `doc_number`, `doc_date`, `category`, `file_path`, `file_size`, `download_count`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('2', 'O\'rta bo\'g\'in tibbiyot xodimlarini tayyorlash bo\'yicha Davlat Ta\'lim Standartlari (DTS)', 'Государственные образовательные стандарты подготовки среднего медперсонала', 'State Educational Standards for Mid-Level Healthcare Training', 'DTS-2026/04', '2026-02-15', 'decree', '/uploads/documents/sample-nizom.pdf', '3.8 MB', '210', '1', '0', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `documents` (`id`, `title_uz`, `title_ru`, `title_en`, `doc_number`, `doc_date`, `category`, `file_path`, `file_size`, `download_count`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('3', '2026/2027 o\'quv yili uchun qabul parametrlari va imtihon o\'tkazish Nizomi', 'Положение о приеме и вступительных испытаниях на 2026/2027 учебный год', 'Admissions and Examination Regulations for 2026/2027', 'QABUL-2026-1', '2026-05-01', 'law', '/uploads/documents/sample-nizom.pdf', '1.5 MB', '590', '1', '0', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `documents` (`id`, `title_uz`, `title_ru`, `title_en`, `doc_number`, `doc_date`, `category`, `file_path`, `file_size`, `download_count`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('4', 'Klinik amaliyot o\'tash va bioxavfsizlik qoidalari yo\'riqnomasi', 'Инструкция по прохождению клинической практики и биобезопасности', 'Clinical Internship and Biosafety Guidelines', 'KLINIK-19', '2026-03-20', 'other', '/uploads/documents/sample-nizom.pdf', '1.9 MB', '175', '1', '0', '2026-11-16 19:23:25', '2026-11-16 19:23:25');

-- ------------------------------------------------------------
-- Table structure for `employees`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `employees`;
CREATE TABLE `employees` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `full_name_uz` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name_ru` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_name_en` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department_uz` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_ru` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department_en` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specialty_uz` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specialty_ru` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specialty_en` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `degree_uz` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `degree_ru` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `degree_en` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_emp_sort` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `employees`
INSERT INTO `employees` (`id`, `full_name_uz`, `full_name_ru`, `full_name_en`, `department_uz`, `department_ru`, `department_en`, `specialty_uz`, `specialty_ru`, `specialty_en`, `degree_uz`, `degree_ru`, `degree_en`, `phone`, `email`, `image`, `sort_order`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('1', 'Soliyev Akmal Bahodirovich', 'Солиев Акмал Баходирович', 'Soliyev Akmal Bahodirovich', 'Axborot texnologiyalari kafedrasi', 'Кафедра информационных технологий', 'IT Department', 'Web dasturlash va tizim boshqaruvi', 'Веб-программирование и системное администрирование', 'Web Development & System Admin', 'Oliy toifali o\'qituvchi', 'Преподаватель высшей категории', 'Senior Instructor', '+998 (90) 555-11-22', 'soliyev@kosonsoykollej.uz', '/assets/images/teacher-1.jpg', '1', '1', '0', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `employees` (`id`, `full_name_uz`, `full_name_ru`, `full_name_en`, `department_uz`, `department_ru`, `department_en`, `specialty_uz`, `specialty_ru`, `specialty_en`, `degree_uz`, `degree_ru`, `degree_en`, `phone`, `email`, `image`, `sort_order`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('2', 'Karimova Shahnoza Erkinovna', 'Каримова Шахноза Эркиновна', 'Karimova Shahnoza Erkinovna', 'Yengil sanoat va dizayn kafedrasi', 'Кафедра легкой промышленности и дизайна', 'Light Industry & Design Department', 'Tikuvchilik va modellashtirish', 'Швейное производство и моделирование', 'Sewing & Fashion Design', 'Yetakchi o\'qituvchi', 'Ведущий преподаватель', 'Lead Instructor', '+998 (91) 666-22-33', 'karimova@kosonsoykollej.uz', '/assets/images/teacher-2.jpg', '2', '1', '0', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `employees` (`id`, `full_name_uz`, `full_name_ru`, `full_name_en`, `department_uz`, `department_ru`, `department_en`, `specialty_uz`, `specialty_ru`, `specialty_en`, `degree_uz`, `degree_ru`, `degree_en`, `phone`, `email`, `image`, `sort_order`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('3', 'Nematov Otabek Sheraliyevich', 'Нематов Отабек Шералиевич', 'Nematov Otabek Sheraliyevich', 'Muhandislik va mexanika kafedrasi', 'Кафедра инженерии и механики', 'Engineering & Mechanics Department', 'Avtomobillarga texnik xizmat ko\'rsatish', 'Техническое обслуживание автомобилей', 'Automotive Maintenance & Repair', '1-toifali mutaxassis', 'Специалист 1 категории', 'First Category Specialist', '+998 (93) 777-33-44', 'nematov@kosonsoykollej.uz', '/assets/images/teacher-3.jpg', '3', '1', '0', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `employees` (`id`, `full_name_uz`, `full_name_ru`, `full_name_en`, `department_uz`, `department_ru`, `department_en`, `specialty_uz`, `specialty_ru`, `specialty_en`, `degree_uz`, `degree_ru`, `degree_en`, `phone`, `email`, `image`, `sort_order`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('4', 'Toshmatov Furqat Alimovich', 'Тошматов Фуркат Алимович', 'Toshmatov Furqat Alimovich', 'Metallga ishlov berish kafedrasi', 'Кафедра металлообработки', 'Metalworking Department', 'Payvandlash ishlari texnologiyasi', 'Технология сварочного производства', 'Welding Technology', 'Oliy toifali ustoz', 'Преподаватель высшей категории', 'Master Instructor', '+998 (94) 888-44-55', 'toshmatov@kosonsoykollej.uz', '/assets/images/teacher-4.jpg', '4', '1', '0', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `employees` (`id`, `full_name_uz`, `full_name_ru`, `full_name_en`, `department_uz`, `department_ru`, `department_en`, `specialty_uz`, `specialty_ru`, `specialty_en`, `degree_uz`, `degree_ru`, `degree_en`, `phone`, `email`, `image`, `sort_order`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('5', 'Rasulova Nilufar Tohirovna', 'Расулова Нилуфар Тохировна', 'Rasulova Nilufar Tohirovna', 'Xorijiy tillar kafedrasi', 'Кафедра иностранных языков', 'Foreign Languages Department', 'Amaliy ingliz tili va muloqot madaniyati', 'Практический английский язык', 'Practical English & Communication', 'Magistr', 'Магистр', 'Master of Arts', '+998 (97) 999-55-66', 'rasulova@kosonsoykollej.uz', '/assets/images/teacher-5.jpg', '5', '1', '0', '2026-11-16 18:55:25', '2026-11-16 18:55:25');

-- ------------------------------------------------------------
-- Table structure for `gallery`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `gallery`;
CREATE TABLE `gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title_uz` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_ru` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_date` date DEFAULT NULL,
  `cover_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `gallery`
INSERT INTO `gallery` (`id`, `title_uz`, `title_ru`, `title_en`, `event_date`, `cover_image`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('1', 'Zamonaviy ustaxonalar va amaliyot jarayonlari', 'Современные мастерские и учебная практика', 'Modern Workshops & Practical Training', '2026-11-01', '/assets/images/gallery-1.jpg', '1', '0', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `gallery` (`id`, `title_uz`, `title_ru`, `title_en`, `event_date`, `cover_image`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('2', 'O\'quvchilar hayoti va sport tadbirlari', 'Студенческая жизнь и спорт', 'Student Life & Sports Activities', '2026-10-25', '/assets/images/gallery-2.jpg', '1', '0', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `gallery` (`id`, `title_uz`, `title_ru`, `title_en`, `event_date`, `cover_image`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('3', 'IT laboratoriyasi va robototexnika mashg\'ulotlari', 'ИТ-лаборатория и занятия по робототехнике', 'IT Lab & Robotics Classes', '2026-10-15', '/assets/images/gallery-3.jpg', '1', '0', '2026-11-16 18:55:25', '2026-11-16 18:55:25');

-- ------------------------------------------------------------
-- Table structure for `gallery_images`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `gallery_images`;
CREATE TABLE `gallery_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gallery_id` int(10) unsigned NOT NULL,
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `caption` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_gi_gallery` (`gallery_id`),
  CONSTRAINT `fk_gi_gallery` FOREIGN KEY (`gallery_id`) REFERENCES `gallery` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `gallery_images`
INSERT INTO `gallery_images` (`id`, `gallery_id`, `image_path`, `caption`, `sort_order`, `created_at`) VALUES ('1', '1', '/assets/images/gallery-1.jpg', 'Ustaxonada metallga ishlov berish jarayoni', '1', '2026-11-16 18:55:25');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `image_path`, `caption`, `sort_order`, `created_at`) VALUES ('2', '1', '/assets/images/gallery-1-2.jpg', 'Avtomobil dvigatelini diagnostika qilish amaliyoti', '2', '2026-11-16 18:55:25');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `image_path`, `caption`, `sort_order`, `created_at`) VALUES ('3', '2', 'assets/images/gallery-2.jpg', 'Voleybol bo\'yicha kollej kubogi musobaqasi', '1', '2026-11-16 18:55:25');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `image_path`, `caption`, `sort_order`, `created_at`) VALUES ('4', '3', '/assets/images/gallery-3.jpg', 'Dasturlash va 3D modellashtirish darsi', '1', '2026-11-16 18:55:25');

-- ------------------------------------------------------------
-- Table structure for `management`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `management`;
CREATE TABLE `management` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `full_name_uz` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name_ru` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_name_en` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position_uz` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position_ru` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` enum('director','deputy_director','department_head') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'deputy_director',
  `bio_uz` text COLLATE utf8mb4_unicode_ci,
  `bio_ru` text COLLATE utf8mb4_unicode_ci,
  `bio_en` text COLLATE utf8mb4_unicode_ci,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reception_days_uz` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reception_days_ru` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reception_days_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_mgmt_cat` (`category`),
  KEY `idx_mgmt_sort` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `management`
INSERT INTO `management` (`id`, `full_name_uz`, `full_name_ru`, `full_name_en`, `position_uz`, `position_ru`, `position_en`, `category`, `bio_uz`, `bio_ru`, `bio_en`, `phone`, `email`, `reception_days_uz`, `reception_days_ru`, `reception_days_en`, `image`, `sort_order`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('1', 'Zokirov Anvar Rustamovich', 'Закиров Анвар Рустамович', 'Anvar Zokirov', 'Texnikum direktori', 'Директор техникума', 'Director of Technical School', 'director', 'Tibbiyot fanlari nomzodi. Sog\'liqni saqlash sohasida 25 yillik rahbarlik va pedagogik tajribaga ega. Sog\'liqni saqlash a\'lochisi ko\'krak nishoni sohibi.', 'Кандидат медицинских наук. Имеет 25-летний опыт руководящей и педагогической деятельности в сфере здравоохранения.', 'Candidate of Medical Sciences. Over 25 years of leadership and pedagogical experience in healthcare education.', '+998 (69) 652-14-25', 'director@kosonsoyjst.uz', 'Dushanba, Chorshanba: 14:00 - 17:00', 'Понедельник, Среда: 14:00 - 17:00', 'Monday, Wednesday: 14:00 - 17:00', '/assets/images/avatar-1.jpg', '1', '1', '0', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `management` (`id`, `full_name_uz`, `full_name_ru`, `full_name_en`, `position_uz`, `position_ru`, `position_en`, `category`, `bio_uz`, `bio_ru`, `bio_en`, `phone`, `email`, `reception_days_uz`, `reception_days_ru`, `reception_days_en`, `image`, `sort_order`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('2', 'Rahimova Gulnora Olimovna', 'Рахимова Гульнора Олимовна', 'Gulnora Rahimova', 'O\'quv ishlari bo\'yicha direktor o\'rinbosari', 'Заместитель директора по учебной работе', 'Deputy Director for Academic Affairs', 'deputy_director', 'Oliy toifali shifokor-pedagog. 18 yillik ilmiy-pedagogik faoliyat davomida ko\'plab o\'quv-uslubiy qo\'llanmalar va darsliklar muallifi.', 'Врач-педагог высшей категории. Автор многочисленных учебно-методических пособий и программ по сестринскому делу.', 'Senior medical educator. Author of numerous methodological study guides and curricula in nursing education.', '+998 (69) 652-14-26', 'oquv@kosonsoyjst.uz', 'Seshanba, Payshanba: 10:00 - 13:00', 'Вторник, Четверг: 10:00 - 13:00', 'Tuesday, Thursday: 10:00 - 13:00', '/assets/images/avatar-2.jpg', '2', '1', '0', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `management` (`id`, `full_name_uz`, `full_name_ru`, `full_name_en`, `position_uz`, `position_ru`, `position_en`, `category`, `bio_uz`, `bio_ru`, `bio_en`, `phone`, `email`, `reception_days_uz`, `reception_days_ru`, `reception_days_en`, `image`, `sort_order`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('3', 'Mirzayev Farhod Akramovich', 'Мирзаев Фарход Акрамович', 'Farhod Mirzayev', 'Amaliyot va klinik ta\'lim bo\'yicha direktor o\'rinbosari', 'Заместитель директора по клинической практике', 'Deputy Director for Clinical Practice', 'deputy_director', 'Shifoxonalar va tibbiyot birlashmalari bilan uzviy amaliy hamkorlikni tashkil etish, talabalar klinik rotatsiyalarini muvofiqlashtirish bo\'yicha tajribali mutaxassis.', 'Опытный специалист по организации клинической практики студентов в центральных районных больницах и медицинских центрах.', 'Experienced specialist in coordinating student clinical rotations and hospital internships.', '+998 (69) 652-14-27', 'amaliyot@kosonsoyjst.uz', 'Chorshanba, Juma: 14:00 - 17:00', 'Среда, Пятница: 14:00 - 17:00', 'Wednesday, Friday: 14:00 - 17:00', '/assets/images/avatar-3.jpg', '3', '1', '0', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `management` (`id`, `full_name_uz`, `full_name_ru`, `full_name_en`, `position_uz`, `position_ru`, `position_en`, `category`, `bio_uz`, `bio_ru`, `bio_en`, `phone`, `email`, `reception_days_uz`, `reception_days_ru`, `reception_days_en`, `image`, `sort_order`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('4', 'Hoshimova Umida Nodirovna', 'Хошимова Умида Нодировна', 'Umida Hoshimova', 'Yoshlar bilan ishlash va ma\'naviyat bo\'limi boshlig\'i', 'Начальник отдела по работе с молодежью', 'Head of Youth Affairs and Morality Department', 'department_head', 'Talaba-yoshlar ma\'naviyatini yuksaltirish, Ibn Sino vorislari klubi va jamoat salomatligi targ\'ibot loyihalari tashabbuskori.', 'Руководитель молодежного клуба «Наследники Ибн Сино» и инициатор проектов по пропаганде здорового образа жизни.', 'Leader of the Ibn Sino Heirs Youth Club and coordinator of healthy lifestyle community outreach projects.', '+998 (69) 652-14-28', 'yoshlar@kosonsoyjst.uz', 'Har kuni: 09:00 - 16:00', 'Ежедневно: 09:00 - 16:00', 'Daily: 09:00 - 16:00', '/assets/images/avatar-4.jpg', '4', '1', '0', '2026-11-16 19:23:25', '2026-11-16 19:23:25');

-- ------------------------------------------------------------
-- Table structure for `media`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `media`;
CREATE TABLE `media` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_media_user` (`user_id`),
  CONSTRAINT `fk_media_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `media`
INSERT INTO `media` (`id`, `file_name`, `original_name`, `file_path`, `file_type`, `file_size`, `user_id`, `created_at`) VALUES ('1', '20261116_214006_da112d1db9b394bf.jpg', '4. Кот с наушниками.jpg', '/uploads/news/20261116_214006_da112d1db9b394bf.jpg', 'jpg', '581177', '1', '2026-11-16 19:40:06');
INSERT INTO `media` (`id`, `file_name`, `original_name`, `file_path`, `file_type`, `file_size`, `user_id`, `created_at`) VALUES ('2', '20261116_221806_cc393f84413991c7.jpg', '1. Черный кот с рыбкой.jpg', '/uploads/news/20261116_221806_cc393f84413991c7.jpg', 'jpg', '262577', '1', '2026-11-16 20:18:06');

-- ------------------------------------------------------------
-- Table structure for `menus`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `title_uz` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_ru` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_en` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` enum('_self','_blank') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self',
  `location` enum('header','footer','quick_links') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'header',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_menu_parent` (`parent_id`),
  KEY `idx_menu_loc` (`location`,`sort_order`),
  CONSTRAINT `fk_menu_parent` FOREIGN KEY (`parent_id`) REFERENCES `menus` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `menus`
INSERT INTO `menus` (`id`, `parent_id`, `title_uz`, `title_ru`, `title_en`, `url`, `target`, `location`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('1', NULL, 'Bosh sahifa', 'Главная', 'Home', '/', '_self', 'header', '1', '1', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `menus` (`id`, `parent_id`, `title_uz`, `title_ru`, `title_en`, `url`, `target`, `location`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('2', NULL, 'Biz haqimizda', 'О колледже', 'About Us', '/about', '_self', 'header', '2', '1', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `menus` (`id`, `parent_id`, `title_uz`, `title_ru`, `title_en`, `url`, `target`, `location`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('3', NULL, 'Yangiliklar', 'Новости', 'News', '/news', '_self', 'header', '3', '1', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `menus` (`id`, `parent_id`, `title_uz`, `title_ru`, `title_en`, `url`, `target`, `location`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('4', NULL, 'Rahbariyat', 'Руководство', 'Leadership', '/management', '_self', 'header', '4', '1', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `menus` (`id`, `parent_id`, `title_uz`, `title_ru`, `title_en`, `url`, `target`, `location`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('5', NULL, 'Statistika', 'Статистика', 'Statistics', '/statistics', '_self', 'header', '5', '1', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `menus` (`id`, `parent_id`, `title_uz`, `title_ru`, `title_en`, `url`, `target`, `location`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('6', NULL, 'Vakansiyalar', 'Вакансии', 'Vacancies', '/vacancies', '_self', 'header', '6', '1', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `menus` (`id`, `parent_id`, `title_uz`, `title_ru`, `title_en`, `url`, `target`, `location`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('7', NULL, 'Virtual qabulxona', 'Виртуальная приемная', 'Virtual Reception', '/reception', '_self', 'header', '7', '1', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `menus` (`id`, `parent_id`, `title_uz`, `title_ru`, `title_en`, `url`, `target`, `location`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('8', NULL, 'Rasmiy hujjatlar', 'Официальные документы', 'Official Documents', '/documents', '_self', 'header', '8', '1', '2026-11-16 18:55:25', '2026-11-16 18:55:25');

-- ------------------------------------------------------------
-- Table structure for `message_replies`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `message_replies`;
CREATE TABLE `message_replies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_id` int(10) unsigned NOT NULL,
  `replied_by_user_id` int(10) unsigned DEFAULT NULL,
  `reply_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `reply_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_mr_msg` (`message_id`),
  KEY `fk_mr_user` (`replied_by_user_id`),
  CONSTRAINT `fk_mr_msg` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mr_user` FOREIGN KEY (`replied_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `message_replies`
INSERT INTO `message_replies` (`id`, `message_id`, `replied_by_user_id`, `reply_text`, `reply_file`, `created_at`) VALUES ('1', '1', '1', 'Assalomu alaykum, hurmatli Jamshid Farhodovich! Farzandingizni Kosonsoy kollejida ko\'rishdan mamnunmiz. Qabul komissiyasi dushanbadan shanbagacha soat 08:30 dan 17:30 gacha ishlaydi. Talab etiladigan hujjatlar: 1) Tug\'ilganlik haqidagi guvohnoma yoki pasport nusxasi; 2) 9-sinf shahodatnomasi; 3) 086-U tibbiy ma\'lumotnoma; 4) 3x4 o\'lchamdagi 6 dona rasm. Shuningdek, arizani saytimiz orqali onlayn topshirishingiz ham mumkin.', NULL, '2026-11-12 16:30:00');

-- ------------------------------------------------------------
-- Table structure for `messages`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tracking_code` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inquiry_type` enum('murojaat','taklif','shikoyat','ariza') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'murojaat',
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('NEW','IN_PROGRESS','ANSWERED','CLOSED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NEW',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tracking_code` (`tracking_code`),
  KEY `idx_msg_code` (`tracking_code`),
  KEY `idx_msg_status` (`status`,`is_deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `messages`
INSERT INTO `messages` (`id`, `tracking_code`, `full_name`, `phone`, `email`, `address`, `inquiry_type`, `subject`, `message`, `attachment_file`, `status`, `ip_address`, `is_deleted`, `created_at`, `updated_at`) VALUES ('1', 'KK-2026-10492', 'Ergashev Jamshid Farhodovich', '+998 (90) 111-22-33', 'j.ergashev@gmail.com', 'Kosonsoy tumani, Chindovul MFY', 'ariza', 'Kollejga qabul hujjatlari topshirish tartibi to\'g\'risida', 'Assalomu alaykum. Men 9-sinfni tugatgan farzandimni axborot texnologiyalari yo\'nalishiga o\'qishga bermoqchiman. Qabul komissiyasi qaysi sanalarda ishlaydi va qanday hujjatlar talab etiladi?', NULL, 'ANSWERED', '127.0.0.1', '0', '2026-11-12 11:20:00', '2026-11-16 18:55:25');
INSERT INTO `messages` (`id`, `tracking_code`, `full_name`, `phone`, `email`, `address`, `inquiry_type`, `subject`, `message`, `attachment_file`, `status`, `ip_address`, `is_deleted`, `created_at`, `updated_at`) VALUES ('2', 'KK-2026-20831', 'Rahimova Mohira Odilovna', '+998 (93) 222-33-44', 'mohira.r@mail.ru', 'Kosonsoy tumani, Tergachi MFY', 'taklif', 'Tikuvchilik ustaxonasida yangi dizayn to\'garagini ochish taklifi', 'Hurmatli direktor! Kollejdagi tikuvchilik yo\'nalishida an\'anaviy milliy kashtachilik va zamonaviy liboslar dizayni to\'garagini yo\'lga qo\'yish taklifini bildirmoqchiman.', NULL, 'IN_PROGRESS', '127.0.0.1', '0', '2026-11-14 15:45:00', '2026-11-16 18:55:25');
INSERT INTO `messages` (`id`, `tracking_code`, `full_name`, `phone`, `email`, `address`, `inquiry_type`, `subject`, `message`, `attachment_file`, `status`, `ip_address`, `is_deleted`, `created_at`, `updated_at`) VALUES ('3', 'KK-2026-30119', 'Narzullayev Sanjarbek', '+998 (94) 333-44-55', 'sanjar.narz@gmail.com', 'Namangan shahri', 'murojaat', 'Dual ta\'lim amaliyot korxonalari ro\'yxati bo\'yicha', 'Assalomu alaykum. Avtomobillarga texnik xizmat ko\'rsatish yo\'nalishi bo\'yicha qaysi korxonalar bilan shartnomalar tuzilganligini bilmoqchi edim.', NULL, 'NEW', '127.0.0.1', '0', '2026-11-16 10:15:00', '2026-11-16 18:55:25');
INSERT INTO `messages` (`id`, `tracking_code`, `full_name`, `phone`, `email`, `address`, `inquiry_type`, `subject`, `message`, `attachment_file`, `status`, `ip_address`, `is_deleted`, `created_at`, `updated_at`) VALUES ('4', 'KK-2026-16877', 'Botir Ergashev', '+998 90 123 45 67', 'botir@example.com', '', 'taklif', 'IT to\'garaklarini kengaytirish bo\'yicha taklif', 'Assalomu alaykum! Kollejda yangi IT laboratoriyasi tashkil etilgani bilan tabriklayman. Men sun\'iy intellekt va veb dasturlash bo\'yicha qo\'shimcha amaliy to\'garak tashkil qilishni taklif qilmoqchiman.', NULL, 'NEW', '127.0.0.1', '0', '2026-11-16 19:17:39', '2026-11-16 19:17:39');

-- ------------------------------------------------------------
-- Table structure for `news`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `author_id` int(10) unsigned DEFAULT NULL,
  `title_uz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary_uz` text COLLATE utf8mb4_unicode_ci,
  `summary_ru` text COLLATE utf8mb4_unicode_ci,
  `summary_en` text COLLATE utf8mb4_unicode_ci,
  `content_uz` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_ru` longtext COLLATE utf8mb4_unicode_ci,
  `content_en` longtext COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `views_count` int(10) unsigned NOT NULL DEFAULT '0',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `is_announcement` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('published','draft','archived') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `fk_news_cat` (`category_id`),
  KEY `fk_news_author` (`author_id`),
  KEY `idx_news_slug` (`slug`),
  KEY `idx_news_status` (`status`,`is_deleted`),
  KEY `idx_news_published` (`published_at`),
  CONSTRAINT `fk_news_author` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_news_cat` FOREIGN KEY (`category_id`) REFERENCES `news_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `news`
INSERT INTO `news` (`id`, `category_id`, `author_id`, `title_uz`, `title_ru`, `title_en`, `slug`, `summary_uz`, `summary_ru`, `summary_en`, `content_uz`, `content_ru`, `content_en`, `image`, `views_count`, `is_featured`, `is_announcement`, `status`, `meta_title`, `meta_description`, `published_at`, `is_deleted`, `created_at`, `updated_at`) VALUES ('1', '1', '1', 'Kosonsoy Abu Ali ibn Sino nomidagi JSTda zamonaviy tibbiy simulyatsiya markazi ochildi', 'В Косонсайском техникуме имени Абу Али ибн Сино открыт современный медицинский симуляционный центр', 'Modern Medical Simulation Center Opened at Kosonsoy Abu Ali ibn Sino Technical School', 'kosonsoy-abu-ali-ibn-sino-nomidagi-jstda-zamonaviy-tibbiy-simulyatsiya-markazi-ochildi', 'Namangan viloyati Kosonsoy Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumida eng so\'nggi rusumdagi robot-manekenlar va reanimatsiya trenajyorlari bilan jihozlangan simulyatsiya markazi ochildi.', 'В Косонсайском техникуме общественного здоровья имени Абу Али ибн Сино открылся современный симуляционный центр с роботизированными манекенами.', 'A state-of-the-art medical simulation center equipped with high-tech robotic manikins was opened at Kosonsoy Technical School of Public Health.', '<p>Namangan viloyati Kosonsoy tumanida joylashgan Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumida o\'quv jarayonini amaliyot bilan uzviy bog\'lash maqsadida eng zamonaviy Tibbiy Simulyatsiya Markazi tantanali ravishda ochildi.</p><p>Markazda bo\'lajak hamshiralar, feldsherlar va akusherlar shoshilinch tez tibbiy yordam ko\'rsatish, EKG olish, infuzion terapiya, yurak-o\'pka reanimatsiyasi va tug\'ruqqa yordam berish ko\'nikmalarini real vaziyatga yaqinlashtirilgan interaktiv robot-manekenlarda mashq qiladilar.</p><p>Ushbu markaz talabalarning klinik ko\'nikmalarini shifoxonaga bormasdan oldin yuksak darajada o\'zlashtirishlariga xizmat qiladi.</p>', '<p>В Касансайском районе Наманганской области состоялось открытие передового центра медицинской симуляции.</p>', '<p>In Kosonsoy district of Namangan region, an advanced medical simulation center has been officially inaugurated.</p>', '/assets/images/news-1.jpg', '541', '1', '0', 'published', NULL, NULL, '2026-11-16 19:23:25', '0', '2026-11-16 19:23:25', '2026-11-16 19:26:47');
INSERT INTO `news` (`id`, `category_id`, `author_id`, `title_uz`, `title_ru`, `title_en`, `slug`, `summary_uz`, `summary_ru`, `summary_en`, `content_uz`, `content_ru`, `content_en`, `image`, `views_count`, `is_featured`, `is_announcement`, `status`, `meta_title`, `meta_description`, `published_at`, `is_deleted`, `created_at`, `updated_at`) VALUES ('2', '2', '1', 'Abu Ali ibn Sino ilmiy merosiga bag\'ishlangan viloyat ilmiy-amaliy anjumani o\'tkazildi', 'Проведена научно-практическая конференция, посвященная научному наследию Абу Али ибн Сино', 'Scientific and Practical Conference Dedicated to the Heritage of Abu Ali ibn Sino Held', 'abu-ali-ibn-sino-ilmiy-merosiga-bagishlangan-viloyat-ilmiy-amaliy-anjumani-otkazildi', 'Texnikumda buyuk tabib va alloma Abu Ali ibn Sino ilmiy merosi, profilaktik tibbiyot tamoyillari hamda zamonaviy sog\'liqni saqlashga doir ilmiy ma\'ruzalar tinglandi.', 'В техникуме были заслушаны научные доклады о наследии Абу Али ибн Сино и принципах профилактической медицины.', 'Reports on the medical heritage of Abu Ali ibn Sino and principles of public health were presented at the conference.', '<p>Kosonsoy Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumi faollar zalida \'Ibn Sino ta\'limoti va jamoat salomatligining dolzarb vazifalari\' mavzusida ilmiy-amaliy konferensiya bo\'lib o\'tdi.</p><p>Konferensiyada Namangan viloyat Sog\'liqni saqlash boshqarmasi mutasaddilari, tibbiyot oliygohlari professorlari, texnikum pedagoglari va iqtidorli talabalari qatnashdilar. Tadbir doirasida o\'quvchilar allomaning \'Tib qonunlari\' asari bo\'yicha o\'z ilmiy izlanishlarini taqdim etdilar.</p>', '<p>Научная конференция собрала ведущих врачей и педагогов области.</p>', '<p>The conference brought together prominent healthcare professionals and educators of the region.</p>', '/assets/images/news-2.jpg', '380', '1', '0', 'published', NULL, NULL, '2026-11-16 19:23:25', '0', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `news` (`id`, `category_id`, `author_id`, `title_uz`, `title_ru`, `title_en`, `slug`, `summary_uz`, `summary_ru`, `summary_en`, `content_uz`, `content_ru`, `content_en`, `image`, `views_count`, `is_featured`, `is_announcement`, `status`, `meta_title`, `meta_description`, `published_at`, `is_deleted`, `created_at`, `updated_at`) VALUES ('3', '1', '1', 'Kosonsoy tuman Tibbiyot birlashmasi bilan klinik amaliyot memorandumi imzolandi', 'Подписан меморандум о клинической практике с медицинским объединением Касансайского района', 'Clinical Practice Memorandum Signed with Kosonsoy District Medical Association', 'kosonsoy-tuman-tibbiyot-birlashmasi-bilan-klinik-amaliyot-memorandumi-imzolandi', 'Talabalarimiz tuman markaziy shifoxonasi, tug\'ruq majmuasi va tez tibbiy yordam bo\'limlarida doimiy klinik amaliyot o\'tash imkoniyatiga ega bo\'ldilar.', 'Студенты получили возможность проходить регулярную практику в отделениях центральной районной больницы.', 'Students will now undergo systematic clinical internships across departments of the central hospital.', '<p>Texnikum ma\'muriyati hamda Kosonsoy tuman Tibbiyot birlashmasi (TTB) o\'rtasida o\'zaro hamkorlikni yangi bosqichga ko\'taruvchi bosh memorandum imzolandi.</p><p>Ushbu kelishuvga binoan 2- va 3-kurs talabalari o\'qish bilan bir qatorda bevosita tuman shifoxonasining reanimatsiya, jarrohlik, terapiya, bolalar bo\'limi va laboratoriyalarida amaliy navbatchilik qiladilar.</p>', '<p>Новый меморандум открывает широкие возможности практического обучения.</p>', '<p>The new memorandum broadens clinical learning horizons for technical school students.</p>', '/uploads/news/20261116_221806_cc393f84413991c7.jpg', '295', '0', '0', 'published', '', '', '2026-11-16 19:23:00', '0', '2026-11-16 19:23:25', '2026-11-16 20:18:06');
INSERT INTO `news` (`id`, `category_id`, `author_id`, `title_uz`, `title_ru`, `title_en`, `slug`, `summary_uz`, `summary_ru`, `summary_en`, `content_uz`, `content_ru`, `content_en`, `image`, `views_count`, `is_featured`, `is_announcement`, `status`, `meta_title`, `meta_description`, `published_at`, `is_deleted`, `created_at`, `updated_at`) VALUES ('4', '3', '1', 'DIQQAT: 2026/2027 o\'quv yili uchun Abu Ali ibn Sino texnikumiga qabul boshlandi!', 'ВНИМАНИЕ: Начался прием в техникум имени Абу Али ибн Сино на 2026/2027 учебный год!', 'ATTENTION: Admissions Open for 2026/2027 at Abu Ali ibn Sino Technical School!', 'diqqat-2026-2027-oquv-yili-uchun-abu-ali-ibn-sino-texnikumiga-qabul-boshlandi', '9- va 11-sinf bitiruvchilari uchun Hamshiralik ishi, Davolash ishi (feldsherlik), Farmatsiya va Tibbiy profilaktika yo\'nalishlariga hujjatlar qabul qilinmoqda.', 'Прием документов для выпускников 9-х и 11-х классов по направлениям сестринского, лечебного дела и фармации.', 'Accepting applications for 9th and 11th grade graduates in Nursing, Paramedicine, Pharmacy and Public Health.', '<p>Kosonsoy Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumi 2026/2027 o\'quv yili uchun quyidagi yo\'nalishlar bo\'yicha abituriyentlarni qabul qiladi:</p><ul><li>Hamshiralik ishi (kunduzgi va kechki ta\'lim shakllari)</li><li>Davolash ishi (Feldsherlik)</li><li>Farmatsiya (Dorishunoslik)</li><li>Akusherlik ishi</li><li>Tibbiy profilaktika ishi</li><li>Stomatologiya ishi (Tish texnigi)</li></ul><p>Hujjatlar elektron qabul portali hamda texnikum qabul komissiyasi orqali qabul qilinadi.</p>', '<p>Приемная комиссия работает ежедневно с 09:00 до 17:00.</p>', '<p>The admissions office is open Monday to Saturday from 09:00 to 17:00.</p>', '/uploads/news/20261116_214006_da112d1db9b394bf.jpg', '841', '1', '1', 'published', '', '', '2026-11-16 19:23:00', '0', '2026-11-16 19:23:25', '2026-11-16 19:40:22');

-- ------------------------------------------------------------
-- Table structure for `news_categories`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `news_categories`;
CREATE TABLE `news_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_uz` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ru` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_cat_slug` (`slug`),
  KEY `idx_cat_sort` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `news_categories`
INSERT INTO `news_categories` (`id`, `name_uz`, `name_ru`, `name_en`, `slug`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'Kollej yangiliklari', 'Новости колледжа', 'College News', 'kollej-yangiliklari', 'Kollejning ichki hayoti va tadbirlari', '1', '1', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `news_categories` (`id`, `name_uz`, `name_ru`, `name_en`, `slug`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('2', 'E\'lonlar', 'Объявления', 'Announcements', 'elonlar', 'Muhim xabarlar va e\'lonlar', '2', '1', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `news_categories` (`id`, `name_uz`, `name_ru`, `name_en`, `slug`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('3', 'Ta\'lim va innovatsiya', 'Образование и инновации', 'Education & Innovation', 'talim-va-innovatsiya', 'Zamonaviy kasbiy standartlar va amaliyotlar', '3', '1', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `news_categories` (`id`, `name_uz`, `name_ru`, `name_en`, `slug`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('4', 'Ma\'naviyat va sport', 'Духовность и спорт', 'Spirituality & Sport', 'manaviyat-va-sport', 'Sport musobaqalari va ma\'naviy tadbirlar', '4', '1', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `news_categories` (`id`, `name_uz`, `name_ru`, `name_en`, `slug`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('5', 'Xalqaro hamkorlik', 'Международное сотрудничество', 'International Cooperation', 'xalqaro-hamkorlik', 'Chet el ta\'lim muassasalari bilan aloqalar', '5', '1', '2026-11-16 18:55:25', '2026-11-16 18:55:25');

-- ------------------------------------------------------------
-- Table structure for `news_gallery`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `news_gallery`;
CREATE TABLE `news_gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `news_id` int(10) unsigned NOT NULL,
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_ng_news` (`news_id`),
  CONSTRAINT `fk_ng_news` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table structure for `news_tag_relations`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `news_tag_relations`;
CREATE TABLE `news_tag_relations` (
  `news_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`news_id`,`tag_id`),
  KEY `fk_ntr_tag` (`tag_id`),
  CONSTRAINT `fk_ntr_news` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ntr_tag` FOREIGN KEY (`tag_id`) REFERENCES `news_tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `news_tag_relations`
INSERT INTO `news_tag_relations` (`news_id`, `tag_id`) VALUES ('2', '1');
INSERT INTO `news_tag_relations` (`news_id`, `tag_id`) VALUES ('1', '2');
INSERT INTO `news_tag_relations` (`news_id`, `tag_id`) VALUES ('3', '3');
INSERT INTO `news_tag_relations` (`news_id`, `tag_id`) VALUES ('5', '3');
INSERT INTO `news_tag_relations` (`news_id`, `tag_id`) VALUES ('1', '4');
INSERT INTO `news_tag_relations` (`news_id`, `tag_id`) VALUES ('3', '4');
INSERT INTO `news_tag_relations` (`news_id`, `tag_id`) VALUES ('4', '5');

-- ------------------------------------------------------------
-- Table structure for `news_tags`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `news_tags`;
CREATE TABLE `news_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_uz` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ru` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_tag_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `news_tags`
INSERT INTO `news_tags` (`id`, `name_uz`, `name_ru`, `name_en`, `slug`, `created_at`) VALUES ('1', 'Qabul 2026', 'Прием 2026', 'Admission 2026', 'qabul-2026', '2026-11-16 18:55:25');
INSERT INTO `news_tags` (`id`, `name_uz`, `name_ru`, `name_en`, `slug`, `created_at`) VALUES ('2', 'IT va Dasturlash', 'ИТ и программирование', 'IT & Programming', 'it-dasturlash', '2026-11-16 18:55:25');
INSERT INTO `news_tags` (`id`, `name_uz`, `name_ru`, `name_en`, `slug`, `created_at`) VALUES ('3', 'Amaliyot', 'Практика', 'Internship', 'amaliyot', '2026-11-16 18:55:25');
INSERT INTO `news_tags` (`id`, `name_uz`, `name_ru`, `name_en`, `slug`, `created_at`) VALUES ('4', 'Ustaxona', 'Мастерская', 'Workshop', 'ustaxona', '2026-11-16 18:55:25');
INSERT INTO `news_tags` (`id`, `name_uz`, `name_ru`, `name_en`, `slug`, `created_at`) VALUES ('5', 'Musobaqa', 'Соревнование', 'Competition', 'musobaqa', '2026-11-16 18:55:25');

-- ------------------------------------------------------------
-- Table structure for `pages`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title_uz` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_ru` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_uz` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_ru` longtext COLLATE utf8mb4_unicode_ci,
  `content_en` longtext COLLATE utf8mb4_unicode_ci,
  `banner_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_page_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `pages`
INSERT INTO `pages` (`id`, `title_uz`, `title_ru`, `title_en`, `slug`, `content_uz`, `content_ru`, `content_en`, `banner_image`, `meta_title`, `meta_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('1', 'Kollej tarixi va faoliyati', 'История и деятельность колледжа', 'College History and Overview', 'kollej-tarixi', '<h2>Kosonsoy kolleji tarixi</h2><p>Kosonsoy kasb-hunar kolleji hududda malakali o\'rta bo\'g\'in mutaxassislarini tayyorlashda uzoq yillik boy an\'analarga ega bo\'lgan ta\'lim dargohidir. Dastlab hunarmandchilik maktabi sifatida tashkil etilgan muassasa keyinchalik zamonaviy kasb-hunar kollejiga aylantirildi.</p><p>Hozirgi kunda kollejda 14 ta mutaxassislik bo\'yicha mingdan ziyod o\'quvchilar eng zamonaviy o\'quv xonalari va ustaxonalarda saboq olmoqdalar. Ta\'lim muassasasida Germaniyaning dual ta\'lim modeli joriy etilgan bo\'lib, o\'quvchilar nazariy bilimlarni bevosita korxonalarda mustahkamlaydilar.</p><h3>Bizning qadriyatlarimiz:</h3><ul><li>Sifatli va amaliyotga yo\'naltirilgan ta\'lim;</li><li>Mehnat bozorida yuqori talabga ega kasblar;</li><li>Ustoz-shogird an\'anasi;</li><li>Zamonaviy innovatsion texnologiyalar;</li><li>Har bir o\'quvchining shaxsiy va kasbiy yuksalishi.</li></ul>', '<h2>История Косонсойского колледжа</h2><p>Косонсойский профессиональный колледж имеет многолетние традиции в подготовке квалифицированных специалистов среднего звена.</p>', '<h2>History of Kosonsoy College</h2><p>Kosonsoy Vocational College has a rich tradition of training highly qualified middle-tier technical specialists.</p>', '/assets/images/about-banner.jpg', 'Kollej tarixi - Kosonsoy Kolleji', 'Kosonsoy kolleji tarixi, tashkil etilishi va faoliyati haqida batafsil ma\'lumot.', '1', '0', '2026-11-16 18:55:25', '2026-11-16 18:55:25');

-- ------------------------------------------------------------
-- Table structure for `partners`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `partners`;
CREATE TABLE `partners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `website_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_uz` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_ru` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `partners`
INSERT INTO `partners` (`id`, `name`, `logo`, `website_url`, `description_uz`, `description_ru`, `description_en`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'Namangan viloyat Sog\'liqni saqlash boshqarmasi', '/assets/images/partner-1.svg', 'https://ssv.uz', 'Viloyat bosh tibbiyot va sog\'liqni saqlash muassasasi', '', '', '1', '1', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `partners` (`id`, `name`, `logo`, `website_url`, `description_uz`, `description_ru`, `description_en`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('2', 'Kosonsoy tuman Tibbiyot birlashmasi (TTB)', '/assets/images/partner-2.svg', 'https://ssv.uz', 'Asosiy klinik amaliyot va shifoxona bazasi', '', '', '2', '1', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `partners` (`id`, `name`, `logo`, `website_url`, `description_uz`, `description_ru`, `description_en`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('3', 'Respublika shoshilinch tez tibbiy yordam markazi', '/assets/images/partner-3.svg', 'https://ssv.uz', 'Shoshilinch tibbiy yordam va reanimatsiya amaliyoti', '', '', '3', '1', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `partners` (`id`, `name`, `logo`, `website_url`, `description_uz`, `description_ru`, `description_en`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('4', 'Farmatsevtika tarmog\'ini rivojlantirish agentligi', '/assets/images/partner-4.svg', 'https://uzpharmagency.uz', 'Farmatsiya va dori ishlab chiqarish amaliyoti', '', '', '4', '1', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `partners` (`id`, `name`, `logo`, `website_url`, `description_uz`, `description_ru`, `description_en`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('5', 'O\'zbekiston Qizil Yarim Oy Jamiyati', '/assets/images/partner-5.svg', 'https://redcrescent.uz', 'Insonparvarlik va birinchi tibbiy yordam amaliyoti', '', '', '5', '1', '2026-11-16 19:23:25', '2026-11-16 19:23:25');

-- ------------------------------------------------------------
-- Table structure for `permissions`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `idx_perm_module` (`module`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `permissions`
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('1', 'news.view', 'Yangiliklarni ko\'rish', 'news', 'Yangiliklar ro\'yxati va tafsilotlarini ko\'rish', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('2', 'news.create', 'Yangilik qo\'shish', 'news', 'Yangi maqola yoki yangilik yaratish', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('3', 'news.edit', 'Yangilikni tahrirlash', 'news', 'Mavjud yangiliklarni o\'zgartirish', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('4', 'news.delete', 'Yangilikni o\'chirish', 'news', 'Yangiliklarni o\'chirish va arxivlash', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('5', 'categories.manage', 'Kategoriyalarni boshqarish', 'categories', 'Kategoriyalar CRUD', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('6', 'management.manage', 'Rahbariyatni boshqarish', 'management', 'Rahbariyat va xodimlar ma\'lumotlarini tahrirlash', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('7', 'employees.manage', 'Xodimlarni boshqarish', 'employees', 'O\'qituvchilar va xodimlar CRUD', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('8', 'statistics.manage', 'Statistikani boshqarish', 'statistics', 'Statistik ko\'rsatkichlarni yangilash', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('9', 'vacancies.manage', 'Vakansiyalarni boshqarish', 'vacancies', 'Ish o\'rinlarini e\'lon qilish va boshqarish', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('10', 'applications.manage', 'Vakansiya arizalarini ko\'rish', 'applications', 'Nomzodlar arizalarini ko\'rib chiqish va baholash', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('11', 'messages.manage', 'Murojaatlarni boshqarish', 'messages', 'Virtual qabulxona murojaatlarini ko\'rish', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('12', 'messages.reply', 'Murojaatlarga javob berish', 'messages', 'Fuqarolar murojaatiga rasmiy javob yo\'llash', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('13', 'pages.manage', 'Sahifalarni boshqarish', 'pages', 'Statik va dinamik sahifalar CRUD', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('14', 'menus.manage', 'Menyuni boshqarish', 'menus', 'Sayt menyulari strukturasini boshqarish', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('15', 'banners.manage', 'Bannerlarni boshqarish', 'banners', 'Bosh sahifa slayderini boshqarish', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('16', 'gallery.manage', 'Galereyani boshqarish', 'gallery', 'Fotogalereya albomlarini boshqarish', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('17', 'documents.manage', 'Hujjatlarni boshqarish', 'documents', 'Rasmiy me\'yoriy hujjatlar CRUD', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('18', 'partners.manage', 'Hamkorlarni boshqarish', 'partners', 'Hamkor tashkilotlarni boshqarish', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('19', 'media.manage', 'Fayllar menejeri', 'media', 'Media kutubxonasini boshqarish', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('20', 'users.manage', 'Foydalanuvchilarni boshqarish', 'users', 'Adminlar va moderatorlar hisoblarini boshqarish', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('21', 'roles.manage', 'Rollar va ruxsatlar', 'roles', 'Rollar va ruxsatlar matritsasini sozlash', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('22', 'settings.manage', 'Sayt sozlamalari', 'settings', 'Global sayt sozlamalari va Telegram integratsiyasi', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('23', 'audit_logs.view', 'Audit jurnali', 'audit_logs', 'Tizim amallari tarixini ko\'rish', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`, `updated_at`) VALUES ('24', 'programs.manage', 'Yo\'nalishlarni boshqarish', 'programs', NULL, '2026-11-16 20:01:54', '2026-11-16 20:01:54');

-- ------------------------------------------------------------
-- Table structure for `programs`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `programs`;
CREATE TABLE `programs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title_uz` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_uz` text COLLATE utf8mb4_unicode_ci,
  `description_ru` text COLLATE utf8mb4_unicode_ci,
  `description_en` text COLLATE utf8mb4_unicode_ci,
  `icon` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'bi-heart-pulse-fill',
  `icon_color` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'primary',
  `badge_category_uz` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Tibbiyot',
  `badge_category_ru` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `badge_category_en` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration_uz` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '3 yil',
  `duration_ru` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration_en` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type_uz` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Grant / Shartnoma',
  `type_ru` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type_en` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_active_sort` (`is_active`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `programs`
INSERT INTO `programs` (`id`, `title_uz`, `title_ru`, `title_en`, `description_uz`, `description_ru`, `description_en`, `icon`, `icon_color`, `badge_category_uz`, `badge_category_ru`, `badge_category_en`, `duration_uz`, `duration_ru`, `duration_en`, `type_uz`, `type_ru`, `type_en`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'Hamshiralik ishi', 'Сестринское дело', 'Nursing', 'Umumiy amaliyot hamshirasi, statsionar va ambulator sharoitda bemorlarni parvarishlash, dori vositalarini kiritish, infuzion muolajalar va reanimatsion parvarish.', 'Медицинская сестра общей практики, уход за больными в стационарных и амбулаторных условиях, введение лекарственных средств и инфузионная терапия.', 'General practice nursing, patient care in inpatient and outpatient settings, medication administration, and infusion procedures.', 'bi-heart-pulse-fill', 'primary', 'Tibbiyot', 'Медицина', 'Medicine', '3 yil', '3 года', '3 years', 'Grant / Shartnoma', 'Грант / Контракт', 'Grant / Contract', '1', '1', '2026-11-16 20:01:54', '2026-11-16 20:01:54');
INSERT INTO `programs` (`id`, `title_uz`, `title_ru`, `title_en`, `description_uz`, `description_ru`, `description_en`, `icon`, `icon_color`, `badge_category_uz`, `badge_category_ru`, `badge_category_en`, `duration_uz`, `duration_ru`, `duration_en`, `type_uz`, `type_ru`, `type_en`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('2', 'Davolash ishi (Feldsherlik)', 'Лечебное дело (Фельдшер)', 'General Medicine (Paramedic)', 'Shoshilinch tez tibbiy yordam ko\'rsatish, kasalliklarni dastlabki klinik tashxislash, EKG olish, feldsherlik punktlarida aholi salomatligini muhofaza qilish.', 'Оказание экстренной скорой медицинской помощи, первичная диагностика заболеваний, снятие ЭКГ, работа на фельдшерских пунктах.', 'Emergency medical care, initial clinical diagnostics, ECG, and public health protection at paramedic stations.', 'bi-bandaid-fill', 'danger', 'Shoshilinch tibbiyot', 'Экстренная медицина', 'Emergency Medicine', '3 yil', '3 года', '3 years', 'Tez tibbiy yordam', 'Скорая помощь', 'Ambulance service', '2', '1', '2026-11-16 20:01:54', '2026-11-16 20:01:54');
INSERT INTO `programs` (`id`, `title_uz`, `title_ru`, `title_en`, `description_uz`, `description_ru`, `description_en`, `icon`, `icon_color`, `badge_category_uz`, `badge_category_ru`, `badge_category_en`, `duration_uz`, `duration_ru`, `duration_en`, `type_uz`, `type_ru`, `type_en`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('3', 'Farmatsiya (Dorishunoslik)', 'Фармация', 'Pharmacy', 'Dorivor moddalar, retseptura asosida dorilar tayyorlash, dorixona boshqaruvi, farmatsevtik tahlil va dori vositalarini saqlash qoidalari.', 'Лекарственные средства, изготовление лекарств по рецептам, аптечный менеджмент, фармацевтический анализ и хранение медикаментов.', 'Medicinal substances, compounding pharmaceuticals by prescriptions, pharmacy management, and quality analysis.', 'bi-capsule', 'success', 'Farmatsevtika', 'Фармацевтика', 'Pharmaceuticals', '2 yil', '2 года', '2 years', 'Dorixona ishi', 'Аптечное дело', 'Pharmacy practice', '3', '1', '2026-11-16 20:01:54', '2026-11-16 20:01:54');
INSERT INTO `programs` (`id`, `title_uz`, `title_ru`, `title_en`, `description_uz`, `description_ru`, `description_en`, `icon`, `icon_color`, `badge_category_uz`, `badge_category_ru`, `badge_category_en`, `duration_uz`, `duration_ru`, `duration_en`, `type_uz`, `type_ru`, `type_en`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('4', 'Akusherlik ishi', 'Акушерское дело', 'Midwifery', 'Homilador ayollar dispanserizatsiyasi, tug\'ruqqa tayyorlash va tug\'ruq jarayoniga yordam berish, onalar va chaqaloqlar salomatligini muhofaza qilish.', 'Диспансеризация беременных, подготовка и ведение родов, охрана здоровья матерей и новорожденных детей.', 'Antenatal care, labor and delivery assistance, maternal and neonatal health protection.', 'bi-gender-female', 'warning', 'Onalik va bolalik', 'Материнство и детство', 'Maternal & Child Health', '3 yil', '3 года', '3 years', 'Perinatal parvarish', 'Перинатальный уход', 'Perinatal care', '4', '1', '2026-11-16 20:01:54', '2026-11-16 20:01:54');
INSERT INTO `programs` (`id`, `title_uz`, `title_ru`, `title_en`, `description_uz`, `description_ru`, `description_en`, `icon`, `icon_color`, `badge_category_uz`, `badge_category_ru`, `badge_category_en`, `duration_uz`, `duration_ru`, `duration_en`, `type_uz`, `type_ru`, `type_en`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('5', 'Stomatologiya ishi (Tish texnigi)', 'Стоматология ортопедическая (Зубной техник)', 'Orthopedic Dentistry (Dental Technician)', 'Zamonaviy tish protezlari, metallokeramika, ortodontik moslamalar yasash, stomatologik materialshunoslik va laboratoriya amaliyoti.', 'Изготовление зубных протезов, металлокерамика, ортодонтические аппараты, материаловедение и лабораторная практика.', 'Fabrication of modern dental prostheses, metal-ceramics, orthodontic appliances, and laboratory practice.', 'bi-scissors', 'info', 'Stomatologiya', 'Стоматология', 'Dentistry', '2 yil', '2 года', '2 years', 'Tish texnigi', 'Зубной техник', 'Dental tech', '5', '1', '2026-11-16 20:01:54', '2026-11-16 20:01:54');
INSERT INTO `programs` (`id`, `title_uz`, `title_ru`, `title_en`, `description_uz`, `description_ru`, `description_en`, `icon`, `icon_color`, `badge_category_uz`, `badge_category_ru`, `badge_category_en`, `duration_uz`, `duration_ru`, `duration_en`, `type_uz`, `type_ru`, `type_en`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('6', 'Tibbiy profilaktika ishi', 'Медико-профилактическое дело', 'Preventive Medicine', 'Aholi salomatligini mustahkamlash, yuqumli kasalliklar profilaktikasi, sanitariya-epidemiologik nazorat va sog\'lom turmush tarzini targ\'ib qilish.', 'Укрепление здоровья населения, профилактика инфекционных болезней, санитарно-эпидемиологический надзор и пропаганда ЗОЖ.', 'Promoting public health, infectious disease prevention, sanitary-epidemiological surveillance, and healthy lifestyle advocacy.', 'bi-shield-check', 'teal', 'Jamoat salomatligi', 'Общественное здоровье', 'Public Health', '2 yil', '2 года', '2 years', 'Sanitariya nazorati', 'Санитарный надзор', 'Sanitary surveillance', '6', '1', '2026-11-16 20:01:54', '2026-11-16 20:01:54');

-- ------------------------------------------------------------
-- Table structure for `role_permissions`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE `role_permissions` (
  `role_id` int(10) unsigned NOT NULL,
  `permission_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `fk_rp_permission` (`permission_id`),
  CONSTRAINT `fk_rp_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rp_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `role_permissions`
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '1');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '1');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('3', '1');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '2');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '2');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('3', '2');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '3');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '3');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('3', '3');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '4');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '4');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('3', '4');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '5');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '5');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('3', '5');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '6');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '6');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '7');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '7');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '8');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '8');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '9');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '9');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('4', '9');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '10');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '10');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('4', '10');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '11');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '11');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('4', '11');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '12');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '12');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('4', '12');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '13');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '13');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('3', '13');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '14');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '14');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '15');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '15');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('3', '15');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '16');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '16');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('3', '16');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '17');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '17');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('3', '17');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '18');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '18');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '19');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '19');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('3', '19');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '20');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '20');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '21');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '22');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '23');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '23');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('1', '24');
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES ('2', '24');

-- ------------------------------------------------------------
-- Table structure for `roles`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `roles`
INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES ('1', 'SUPER_ADMIN', 'Bosh Administrator', 'Tizimning barcha imkoniyatlari va sozlamalariga to\'liq kirish huquqi', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES ('2', 'ADMIN', 'Administrator', 'Asosiy modullarni boshqarish va nazorat qilish', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES ('3', 'EDITOR', 'Muharrir', 'Yangiliklar, sahifalar va media kontentni boshqarish', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES ('4', 'MODERATOR', 'Moderator', 'Murojaatlar va vakansiya arizalarini ko\'rib chiqish', '2026-11-16 18:55:25', '2026-11-16 18:55:25');

-- ------------------------------------------------------------
-- Table structure for `site_settings`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `site_settings`;
CREATE TABLE `site_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_value` text COLLATE utf8mb4_unicode_ci,
  `group_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'general',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_name` (`key_name`),
  KEY `idx_sett_key` (`key_name`),
  KEY `idx_sett_grp` (`group_name`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `site_settings`
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('1', 'site_name', 'Kosonsoy Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumi', 'general', '2026-11-16 18:55:25', '2026-11-16 19:21:18');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('2', 'site_tagline', 'Kasbiy ta\'lim, zamonaviy ko\'nikmalar va porloq kelajak poydevori', 'general', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('3', 'site_phone', '+998 (69) 652-14-25', 'contacts', '2026-11-16 18:55:25', '2026-11-16 19:21:18');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('4', 'site_hotline', '1103', 'contacts', '2026-11-16 18:55:25', '2026-11-16 19:21:18');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('5', 'site_email', 'info@kosonsoyjst.uz', 'contacts', '2026-11-16 18:55:25', '2026-11-16 19:21:18');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('6', 'site_address', 'Namangan viloyati, Kosonsoy tumani, Tibbiyot ko\'chasi, 12-uy', 'contacts', '2026-11-16 18:55:25', '2026-11-16 19:21:18');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('7', 'working_hours', 'Dushanba - Shanba: 08:30 - 17:30', 'contacts', '2026-11-16 18:55:25', '2026-11-16 19:21:18');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('8', 'telegram_channel', 'https://t.me/kosonsoy_kolleji', 'social', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('9', 'instagram_url', 'https://instagram.com/kosonsoy_jst', 'social', '2026-11-16 18:55:25', '2026-11-16 19:21:18');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('10', 'facebook_url', 'https://facebook.com/kosonsoy.jst', 'social', '2026-11-16 18:55:25', '2026-11-16 19:21:18');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('11', 'youtube_url', 'https://youtube.com/@kosonsoyjst', 'social', '2026-11-16 18:55:25', '2026-11-16 19:21:18');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('12', 'telegram_bot_token', '', 'telegram', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('13', 'telegram_chat_id', '', 'telegram', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('14', 'telegram_notifications_enabled', '0', 'telegram', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('15', 'meta_title_default', 'Kosonsoy Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumi - Rasmiy veb-sayti', 'seo', '2026-11-16 18:55:25', '2026-11-16 19:21:18');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('16', 'meta_desc_default', 'Namangan viloyati Kosonsoy Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumi rasmiy veb-portali. Hamshiralik, davolash, farmatsiya va laboratoriya yo\'nalishlari, qabul 2026, statistika va virtual qabulxona.', 'seo', '2026-11-16 18:55:25', '2026-11-16 19:22:26');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('17', 'meta_keywords_default', 'Kosonsoy JST, Abu Ali ibn Sino texnikumi, Jamoat salomatligi texnikumi, Kosonsoy tibbiyot texnikumi, Namangan viloyati, Kosonsoy tumani, hamshiralik ishi, farmatsiya, feldsherlik, qabul 2026', 'seo', '2026-11-16 18:55:25', '2026-11-16 19:21:18');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('18', 'maintenance_mode', '0', 'system', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('19', 'director_quote_uz', 'Bizning bosh maqsadimiz — har bir yoshga zamonaviy kasbiy bilimlarni berish, ularni mehnat bozorida yuqori talabga ega, mustaqil fikrlaydigan raqobatbardosh mutaxassis qilib tarbiyalashdir.', 'homepage', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('20', 'director_quote_ru', 'Наша главная цель — дать каждому молодому человеку современные профессиональные знания, воспитать из них востребованных и конкурентоспособных специалистов.', 'homepage', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('21', 'director_quote_en', 'Our main goal is to provide every young person with modern professional knowledge and train them into highly demanded, competitive specialists in the labor market.', 'homepage', '2026-11-16 18:55:25', '2026-11-16 18:55:25');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('22', 'director_name', 'Zokirov Anvar Rustamovich', 'homepage', '2026-11-16 18:55:25', '2026-11-16 19:21:18');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('23', 'director_title', 'Texnikum direktori, tibbiyot fanlari nomzodi', 'homepage', '2026-11-16 18:55:25', '2026-11-16 19:21:18');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('25', 'site_short_name', 'Kosonsoy JST', 'general', '2026-11-16 19:21:18', '2026-11-16 19:21:18');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('26', 'site_title', 'Kosonsoy Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumi - Rasmiy veb-portali', 'general', '2026-11-16 19:21:18', '2026-11-16 19:21:18');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('37', 'telegram_url', 'https://t.me/kosonsoy_jst', 'general', '2026-11-16 19:21:18', '2026-11-16 19:21:18');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('42', 'site_name_ru', 'Косонсайский техникум общественного здоровья имени Абу Али ибн Сино', 'general', '2026-11-16 19:22:26', '2026-11-16 19:22:26');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('43', 'site_name_en', 'Kosonsoy Abu Ali ibn Sino Technical School of Public Health', 'general', '2026-11-16 19:22:26', '2026-11-16 19:22:26');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('46', 'site_region', 'Namangan viloyati', 'general', '2026-11-16 19:22:26', '2026-11-16 19:22:26');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('47', 'site_district', 'Kosonsoy tumani', 'general', '2026-11-16 19:22:26', '2026-11-16 19:22:26');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('49', 'site_address_ru', 'Наманганская область, Касансайский район, улица Тиббиёт, 12', 'general', '2026-11-16 19:22:26', '2026-11-16 19:22:26');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('50', 'site_address_en', '12, Tibbiyot street, Kosonsoy district, Namangan region', 'general', '2026-11-16 19:22:26', '2026-11-16 19:22:26');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('56', 'director_speech', 'Assalomu alaykum, qadrli o\'quvchilar, ustozlar va aziz ota-onalar! Abu Ali ibn Sino nomidagi Jamoat salomatligi texnikumimiz Namangan viloyati va respublikamiz sog\'liqni saqlash tizimi uchun yuksak malakali, bilimli va fidoyi o\'rta bo\'g\'in tibbiyot xodimlarini yetishtirib chiqarmoqda. Zamonaviy simulyatsion o\'quv markazlarimiz, yetakchi shifoxonalar bilan yo\'lga qo\'yilgan klinik amaliyot hamda kuchli pedagogik salohiyatimiz orqali har bir talabamizning yetuk tibbiyot mutaxassisi bo\'lib yetishishiga kafolat beramiz.', 'general', '2026-11-16 19:22:26', '2026-11-16 19:22:26');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('137', 'site_logo', '/assets/images/logo.png', 'general', '2026-11-16 19:43:20', '2026-11-16 19:43:20');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('138', 'site_favicon', '/assets/images/favicon.png', 'general', '2026-11-16 19:43:20', '2026-11-16 19:43:20');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('139', 'site_logo_admin', '/assets/images/logo-admin.png', 'general', '2026-11-16 19:43:20', '2026-11-16 19:43:20');
INSERT INTO `site_settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES ('140', 'google_maps_iframe', 'https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d827.0859539574639!2d71.548260664038!3d41.24567371795184!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e1!3m2!1sru!2s!4v1794849669585!5m2!1sru!2s', 'contacts', '2026-11-16 20:17:20', '2026-11-16 20:21:32');

-- ------------------------------------------------------------
-- Table structure for `statistics`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `statistics`;
CREATE TABLE `statistics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title_uz` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_ru` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_en` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count_value` int(11) NOT NULL DEFAULT '0',
  `suffix` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '+',
  `icon` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT 'bi-mortarboard',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_stats_sort` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `statistics`
INSERT INTO `statistics` (`id`, `title_uz`, `title_ru`, `title_en`, `count_value`, `suffix`, `icon`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'Jami tahsil olayotgan talabalar', 'Всего обучающихся студентов', 'Total enrolled students', '1850', '+', 'bi-people-fill', '1', '1', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `statistics` (`id`, `title_uz`, `title_ru`, `title_en`, `count_value`, `suffix`, `icon`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('2', 'Malakali shifokor va ustozlar', 'Квалифицированные врачи и педагоги', 'Qualified doctors and teachers', '120', '+', 'bi-person-badge-fill', '2', '1', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `statistics` (`id`, `title_uz`, `title_ru`, `title_en`, `count_value`, `suffix`, `icon`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('3', 'Tibbiy ta\'lim yo\'nalishlari', 'Медицинские направления обучения', 'Medical study programs', '7', ' ta', 'bi-heart-pulse-fill', '3', '1', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `statistics` (`id`, `title_uz`, `title_ru`, `title_en`, `count_value`, `suffix`, `icon`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('4', 'Klinik amaliyot bazalari', 'Базы клинической практики', 'Clinical practice bases', '25', '+', 'bi-hospital-fill', '4', '1', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `statistics` (`id`, `title_uz`, `title_ru`, `title_en`, `count_value`, `suffix`, `icon`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('5', 'Bitiruvchilarning ish bilan ta\'minlanishi', 'Трудоустройство выпускников', 'Graduate employment rate', '94', '%', 'bi-award-fill', '5', '1', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `statistics` (`id`, `title_uz`, `title_ru`, `title_en`, `count_value`, `suffix`, `icon`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('6', 'Simulyatsion va o\'quv laboratoriyalari', 'Симуляционные лаборатории', 'Simulation laboratories', '18', ' ta', 'bi-shield-check', '6', '1', '2026-11-16 19:23:25', '2026-11-16 19:23:25');

-- ------------------------------------------------------------
-- Table structure for `users`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_users_role` (`role_id`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `users`
INSERT INTO `users` (`id`, `role_id`, `username`, `email`, `password`, `full_name`, `phone`, `avatar`, `status`, `remember_token`, `last_login_at`, `created_at`, `updated_at`) VALUES ('1', '1', 'admin', 'admin@kosonsoykollej.uz', '$2y$10$5/dLjGJDiod6utYgE0GQk.rXjzwNNJkopaXEi0UgZXZU./GSr.lKC', 'Bosh Administrator', '+998 (90) 123-45-67', '/assets/images/avatar-default.png', 'active', NULL, '2026-11-16 22:17:49', '2026-11-16 18:55:25', '2026-11-16 20:17:49');

-- ------------------------------------------------------------
-- Table structure for `vacancies`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `vacancies`;
CREATE TABLE `vacancies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title_uz` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_ru` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department_uz` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_ru` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department_en` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employment_type` enum('full_time','part_time','internship','contract') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'full_time',
  `salary_text` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'Suhbat asosida',
  `deadline_date` date DEFAULT NULL,
  `requirements_uz` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `requirements_ru` text COLLATE utf8mb4_unicode_ci,
  `requirements_en` text COLLATE utf8mb4_unicode_ci,
  `responsibilities_uz` text COLLATE utf8mb4_unicode_ci,
  `responsibilities_ru` text COLLATE utf8mb4_unicode_ci,
  `responsibilities_en` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_vac_active` (`is_active`,`is_deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Records for `vacancies`
INSERT INTO `vacancies` (`id`, `title_uz`, `title_ru`, `title_en`, `department_uz`, `department_ru`, `department_en`, `employment_type`, `salary_text`, `deadline_date`, `requirements_uz`, `requirements_ru`, `requirements_en`, `responsibilities_uz`, `responsibilities_ru`, `responsibilities_en`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('1', 'Hamshiralik ishi va klinik fanlar o\'qituvchisi', 'Преподаватель сестринского дела и клинических дисциплин', 'Instructor of Nursing and Clinical Disciplines', 'Hamshiralik ishi kafedrasi', 'Кафедра сестринского дела', 'Department of Nursing', 'full_time', '4 500 000 - 7 000 000 so\'m', '2026-12-31', 'Oliy tibbiy ma\'lumot (umumiy amaliyot shifokori yoki oliy toifali hamshira), kamida 3 yillik klinik va pedagogik tajriba.', 'Высшее медицинское образование, опыт клинической и педагогической работы от 3 лет.', 'Higher medical education, at least 3 years of clinical and teaching experience.', 'Nazariy va amaliy mashg\'ulotlarni o\'tish, talabalar klinik amaliyotiga rahbarlik qilish.', 'Проведение теоретических и практических занятий, руководство практикой студентов.', 'Conducting theoretical and practical classes, supervising student clinical rotations.', '1', '0', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `vacancies` (`id`, `title_uz`, `title_ru`, `title_en`, `department_uz`, `department_ru`, `department_en`, `employment_type`, `salary_text`, `deadline_date`, `requirements_uz`, `requirements_ru`, `requirements_en`, `responsibilities_uz`, `responsibilities_ru`, `responsibilities_en`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('2', 'Farmakologiya va farmatsevtika texnologiyasi o\'qituvchisi', 'Преподаватель фармакологии и фармацевтической технологии', 'Instructor of Pharmacology and Pharmaceutical Technology', 'Farmatsiya bo\'limi', 'Отделение фармации', 'Pharmacy Department', 'full_time', '4 200 000 - 6 500 000 so\'m', '2026-12-25', 'Oliy farmatsevtik ma\'lumot (provizor), dori turlarini tayyorlash va farmakologiya bo\'yicha amaliy bilimlar.', 'Высшее фармацевтическое образование (провизор), знание технологий лекарственных форм.', 'Higher pharmaceutical education (pharmacist), expertise in dosage form technologies.', 'Laboratoriya mashg\'ulotlarini o\'tkazish, farmatsevtika o\'quv dasturlarini ishlab chiqish.', 'Проведение лабораторных работ, разработка учебных программ.', 'Conducting laboratory sessions, developing pharmaceutical curricula.', '1', '0', '2026-11-16 19:23:25', '2026-11-16 19:23:25');
INSERT INTO `vacancies` (`id`, `title_uz`, `title_ru`, `title_en`, `department_uz`, `department_ru`, `department_en`, `employment_type`, `salary_text`, `deadline_date`, `requirements_uz`, `requirements_ru`, `requirements_en`, `responsibilities_uz`, `responsibilities_ru`, `responsibilities_en`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES ('3', 'Odam anatomiyasi va patologik fiziologiya fani o\'qituvchisi', 'Преподаватель анатомии человека и патологической физиологии', 'Instructor of Human Anatomy and Pathological Physiology', 'Umumkasbiy tibbiy fanlar', 'Общепрофессиональные медицинские дисциплины', 'General Medical Sciences', 'full_time', '4 000 000 - 6 800 000 so\'m', '2026-12-20', 'Oliy tibbiy ma\'lumot, zamonaviy interaktiv anatomiya metodikalarini bilish.', 'Высшее медицинское образование, знание интерактивных методик преподавания анатомии.', 'Higher medical degree, expertise in modern interactive anatomical teaching methods.', 'Anatomiya preparatlari va simulyatorlarda amaliy mashg\'ulotlar o\'tish.', 'Проведение практических занятий на анатомических препаратах и симуляторах.', 'Conducting hands-on sessions using anatomical specimens and simulators.', '1', '0', '2026-11-16 19:23:25', '2026-11-16 19:23:25');

-- ------------------------------------------------------------
-- Table structure for `vacancy_applications`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `vacancy_applications`;
CREATE TABLE `vacancy_applications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vacancy_id` int(10) unsigned NOT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `cv_file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('NEW','REVIEWING','ACCEPTED','REJECTED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NEW',
  `admin_notes` text COLLATE utf8mb4_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_va_vacancy` (`vacancy_id`),
  KEY `idx_va_status` (`status`),
  CONSTRAINT `fk_va_vacancy` FOREIGN KEY (`vacancy_id`) REFERENCES `vacancies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
