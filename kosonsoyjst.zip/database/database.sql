-- Database Schema for KOSONSOY KOLLEJI
-- Charset: utf8mb4, Collation: utf8mb4_unicode_ci

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 1. Roles table
DROP TABLE IF EXISTS `role_permissions`;
DROP TABLE IF EXISTS `permissions`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(50) NOT NULL UNIQUE,
  `display_name` VARCHAR(100) NOT NULL,
  `description` VARCHAR(255) NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Permissions table
CREATE TABLE `permissions` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `display_name` VARCHAR(150) NOT NULL,
  `module` VARCHAR(50) NOT NULL,
  `description` VARCHAR(255) NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_perm_module` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Role Permissions table
CREATE TABLE `role_permissions` (
  `role_id` INT UNSIGNED NOT NULL,
  `permission_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`role_id`, `permission_id`),
  CONSTRAINT `fk_rp_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rp_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Users table
CREATE TABLE `users` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `role_id` INT UNSIGNED NOT NULL,
  `username` VARCHAR(60) NOT NULL UNIQUE,
  `email` VARCHAR(120) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(150) NOT NULL,
  `phone` VARCHAR(30) NULL,
  `avatar` VARCHAR(255) NULL,
  `status` ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
  `remember_token` VARCHAR(100) NULL,
  `last_login_at` DATETIME NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. News Categories
DROP TABLE IF EXISTS `news_tag_relations`;
DROP TABLE IF EXISTS `news_tags`;
DROP TABLE IF EXISTS `news_gallery`;
DROP TABLE IF EXISTS `news`;
DROP TABLE IF EXISTS `news_categories`;

CREATE TABLE `news_categories` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name_uz` VARCHAR(150) NOT NULL,
  `name_ru` VARCHAR(150) NULL,
  `name_en` VARCHAR(150) NULL,
  `slug` VARCHAR(160) NOT NULL UNIQUE,
  `description` VARCHAR(255) NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_cat_slug` (`slug`),
  INDEX `idx_cat_sort` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. News
CREATE TABLE `news` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT UNSIGNED NOT NULL,
  `author_id` INT UNSIGNED NULL,
  `title_uz` VARCHAR(255) NOT NULL,
  `title_ru` VARCHAR(255) NULL,
  `title_en` VARCHAR(255) NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `summary_uz` TEXT NULL,
  `summary_ru` TEXT NULL,
  `summary_en` TEXT NULL,
  `content_uz` LONGTEXT NOT NULL,
  `content_ru` LONGTEXT NULL,
  `content_en` LONGTEXT NULL,
  `image` VARCHAR(255) NULL,
  `views_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `is_featured` TINYINT(1) NOT NULL DEFAULT 0,
  `is_announcement` TINYINT(1) NOT NULL DEFAULT 0,
  `status` ENUM('published', 'draft', 'archived') NOT NULL DEFAULT 'published',
  `meta_title` VARCHAR(255) NULL,
  `meta_description` VARCHAR(255) NULL,
  `published_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_news_cat` FOREIGN KEY (`category_id`) REFERENCES `news_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_news_author` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  INDEX `idx_news_slug` (`slug`),
  INDEX `idx_news_status` (`status`, `is_deleted`),
  INDEX `idx_news_published` (`published_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. News Tags
CREATE TABLE `news_tags` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name_uz` VARCHAR(100) NOT NULL,
  `name_ru` VARCHAR(100) NULL,
  `name_en` VARCHAR(100) NULL,
  `slug` VARCHAR(120) NOT NULL UNIQUE,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_tag_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. News Tag Relations
CREATE TABLE `news_tag_relations` (
  `news_id` INT UNSIGNED NOT NULL,
  `tag_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`news_id`, `tag_id`),
  CONSTRAINT `fk_ntr_news` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ntr_tag` FOREIGN KEY (`tag_id`) REFERENCES `news_tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. News Gallery
CREATE TABLE `news_gallery` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `news_id` INT UNSIGNED NOT NULL,
  `image_path` VARCHAR(255) NOT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_ng_news` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Management (Rahbariyat)
DROP TABLE IF EXISTS `management`;
CREATE TABLE `management` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `full_name_uz` VARCHAR(150) NOT NULL,
  `full_name_ru` VARCHAR(150) NULL,
  `full_name_en` VARCHAR(150) NULL,
  `position_uz` VARCHAR(200) NOT NULL,
  `position_ru` VARCHAR(200) NULL,
  `position_en` VARCHAR(200) NULL,
  `category` ENUM('director', 'deputy_director', 'department_head') NOT NULL DEFAULT 'deputy_director',
  `bio_uz` TEXT NULL,
  `bio_ru` TEXT NULL,
  `bio_en` TEXT NULL,
  `phone` VARCHAR(50) NULL,
  `email` VARCHAR(100) NULL,
  `reception_days_uz` VARCHAR(255) NULL,
  `reception_days_ru` VARCHAR(255) NULL,
  `reception_days_en` VARCHAR(255) NULL,
  `image` VARCHAR(255) NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_mgmt_cat` (`category`),
  INDEX `idx_mgmt_sort` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Employees / Teachers (Xodimlar va O'qituvchilar)
DROP TABLE IF EXISTS `employees`;
CREATE TABLE `employees` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `full_name_uz` VARCHAR(150) NOT NULL,
  `full_name_ru` VARCHAR(150) NULL,
  `full_name_en` VARCHAR(150) NULL,
  `department_uz` VARCHAR(150) NOT NULL,
  `department_ru` VARCHAR(150) NULL,
  `department_en` VARCHAR(150) NULL,
  `specialty_uz` VARCHAR(150) NOT NULL,
  `specialty_ru` VARCHAR(150) NULL,
  `specialty_en` VARCHAR(150) NULL,
  `degree_uz` VARCHAR(100) NULL,
  `degree_ru` VARCHAR(100) NULL,
  `degree_en` VARCHAR(100) NULL,
  `phone` VARCHAR(50) NULL,
  `email` VARCHAR(100) NULL,
  `image` VARCHAR(255) NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_emp_sort` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. Statistics (Dinamik statistika)
DROP TABLE IF EXISTS `statistics`;
CREATE TABLE `statistics` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title_uz` VARCHAR(150) NOT NULL,
  `title_ru` VARCHAR(150) NULL,
  `title_en` VARCHAR(150) NULL,
  `count_value` INT NOT NULL DEFAULT 0,
  `suffix` VARCHAR(20) DEFAULT '+',
  `icon` VARCHAR(60) DEFAULT 'bi-mortarboard',
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_stats_sort` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. Vacancies (Vakansiyalar)
DROP TABLE IF EXISTS `vacancy_applications`;
DROP TABLE IF EXISTS `vacancies`;

CREATE TABLE `vacancies` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title_uz` VARCHAR(200) NOT NULL,
  `title_ru` VARCHAR(200) NULL,
  `title_en` VARCHAR(200) NULL,
  `department_uz` VARCHAR(150) NOT NULL,
  `department_ru` VARCHAR(150) NULL,
  `department_en` VARCHAR(150) NULL,
  `employment_type` ENUM('full_time', 'part_time', 'internship', 'contract') NOT NULL DEFAULT 'full_time',
  `salary_text` VARCHAR(100) DEFAULT 'Suhbat asosida',
  `deadline_date` DATE NULL,
  `requirements_uz` TEXT NOT NULL,
  `requirements_ru` TEXT NULL,
  `requirements_en` TEXT NULL,
  `responsibilities_uz` TEXT NULL,
  `responsibilities_ru` TEXT NULL,
  `responsibilities_en` TEXT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_vac_active` (`is_active`, `is_deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. Vacancy Applications (Arizalar)
CREATE TABLE `vacancy_applications` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `vacancy_id` INT UNSIGNED NOT NULL,
  `full_name` VARCHAR(150) NOT NULL,
  `phone` VARCHAR(40) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `message` TEXT NULL,
  `cv_file` VARCHAR(255) NOT NULL,
  `status` ENUM('NEW', 'REVIEWING', 'ACCEPTED', 'REJECTED') NOT NULL DEFAULT 'NEW',
  `admin_notes` TEXT NULL,
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_va_vacancy` FOREIGN KEY (`vacancy_id`) REFERENCES `vacancies` (`id`) ON DELETE CASCADE,
  INDEX `idx_va_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 15. Messages / Virtual Reception (Virtual qabulxona murojaatlari)
DROP TABLE IF EXISTS `message_replies`;
DROP TABLE IF EXISTS `messages`;

CREATE TABLE `messages` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `tracking_code` VARCHAR(30) NOT NULL UNIQUE,
  `full_name` VARCHAR(150) NOT NULL,
  `phone` VARCHAR(40) NOT NULL,
  `email` VARCHAR(100) NULL,
  `address` VARCHAR(255) NULL,
  `inquiry_type` ENUM('murojaat', 'taklif', 'shikoyat', 'ariza') NOT NULL DEFAULT 'murojaat',
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `attachment_file` VARCHAR(255) NULL,
  `status` ENUM('NEW', 'IN_PROGRESS', 'ANSWERED', 'CLOSED') NOT NULL DEFAULT 'NEW',
  `ip_address` VARCHAR(45) NULL,
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_msg_code` (`tracking_code`),
  INDEX `idx_msg_status` (`status`, `is_deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 16. Message Replies
CREATE TABLE `message_replies` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `message_id` INT UNSIGNED NOT NULL,
  `replied_by_user_id` INT UNSIGNED NULL,
  `reply_text` TEXT NOT NULL,
  `reply_file` VARCHAR(255) NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_mr_msg` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mr_user` FOREIGN KEY (`replied_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 17. Custom Pages (Sahifalar)
DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title_uz` VARCHAR(200) NOT NULL,
  `title_ru` VARCHAR(200) NULL,
  `title_en` VARCHAR(200) NULL,
  `slug` VARCHAR(200) NOT NULL UNIQUE,
  `content_uz` LONGTEXT NOT NULL,
  `content_ru` LONGTEXT NULL,
  `content_en` LONGTEXT NULL,
  `banner_image` VARCHAR(255) NULL,
  `meta_title` VARCHAR(255) NULL,
  `meta_description` VARCHAR(255) NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_page_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 18. Menus (Menyu boshqaruvi)
DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `parent_id` INT UNSIGNED NULL,
  `title_uz` VARCHAR(150) NOT NULL,
  `title_ru` VARCHAR(150) NULL,
  `title_en` VARCHAR(150) NULL,
  `url` VARCHAR(255) NOT NULL,
  `target` ENUM('_self', '_blank') NOT NULL DEFAULT '_self',
  `location` ENUM('header', 'footer', 'quick_links') NOT NULL DEFAULT 'header',
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_menu_parent` FOREIGN KEY (`parent_id`) REFERENCES `menus` (`id`) ON DELETE SET NULL,
  INDEX `idx_menu_loc` (`location`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 19. Banners (Bosh sahifa slayderi)
DROP TABLE IF EXISTS `banners`;
CREATE TABLE `banners` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title_uz` VARCHAR(255) NOT NULL,
  `title_ru` VARCHAR(255) NULL,
  `title_en` VARCHAR(255) NULL,
  `subtitle_uz` TEXT NULL,
  `subtitle_ru` TEXT NULL,
  `subtitle_en` TEXT NULL,
  `image` VARCHAR(255) NOT NULL,
  `button_text_uz` VARCHAR(100) NULL,
  `button_text_ru` VARCHAR(100) NULL,
  `button_text_en` VARCHAR(100) NULL,
  `button_url` VARCHAR(255) NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_banner_sort` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 20. Photo Gallery (Fotogalereya)
DROP TABLE IF EXISTS `gallery_images`;
DROP TABLE IF EXISTS `gallery`;

CREATE TABLE `gallery` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title_uz` VARCHAR(200) NOT NULL,
  `title_ru` VARCHAR(200) NULL,
  `title_en` VARCHAR(200) NULL,
  `event_date` DATE NULL,
  `cover_image` VARCHAR(255) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `gallery_images` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `gallery_id` INT UNSIGNED NOT NULL,
  `image_path` VARCHAR(255) NOT NULL,
  `caption` VARCHAR(255) NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_gi_gallery` FOREIGN KEY (`gallery_id`) REFERENCES `gallery` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 21. Documents (Rasmiy me'yoriy hujjatlar)
DROP TABLE IF EXISTS `documents`;
CREATE TABLE `documents` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title_uz` VARCHAR(255) NOT NULL,
  `title_ru` VARCHAR(255) NULL,
  `title_en` VARCHAR(255) NULL,
  `doc_number` VARCHAR(100) NULL,
  `doc_date` DATE NULL,
  `category` ENUM('law', 'decree', 'college_charter', 'license', 'certificate', 'other') NOT NULL DEFAULT 'other',
  `file_path` VARCHAR(255) NOT NULL,
  `file_size` VARCHAR(50) NULL,
  `download_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_doc_cat` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 22. Partners (Hamkorlar)
DROP TABLE IF EXISTS `partners`;
CREATE TABLE `partners` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `logo` VARCHAR(255) NOT NULL,
  `website_url` VARCHAR(255) NULL,
  `description_uz` VARCHAR(255) NULL,
  `description_ru` VARCHAR(255) NULL,
  `description_en` VARCHAR(255) NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 23. Site Settings (Sayt sozlamalari)
DROP TABLE IF EXISTS `site_settings`;
CREATE TABLE `site_settings` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `key_name` VARCHAR(100) NOT NULL UNIQUE,
  `key_value` TEXT NULL,
  `group_name` VARCHAR(50) NOT NULL DEFAULT 'general',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_sett_key` (`key_name`),
  INDEX `idx_sett_grp` (`group_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 24. Media Library (Fayl boshqaruvi)
DROP TABLE IF EXISTS `media`;
CREATE TABLE `media` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `file_name` VARCHAR(255) NOT NULL,
  `original_name` VARCHAR(255) NOT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `file_type` VARCHAR(50) NOT NULL,
  `file_size` INT UNSIGNED NOT NULL DEFAULT 0,
  `user_id` INT UNSIGNED NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_media_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 25. Audit Logs (Tizim xatti-harakatlari jurnali)
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NULL,
  `action` VARCHAR(50) NOT NULL,
  `module` VARCHAR(50) NOT NULL,
  `record_id` INT UNSIGNED NULL,
  `details` TEXT NULL,
  `ip_address` VARCHAR(45) NULL,
  `user_agent` VARCHAR(255) NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_al_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  INDEX `idx_al_module` (`module`),
  INDEX `idx_al_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

