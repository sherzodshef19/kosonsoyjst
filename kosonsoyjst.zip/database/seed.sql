-- Seed Data for KOSONSOY KOLLEJI
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- Roles
INSERT INTO `roles` (`id`, `name`, `display_name`, `description`) VALUES
(1, 'SUPER_ADMIN', 'Bosh Administrator', 'Tizimning barcha imkoniyatlari va sozlamalariga to\'liq kirish huquqi'),
(2, 'ADMIN', 'Administrator', 'Asosiy modullarni boshqarish va nazorat qilish'),
(3, 'EDITOR', 'Muharrir', 'Yangiliklar, sahifalar va media kontentni boshqarish'),
(4, 'MODERATOR', 'Moderator', 'Murojaatlar va vakansiya arizalarini ko\'rib chiqish');

-- Permissions
INSERT INTO `permissions` (`name`, `display_name`, `module`, `description`) VALUES
('news.view', 'Yangiliklarni ko\'rish', 'news', 'Yangiliklar ro\'yxati va tafsilotlarini ko\'rish'),
('news.create', 'Yangilik qo\'shish', 'news', 'Yangi maqola yoki yangilik yaratish'),
('news.edit', 'Yangilikni tahrirlash', 'news', 'Mavjud yangiliklarni o\'zgartirish'),
('news.delete', 'Yangilikni o\'chirish', 'news', 'Yangiliklarni o\'chirish va arxivlash'),
('categories.manage', 'Kategoriyalarni boshqarish', 'categories', 'Kategoriyalar CRUD'),
('management.manage', 'Rahbariyatni boshqarish', 'management', 'Rahbariyat va xodimlar ma\'lumotlarini tahrirlash'),
('employees.manage', 'Xodimlarni boshqarish', 'employees', 'O\'qituvchilar va xodimlar CRUD'),
('statistics.manage', 'Statistikani boshqarish', 'statistics', 'Statistik ko\'rsatkichlarni yangilash'),
('vacancies.manage', 'Vakansiyalarni boshqarish', 'vacancies', 'Ish o\'rinlarini e\'lon qilish va boshqarish'),
('applications.manage', 'Vakansiya arizalarini ko\'rish', 'applications', 'Nomzodlar arizalarini ko\'rib chiqish va baholash'),
('messages.manage', 'Murojaatlarni boshqarish', 'messages', 'Virtual qabulxona murojaatlarini ko\'rish'),
('messages.reply', 'Murojaatlarga javob berish', 'messages', 'Fuqarolar murojaatiga rasmiy javob yo\'llash'),
('pages.manage', 'Sahifalarni boshqarish', 'pages', 'Statik va dinamik sahifalar CRUD'),
('menus.manage', 'Menyuni boshqarish', 'menus', 'Sayt menyulari strukturasini boshqarish'),
('banners.manage', 'Bannerlarni boshqarish', 'banners', 'Bosh sahifa slayderini boshqarish'),
('gallery.manage', 'Galereyani boshqarish', 'gallery', 'Fotogalereya albomlarini boshqarish'),
('documents.manage', 'Hujjatlarni boshqarish', 'documents', 'Rasmiy me\'yoriy hujjatlar CRUD'),
('partners.manage', 'Hamkorlarni boshqarish', 'partners', 'Hamkor tashkilotlarni boshqarish'),
('media.manage', 'Fayllar menejeri', 'media', 'Media kutubxonasini boshqarish'),
('users.manage', 'Foydalanuvchilarni boshqarish', 'users', 'Adminlar va moderatorlar hisoblarini boshqarish'),
('roles.manage', 'Rollar va ruxsatlar', 'roles', 'Rollar va ruxsatlar matritsasini sozlash'),
('settings.manage', 'Sayt sozlamalari', 'settings', 'Global sayt sozlamalari va Telegram integratsiyasi'),
('audit_logs.view', 'Audit jurnali', 'audit_logs', 'Tizim amallari tarixini ko\'rish');

-- Assign all permissions to SUPER_ADMIN (role_id = 1)
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 1, id FROM `permissions`;

-- Assign permissions to ADMIN (role_id = 2)
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 2, id FROM `permissions` WHERE `name` NOT IN ('roles.manage', 'settings.manage');

-- Assign permissions to EDITOR (role_id = 3)
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 3, id FROM `permissions` WHERE `module` IN ('news', 'categories', 'pages', 'banners', 'gallery', 'media', 'documents');

-- Assign permissions to MODERATOR (role_id = 4)
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 4, id FROM `permissions` WHERE `module` IN ('messages', 'applications', 'vacancies');

-- Users
-- Passwords: admin123, editor123, moderator123
INSERT INTO `users` (`id`, `role_id`, `username`, `email`, `password`, `full_name`, `phone`, `avatar`, `status`, `created_at`) VALUES
(1, 1, 'admin', 'admin@kosonsoykollej.uz', '$2y$10$5/dLjGJDiod6utYgE0GQk.rXjzwNNJkopaXEi0UgZXZU./GSr.lKC', 'Bosh Administrator', '+998 (90) 123-45-67', '/assets/images/avatar-default.png', 'active', NOW()),
(2, 3, 'editor', 'editor@kosonsoykollej.uz', '$2y$10$5/dLjGJDiod6utYgE0GQk.rXjzwNNJkopaXEi0UgZXZU./GSr.lKC', 'Matbuot Kotibi / Muharrir', '+998 (91) 234-56-78', '/assets/images/avatar-default.png', 'active', NOW()),
(3, 4, 'moderator', 'moderator@kosonsoykollej.uz', '$2y$10$5/dLjGJDiod6utYgE0GQk.rXjzwNNJkopaXEi0UgZXZU./GSr.lKC', 'Murojaatlar Bilan Ishlovchi Moderator', '+998 (93) 345-67-89', '/assets/images/avatar-default.png', 'active', NOW());

-- Site Settings
INSERT INTO `site_settings` (`key_name`, `key_value`, `group_name`) VALUES
('site_name', 'Kosonsoy Kolleji', 'general'),
('site_tagline', 'Kasbiy ta\'lim, zamonaviy ko\'nikmalar va porloq kelajak poydevori', 'general'),
('site_phone', '+998 (69) 652-12-34', 'contacts'),
('site_hotline', '1199', 'contacts'),
('site_email', 'info@kosonsoykollej.uz', 'contacts'),
('site_address', 'Namangan viloyati, Kosonsoy tumani, Mustaqillik ko\'chasi, 45-uy', 'contacts'),
('working_hours', 'Dushanba - Shanba: 08:30 - 17:30 (Yakshanba dam olish)', 'contacts'),
('telegram_channel', 'https://t.me/kosonsoy_kolleji', 'social'),
('instagram_url', 'https://instagram.com/kosonsoy_kolleji', 'social'),
('facebook_url', 'https://facebook.com/kosonsoy_kolleji', 'social'),
('youtube_url', 'https://youtube.com/@kosonsoy_kolleji', 'social'),
('telegram_bot_token', '', 'telegram'),
('telegram_chat_id', '', 'telegram'),
('telegram_notifications_enabled', '0', 'telegram'),
('meta_title_default', 'Kosonsoy Kolleji - Rasmiy axborot portali', 'seo'),
('meta_desc_default', 'Kosonsoy kasb-hunar kolleji rasmiy veb-sayti. Yangiliklar, ta\'lim yo\'nalishlari, qabul, statistika va virtual qabulxona.', 'seo'),
('meta_keywords_default', 'Kosonsoy kolleji, kasb-hunar ta\'limi, qabul 2026, yo\'nalishlar, texnikum, kasbiy ta\'lim, Namangan', 'seo'),
('maintenance_mode', '0', 'system'),
('director_quote_uz', 'Bizning bosh maqsadimiz — har bir yoshga zamonaviy kasbiy bilimlarni berish, ularni mehnat bozorida yuqori talabga ega, mustaqil fikrlaydigan raqobatbardosh mutaxassis qilib tarbiyalashdir.', 'homepage'),
('director_quote_ru', 'Наша главная цель — дать каждому молодому человеку современные профессиональные знания, воспитать из них востребованных и конкурентоспособных специалистов.', 'homepage'),
('director_quote_en', 'Our main goal is to provide every young person with modern professional knowledge and train them into highly demanded, competitive specialists in the labor market.', 'homepage'),
('director_name', 'Qodirov Azizbek Karimovich', 'homepage'),
('director_title', 'Kosonsoy Kolleji Direktori, Texnika fanlari bo\'yicha falsafa doktori (PhD)', 'homepage');

-- News Categories
INSERT INTO `news_categories` (`id`, `name_uz`, `name_ru`, `name_en`, `slug`, `description`, `sort_order`, `is_active`) VALUES
(1, 'Kollej yangiliklari', 'Новости колледжа', 'College News', 'kollej-yangiliklari', 'Kollejning ichki hayoti va tadbirlari', 1, 1),
(2, 'E\'lonlar', 'Объявления', 'Announcements', 'elonlar', 'Muhim xabarlar va e\'lonlar', 2, 1),
(3, 'Ta\'lim va innovatsiya', 'Образование и инновации', 'Education & Innovation', 'talim-va-innovatsiya', 'Zamonaviy kasbiy standartlar va amaliyotlar', 3, 1),
(4, 'Ma\'naviyat va sport', 'Духовность и спорт', 'Spirituality & Sport', 'manaviyat-va-sport', 'Sport musobaqalari va ma\'naviy tadbirlar', 4, 1),
(5, 'Xalqaro hamkorlik', 'Международное сотрудничество', 'International Cooperation', 'xalqaro-hamkorlik', 'Chet el ta\'lim muassasalari bilan aloqalar', 5, 1);

-- News Tags
INSERT INTO `news_tags` (`id`, `name_uz`, `name_ru`, `name_en`, `slug`) VALUES
(1, 'Qabul 2026', 'Прием 2026', 'Admission 2026', 'qabul-2026'),
(2, 'IT va Dasturlash', 'ИТ и программирование', 'IT & Programming', 'it-dasturlash'),
(3, 'Amaliyot', 'Практика', 'Internship', 'amaliyot'),
(4, 'Ustaxona', 'Мастерская', 'Workshop', 'ustaxona'),
('5', 'Musobaqa', 'Соревнование', 'Competition', 'musobaqa');

-- News
INSERT INTO `news` (`id`, `category_id`, `author_id`, `title_uz`, `title_ru`, `title_en`, `slug`, `summary_uz`, `summary_ru`, `summary_en`, `content_uz`, `content_ru`, `content_en`, `image`, `views_count`, `is_featured`, `is_announcement`, `status`, `meta_title`, `meta_description`, `published_at`) VALUES
(1, 1, 1, 'Kosonsoy kollejida yangi o\'quv yili uchun zamonaviy robototexnika va IT laboratoriyasi foydalanishga topshirildi',
 'В Косонсойском колледже сдана в эксплуатацию современная лаборатория робототехники и ИТ к новому учебному году',
 'A modern robotics and IT laboratory was commissioned at Kosonsoy College for the new academic year',
 'kosonsoy-kollejida-yangi-oquv-yili-uchun-zamonaviy-robototexnika-va-it-laboratoriyasi',
 'Kollej o\'quvchilarining zamonaviy axborot texnologiyalari va raqamli kasblarni chuqur o\'rganishlari uchun barcha qulayliklarga ega yangi laboratoriya ochildi.',
 'Для глубокого изучения учащимися современных информационных технологий и цифровых профессий открыта новая лаборатория.',
 'A new laboratory with all modern amenities has been opened for students to study cutting-edge information technology and digital professions.',
 '<p>Bugun Kosonsoy kollejida quvonchli voqea sodir bo\'ldi. Ta\'lim muassasamizda yoshlarning zamonaviy dasturlash, sun\'iy intellekt asoslari, 3D modellashtirish va robototexnika yo\'nalishlarida chuqur amaliy bilim olishlarini ta\'minlash maqsadida eng so\'nggi kompyuter uskunalari bilan jihozlangan yangi IT markazi o\'z ishini boshladi.</p><p>Ochilish marosimida tuman hokimligi vakillari, tuman ta\'lim bo\'limi mutasaddilari, nuroniylar hamda korxona rahbarlari ishtirok etdilar. Kollej direktori o\'z nutqida mazkur laboratoriya yoshlarning zamonaviy mehnat bozorida yuqori daromadli kasblarni egallashiga xizmat qilishini ta\'kidladi.</p><p>Laboratoriya 30 dan ortiq eng so\'nggi avlod kompyuterlari, interaktiv sensor panellar, 3D printerlar va robototexnika konstruktorlari bilan to\'liq ta\'minlangan.</p>',
 '<p>Сегодня в Косонсойском колледже состоялось знаменательное событие. В нашем учебном заведении начал работу новый IT-центр, оснащенный новейшим компьютерным оборудованием для углубленного практического обучения молодежи программированию, 3D-моделированию и робототехнике.</p>',
 '<p>Today a joyful event took place at Kosonsoy College. In our educational institution, a brand new IT center equipped with the latest computer hardware was opened to provide students with in-depth practical knowledge in programming, 3D modeling, and robotics.</p>',
 '/assets/images/news-1.jpg', 342, 1, 0, 'published', 'Kollejda yangi IT laboratoriyasi ochildi', 'Kosonsoy kollejida zamonaviy robototexnika va IT markazi ishga tushirildi.', '2026-11-10 09:30:00'),

(2, 2, 1, '2026-2027 o\'quv yili uchun kasbiy ta\'lim yo\'nalishlariga qabul boshlanishi haqida e\'lon',
 'Объявление о начале приема на направления профессионального образования на 2026-2027 учебный год',
 'Announcement on the commencement of admission for vocational education programs for the 2026-2027 academic year',
 '2026-2027-oquv-yili-uchun-kasbiy-talim-yonalishlariga-qabul-boshlanishi-haqida-elon',
 'Kosonsoy kolleji umumiy o\'rta ta\'lim maktablarining 9 va 11-sinf bitiruvchilarini zamonaviy kasblar bo\'yicha tahsil olishga taklif etadi.',
 'Косонсойский колледж приглашает выпускников 9-х и 11-х классов общеобразовательных школ на обучение по современным профессиям.',
 'Kosonsoy College invites 9th and 11th grade graduates of general secondary schools to study in modern vocational professions.',
 '<p>Hurmatli ota-onalar va bitiruvchi yoshlar! Kosonsoy kollejida 2026-2027 o\'quv yili uchun davlat granti va to\'lov-kontrakt asosida qabul jarayonlari boshlanganini ma\'lum qilamiz.</p><h3>Qabul qilinadigan asosiy kasb va yo\'nalishlar:</h3><ul><li>Axborot tizimlari va dasturiy ta\'minot texnigi;</li><li>Avtomobillarga texnik xizmat ko\'rsatish va ta\'mirlash chilangari;</li><li>Tikuvchilik va kiyim dizayneri;</li><li>Payvandlash ishlari texnologi;</li><li>Qishloq xo\'jaligi texnikalarini ekspluatatsiya qilish mutaxassisi;</li><li>Buxgalteriya hisobi va moliya operatori.</li></ul><p>Arizalar kollej binosida joylashgan Qabul komissiyasi orqali hamda rasmiy veb-saytning Virtual qabulxona bo\'limi orqali qabul qilinadi.</p>',
 '<p>Уважаемые родители и выпускники! Сообщаем о начале приема документов в Косонсойский колледж на 2026-2027 учебный год на грантовой и платно-контрактной основе.</p>',
 '<p>Dear parents and graduates! We announce the start of the admission process for the 2026-2027 academic year at Kosonsoy College on state grant and paid-contract basis.</p>',
 '/assets/images/news-2.jpg', 512, 1, 1, 'published', 'Qabul 2026 - Kosonsoy Kolleji', 'Kosonsoy kolleji 2026-2027 o\'quv yili qabul talablari va yo\'nalishlari.', '2026-11-05 14:00:00'),

(3, 3, 2, 'Kollej o\'quvchilari yirik ishlab chiqarish korxonalarida dual ta\'lim amaliyotini o\'tamoqda',
 'Учащиеся колледжа проходят практику по дуальной системе образования на крупных производственных предприятиях',
 'College students are undergoing dual education internships at major manufacturing enterprises',
 'kollej-oquvchilari-yirik-ishlab-chiqarish-korxonalarida-dual-talim-amaliyotini-otamoqda',
 'Kollejimiz o\'quvchilari dars jarayonidan tashqari hududdagi yetakchi korxonalarda haq to\'lanadigan amaliyot o\'tab, professional tajriba orttirmoqdalar.',
 'Наши учащиеся совмещают учебу с оплачиваемой практикой на ведущих региональных предприятиях, приобретая профессиональный опыт.',
 'Our college students combine their studies with paid internships at leading regional enterprises, gaining essential professional experience.',
 '<p>Kosonsoy kollejida ta\'lim va ishlab chiqarish integratsiyasi yangi bosqichga ko\'tarildi. Germaniya va Shveysariya tajribasi asosida yo\'lga qo\'yilgan dual ta\'lim tizimi doirasida 300 nafardan ortiq o\'quvchi hududdagi 15 dan ziyod sanoat va xizmat ko\'rsatish korxonalariga biriktirildi.</p><p>Haftaning uch kuni kollejda nazariy va laboratoriya mashg\'ulotlari o\'tkazilsa, qolgan kunlar bevosita korxonalarning konveyer va ustaxonalarida amaliyot bilan davom etadi. Bu orqali o\'quvchilar bitirgunga qadar kamida 1 yillik real ish tajribasiga ega bo\'ladilar.</p>',
 '<p>Интеграция образования и производства в Косонсойском колледже вышла на качественно новый уровень в рамках дуальной системы обучения.</p>',
 '<p>Integration of education and industry at Kosonsoy College has reached a new height under the dual vocational education model.</p>',
 '/assets/images/news-3.jpg', 228, 0, 0, 'published', 'Dual ta\'lim amaliyoti', 'Kollej o\'quvchilarining korxonalardagi dual ta\'lim amaliyoti.', '2026-10-28 11:15:00'),

(4, 4, 2, 'Kosonsoy kolleji yoshlari o\'rtasida "Zakovat" intellektual turniri va sport spartakiadasi yakunlandi',
 'Среди молодежи Косонсойского колледжа завершились интеллектуальный турнир «Заковат» и спортивная спартакиада',
 'The Zakovat intellectual tournament and sports spartakiad concluded among Kosonsoy College youth',
 'kosonsoy-kolleji-yoshlari-ortasida-zakovat-turniri-va-sport-spartakiadasi',
 'Kollejda sog\'lom turmush tarzini targ\'ib qilish hamda intellektual salohiyatni yuksaltirishga qaratilgan qizg\'in musobaqalar g\'oliblari taqdirlandi.',
 'Награждены победители соревнований, направленных на пропаганду здорового образа жизни и повышение интеллектуального потенциала.',
 'Winners of events aimed at promoting a healthy lifestyle and enhancing intellectual potential were duly rewarded.',
 '<p>O\'tgan haftada kollej ma\'naviyat bo\'limi tomonidan tashkil etilgan an\'anaviy "Kollej kubogi - 2026" doirasida voleybol, mini-futbol, shaxmat-shashka hamda "Zakovat" o\'yinlari o\'tkazildi.</p><p>Musobaqalarda barcha guruhlardan jami 450 dan ortiq o\'quvchi-yoshlar faol ishtirok etdilar. G\'olib bo\'lgan jamoalarga kollej ma\'muriyati tomonidan esdalik sovg\'alari, diplomlar hamda rag\'batlantiruvchi mukofotlar topshirildi.</p>',
 '<p>В рамках традиционного «Кубка колледжа - 2026» прошли турниры по волейболу, мини-футболу, шахматам и интеллектуальной игре «Заковат».',
 '<p>As part of the annual College Cup 2026, volleyball, mini-football, chess, and Zakovat intellectual competitions were organized.',
 '/assets/images/news-4.jpg', 189, 0, 0, 'published', 'Zakovat va Sport spartakiadasi', 'Kollejda sport musobaqalari va intellektual o\'yinlar yakunlandi.', '2026-10-20 16:45:00'),

(5, 5, 1, 'Yevropa kasbiy ta\'lim ekspertlari bilan xalqaro standartlarni joriy etish bo\'yicha seminar o\'tkazildi',
 'С европейскими экспертами профессионального образования проведен семинар по внедрению международных стандартов',
 'A seminar on implementing international standards was conducted with European vocational education experts',
 'yevropa-kasbiy-talim-ekspertlari-bilan-xalqaro-standartlarni-joriy-etish-seminari',
 'Kollej pedagogik jamoasi kasbiy ta\'lim sifatini oshirish va xalqaro baholash mezonlarini o\'quv dasturiga singdirish bo\'yicha malaka oshirdi.',
 'Педагогический коллектив колледжа повысил квалификацию по внедрению международных критериев оценки качества обучения.',
 'The college pedagogical staff improved their skills in embedding international assessment criteria into the educational curriculum.',
 '<p>Kollejimiz xalqaro ta\'lim aloqalarini kengaytirishda davom etmoqda. Germaniya xalqaro hamkorlik jamiyati (GIZ) bilan hamkorlikda tashkil etilgan amaliy seminarda kollej o\'qituvchilari zamonaviy metodikalar bo\'yicha amaliy mashg\'ulotlarda qatnashdilar.</p><p>Seminar davomida o\'quv rejalari, amaliy ko\'nikmalarni baholash hamda WorldSkills standartlarini amaliyotga tadbiq etish yuzasidan kelishuvlarga erishildi.</p>',
 '<p>Наш колледж продолжает расширять международные образовательные связи совместно с обществом международного сотрудничества Германии (GIZ).</p>',
 '<p>Our college continues to expand international educational relations in partnership with the German International Cooperation Society (GIZ).</p>',
 '/assets/images/news-5.jpg', 305, 0, 0, 'published', 'Xalqaro ta\'lim seminari', 'Kollejda xalqaro ekspertlar bilan mahorat darslari o\'tkazildi.', '2026-10-12 10:00:00');

-- Tag relations
INSERT INTO `news_tag_relations` (`news_id`, `tag_id`) VALUES
(1, 2), (1, 4),
(2, 1),
(3, 3), (3, 4),
(4, 5),
(5, 3);

-- Management
INSERT INTO `management` (`id`, `full_name_uz`, `full_name_ru`, `full_name_en`, `position_uz`, `position_ru`, `position_en`, `category`, `bio_uz`, `bio_ru`, `bio_en`, `phone`, `email`, `reception_days_uz`, `reception_days_ru`, `reception_days_en`, `image`, `sort_order`, `is_active`) VALUES
(1, 'Qodirov Azizbek Karimovich', 'Кадыров Азизбек Каримович', 'Qodirov Azizbek Karimovich', 'Kollej Direktori', 'Директор колледжа', 'College Director', 'director', 
 'Texnika fanlari bo\'yicha falsafa doktori (PhD). Ta\'lim sohasida 22 yillik tajribaga ega. 2019-yildan buyon Kosonsoy kolleji direktori lavozimida faoliyat yuritib kelmoqda. Bir qator ilmiy maqolalar va kasbiy ta\'lim darsliklari muallifi.',
 'Доктор философии по техническим наукам (PhD). Опыт работы в сфере образования 22 года. С 2019 года возглавляет Косонсойский колледж.',
 'PhD in Technical Sciences. 22 years of experience in vocational and higher education. Has served as Director of Kosonsoy College since 2019.',
 '+998 (69) 652-12-01', 'direktor@kosonsoykollej.uz', 'Dushanba va Chorshanba: 09:00 - 12:00', 'Понедельник и Среда: 09:00 - 12:00', 'Monday and Wednesday: 09:00 - 12:00',
 '/assets/images/management-1.jpg', 1, 1),

(2, 'Mahmudov Jasur Alisherovich', 'Махмудов Жасур Алишерович', 'Mahmudov Jasur Alisherovich', 'O\'quv ishlari bo\'yicha direktor o\'rinbosari', 'Заместитель директора по учебной работе', 'Deputy Director for Academic Affairs', 'deputy_director',
 'Oliy toifali pedagog. Kasbiy ta\'lim metodikasi bo\'yicha tajribali mutaxassis. Kollej o\'quv jarayonini zamonaviy axborot texnologiyalari va dual tizim asosida muvofiqlashtiradi.',
 'Педагог высшей категории. Опытный специалист в сфере методики профессионального образования.',
 'Senior educator and vocational curriculum specialist. Coordinates academic processes, modern digital learning tools, and dual education programs.',
 '+998 (69) 652-12-02', 'oquv@kosonsoykollej.uz', 'Seshanba va Payshanba: 14:00 - 17:00', 'Вторник и Четверг: 14:00 - 17:00', 'Tuesday and Thursday: 14:00 - 17:00',
 '/assets/images/management-2.jpg', 2, 1),

(3, 'Umarova Dilnoza Saidovna', 'Умарова Дилноза Саидовна', 'Umarova Dilnoza Saidovna', 'Yoshlar bilan ishlash bo\'yicha direktor o\'rinbosari', 'Заместитель директора по работе с молодежью', 'Deputy Director for Youth Affairs', 'deputy_director',
 'Yoshlar tarbiyasi, ma\'naviy-ma\'rifiy tadbirlar va to\'garaklar faoliyatini boshqaradi. Respublika miqyosidagi ko\'plab ko\'rik-tanlovlar g\'oliblari ustozi.',
 'Курирует духовно-просветительскую работу, молодежные инициативы и кружковую деятельность.',
 'Oversees student development, cultural enlightenment events, career clubs, and social welfare programs.',
 '+998 (69) 652-12-03', 'yoshlar@kosonsoykollej.uz', 'Juma va Shanba: 10:00 - 13:00', 'Пятница и Суббота: 10:00 - 13:00', 'Friday and Saturday: 10:00 - 13:00',
 '/assets/images/management-3.jpg', 3, 1),

(4, 'Rustamov Bekzod Xurramovich', 'Рустамов Бекзод Хуррамович', 'Rustamov Bekzod Xurramovich', 'Ishlab chiqarish ta\'limi bo\'yicha direktor o\'rinbosari', 'Заместитель директора по производственному обучению', 'Deputy Director for Practical & Industrial Training', 'deputy_director',
 'Sanoat va kasbiy ta\'lim ustaxonalari mutaxassisi. Korxonalar bilan dual ta\'lim shartnomalarini tuzish, o\'quvchilar amaliyotini tashkil qilish va xavfsizlik texnikasiga mas\'ul.',
 'Специалист по производственному обучению и организации взаимодействия с работодателями.',
 'Expert in industrial workshop management, employer partnerships, student dual internships, and technical safety.',
 '+998 (69) 652-12-04', 'amaliyot@kosonsoykollej.uz', 'Har kuni: 11:00 - 13:00', 'Ежедневно: 11:00 - 13:00', 'Every day: 11:00 - 13:00',
 '/assets/images/management-4.jpg', 4, 1);

-- Employees / Teachers
INSERT INTO `employees` (`id`, `full_name_uz`, `full_name_ru`, `full_name_en`, `department_uz`, `department_ru`, `department_en`, `specialty_uz`, `specialty_ru`, `specialty_en`, `degree_uz`, `degree_ru`, `degree_en`, `phone`, `email`, `image`, `sort_order`, `is_active`) VALUES
(1, 'Soliyev Akmal Bahodirovich', 'Солиев Акмал Баходирович', 'Soliyev Akmal Bahodirovich', 'Axborot texnologiyalari kafedrasi', 'Кафедра информационных технологий', 'IT Department', 'Web dasturlash va tizim boshqaruvi', 'Веб-программирование и системное администрирование', 'Web Development & System Admin', 'Oliy toifali o\'qituvchi', 'Преподаватель высшей категории', 'Senior Instructor', '+998 (90) 555-11-22', 'soliyev@kosonsoykollej.uz', '/assets/images/teacher-1.jpg', 1, 1),
(2, 'Karimova Shahnoza Erkinovna', 'Каримова Шахноза Эркиновна', 'Karimova Shahnoza Erkinovna', 'Yengil sanoat va dizayn kafedrasi', 'Кафедра легкой промышленности и дизайна', 'Light Industry & Design Department', 'Tikuvchilik va modellashtirish', 'Швейное производство и моделирование', 'Sewing & Fashion Design', 'Yetakchi o\'qituvchi', 'Ведущий преподаватель', 'Lead Instructor', '+998 (91) 666-22-33', 'karimova@kosonsoykollej.uz', '/assets/images/teacher-2.jpg', 2, 1),
(3, 'Nematov Otabek Sheraliyevich', 'Нематов Отабек Шералиевич', 'Nematov Otabek Sheraliyevich', 'Muhandislik va mexanika kafedrasi', 'Кафедра инженерии и механики', 'Engineering & Mechanics Department', 'Avtomobillarga texnik xizmat ko\'rsatish', 'Техническое обслуживание автомобилей', 'Automotive Maintenance & Repair', '1-toifali mutaxassis', 'Специалист 1 категории', 'First Category Specialist', '+998 (93) 777-33-44', 'nematov@kosonsoykollej.uz', '/assets/images/teacher-3.jpg', 3, 1),
(4, 'Toshmatov Furqat Alimovich', 'Тошматов Фуркат Алимович', 'Toshmatov Furqat Alimovich', 'Metallga ishlov berish kafedrasi', 'Кафедра металлообработки', 'Metalworking Department', 'Payvandlash ishlari texnologiyasi', 'Технология сварочного производства', 'Welding Technology', 'Oliy toifali ustoz', 'Преподаватель высшей категории', 'Master Instructor', '+998 (94) 888-44-55', 'toshmatov@kosonsoykollej.uz', '/assets/images/teacher-4.jpg', 4, 1),
(5, 'Rasulova Nilufar Tohirovna', 'Расулова Нилуфар Тохировна', 'Rasulova Nilufar Tohirovna', 'Xorijiy tillar kafedrasi', 'Кафедра иностранных языков', 'Foreign Languages Department', 'Amaliy ingliz tili va muloqot madaniyati', 'Практический английский язык', 'Practical English & Communication', 'Magistr', 'Магистр', 'Master of Arts', '+998 (97) 999-55-66', 'rasulova@kosonsoykollej.uz', '/assets/images/teacher-5.jpg', 5, 1);

-- Statistics
INSERT INTO `statistics` (`id`, `title_uz`, `title_ru`, `title_en`, `count_value`, `suffix`, `icon`, `sort_order`, `is_active`) VALUES
(1, 'Jami o\'quvchilar', 'Всего учащихся', 'Total Students', 1250, '+', 'bi-people-fill', 1, 1),
(2, 'Malakali pedagoglar', 'Квалифицированные педагоги', 'Qualified Teachers', 85, '+', 'bi-person-badge-fill', 2, 1),
(3, 'Ta\'lim yo\'nalishlari', 'Направления обучения', 'Vocational Programs', 14, '', 'bi-mortarboard-fill', 3, 1),
(4, 'Bitiruvchilar bandligi', 'Трудоустройство выпускников', 'Graduate Employment', 92, '%', 'bi-briefcase-fill', 4, 1),
(5, 'Hamkor korxonalar', 'Партнерские предприятия', 'Partner Companies', 42, '+', 'bi-buildings-fill', 5, 1),
(6, 'Zamonaviy ustaxonalar', 'Современные мастерские', 'Modern Workshops', 18, '', 'bi-gear-wide-connected', 6, 1);

-- Vacancies
INSERT INTO `vacancies` (`id`, `title_uz`, `title_ru`, `title_en`, `department_uz`, `department_ru`, `department_en`, `employment_type`, `salary_text`, `deadline_date`, `requirements_uz`, `requirements_ru`, `requirements_en`, `responsibilities_uz`, `responsibilities_ru`, `responsibilities_en`, `is_active`) VALUES
(1, 'Axborot xavfsizligi va tarmoq texnologiyalari o\'qituvchisi', 
 'Преподаватель информационной безопасности и сетевых технологий',
 'Teacher of Information Security & Network Technologies',
 'Axborot texnologiyalari kafedrasi', 'Кафедра информационных технологий', 'IT Department',
 'full_time', '4 500 000 - 7 000 000 so\'m', '2026-12-15',
 'Oliy ma\'lumot (Axborot xavfsizligi yoki Dasturiy injiniring yo\'nalishida). Kamida 2 yillik amaliy tajriba. Cisco CCNA yoki shunga tenglashtirilgan sertifikat afzallik beradi.',
 'Высшее профильное образование. Опыт работы от 2 лет. Сертификаты Cisco CCNA приветствуются.',
 'Higher education degree in Cyber Security or Software Engineering. At least 2 years practical experience.',
 'Kollej o\'quvchilariga tarmoq xavfsizligi, kiberxavfsizlik asoslari va serverlarni boshqarish bo\'yicha amaliy darslar o\'tish.',
 'Проведение теоретических и практических занятий по сетевой безопасности и кибербезопасности.',
 'Deliver interactive lecture and hands-on laboratory sessions on network security and cyber defense fundamentals.', 1),

(2, 'Zamonaviy payvandlash texnologiyalari amaliyot ustasi',
 'Мастер производственного обучения по современным сварочным технологиям',
 'Practical Welding Technologies Master Instructor',
 'Metallga ishlov berish kafedrasi', 'Кафедра металлообработки', 'Metalworking Department',
 'full_time', '4 000 000 - 6 500 000 so\'m', '2026-12-20',
 'Kasbiy ta\'lim yoki texnika yo\'nalishida diplom. TIG, MIG/MAG va elektr yoy payvandlash texnikasini mukammal bilish. Mehnat muhofazasi talablariga qat\'iy rioya qilish.',
 'Профильное техническое образование. Отличное владение технологиями TIG, MIG/MAG.',
 'Vocational technical degree. Thorough command of TIG and MIG/MAG welding techniques.',
 'O\'quvchilarga ustaxonada xavfsiz ishlash ko\'nikmalarini o\'rgatish, amaliy mashg\'ulotlarni sifatli o\'tkazish.',
 'Обучение учащихся практическим навыкам сварочных работ в современных мастерских.',
 'Train students on workshop safety standards and hands-on welding fabrication.', 1),

(3, 'Buxgalteriya hisobi va 1C operatori fani o\'qituvchisi',
 'Преподаватель бухгалтерского учета и 1С оператора',
 'Instructor of Accounting and 1C Software',
 'Iqtisodiyot va moliya kafedrasi', 'Кафедра экономики и финансов', 'Economics & Finance Department',
 'part_time', '3 000 000 - 4 500 000 so\'m', '2026-12-10',
 'Iqtisodiy oliy ma\'lumot. 1C dasturini mukammal bilish va soliq hisobotlari bilan ishlash ko\'nikmasi.',
 'Высшее экономическое образование. Отличное знание 1С Бухгалтерии.',
 'Higher degree in Economics/Finance. Comprehensive knowledge of 1C Accounting software.',
 'O\'quvchilarga buxgalteriya hisobining amaliy asoslari va dasturda ishlashni o\'rgatish.',
 'Обучение ведению первичного бухгалтерского учета и работе в программе 1С.',
 'Instruct students on real-world bookkeeping and automated 1C operations.', 1);

-- Virtual Reception Inquiries (Messages)
INSERT INTO `messages` (`id`, `tracking_code`, `full_name`, `phone`, `email`, `address`, `inquiry_type`, `subject`, `message`, `attachment_file`, `status`, `ip_address`, `created_at`) VALUES
(1, 'KK-2026-10492', 'Ergashev Jamshid Farhodovich', '+998 (90) 111-22-33', 'j.ergashev@gmail.com', 'Kosonsoy tumani, Chindovul MFY', 'ariza', 'Kollejga qabul hujjatlari topshirish tartibi to\'g\'risida', 'Assalomu alaykum. Men 9-sinfni tugatgan farzandimni axborot texnologiyalari yo\'nalishiga o\'qishga bermoqchiman. Qabul komissiyasi qaysi sanalarda ishlaydi va qanday hujjatlar talab etiladi?', NULL, 'ANSWERED', '127.0.0.1', '2026-11-12 11:20:00'),
(2, 'KK-2026-20831', 'Rahimova Mohira Odilovna', '+998 (93) 222-33-44', 'mohira.r@mail.ru', 'Kosonsoy tumani, Tergachi MFY', 'taklif', 'Tikuvchilik ustaxonasida yangi dizayn to\'garagini ochish taklifi', 'Hurmatli direktor! Kollejdagi tikuvchilik yo\'nalishida an\'anaviy milliy kashtachilik va zamonaviy liboslar dizayni to\'garagini yo\'lga qo\'yish taklifini bildirmoqchiman.', NULL, 'IN_PROGRESS', '127.0.0.1', '2026-11-14 15:45:00'),
(3, 'KK-2026-30119', 'Narzullayev Sanjarbek', '+998 (94) 333-44-55', 'sanjar.narz@gmail.com', 'Namangan shahri', 'murojaat', 'Dual ta\'lim amaliyot korxonalari ro\'yxati bo\'yicha', 'Assalomu alaykum. Avtomobillarga texnik xizmat ko\'rsatish yo\'nalishi bo\'yicha qaysi korxonalar bilan shartnomalar tuzilganligini bilmoqchi edim.', NULL, 'NEW', '127.0.0.1', '2026-11-16 10:15:00');

-- Message Replies
INSERT INTO `message_replies` (`id`, `message_id`, `replied_by_user_id`, `reply_text`, `reply_file`, `created_at`) VALUES
(1, 1, 1, 'Assalomu alaykum, hurmatli Jamshid Farhodovich! Farzandingizni Kosonsoy kollejida ko\'rishdan mamnunmiz. Qabul komissiyasi dushanbadan shanbagacha soat 08:30 dan 17:30 gacha ishlaydi. Talab etiladigan hujjatlar: 1) Tug\'ilganlik haqidagi guvohnoma yoki pasport nusxasi; 2) 9-sinf shahodatnomasi; 3) 086-U tibbiy ma\'lumotnoma; 4) 3x4 o\'lchamdagi 6 dona rasm. Shuningdek, arizani saytimiz orqali onlayn topshirishingiz ham mumkin.', NULL, '2026-11-12 16:30:00');

-- Banners
INSERT INTO `banners` (`id`, `title_uz`, `title_ru`, `title_en`, `subtitle_uz`, `subtitle_ru`, `subtitle_en`, `image`, `button_text_uz`, `button_text_ru`, `button_text_en`, `button_url`, `sort_order`, `is_active`) VALUES
(1, 'Kosonsoy Kollejiga Xush Kelibsiz!',
 'Добро пожаловать в Косонсойский колледж!',
 'Welcome to Kosonsoy College!',
 'Zamonaviy kasb-hunar sirlari, xalqaro standartlar va yuqori daromadli mutaxassislik sari ishonchli qadam.',
 'Секреты современных профессий, международные стандарты и уверенный шаг к высокооплачиваемой специальности.',
 'Master in-demand vocational skills, international standards, and take a confident step toward a rewarding career.',
 '/assets/images/banner-1.jpg', 'Ta\'lim yo\'nalishlari', 'Направления обучения', 'Vocational Programs', '/#directions', 1, 1),

(2, '2026-2027 O\'quv Yiliga Qabul',
 'Прием на 2026-2027 учебный год',
 'Admissions for 2026-2027 Academic Year',
 'Davlat granti va to\'lov-kontrakt asosida 14 ta nufuzli kasb bo\'yicha o\'qishga taklif etamiz. Onlayn ariza topshiring!',
 'Приглашаем на обучение по 14 востребованным профессиям на грантовой и платной основе. Подайте заявку онлайн!',
 'We invite you to study across 14 prestigious vocational tracks on grant and contract basis. Apply online today!',
 '/assets/images/banner-2.jpg', 'Virtual Qabulxona', 'Виртуальная приемная', 'Virtual Reception', '/reception', 2, 1),

(3, 'Dual Ta\'lim va Kafolatlangan Bandlik',
 'Дуальное образование и гарантия занятости',
 'Dual Vocational Education & Guaranteed Employment',
 'Nazariy ta\'lim bilan birga 40 dan ortiq yirik sanoat korxonalarida haq to\'lanadigan ishlab chiqarish amaliyoti.',
 'Теоретическое обучение в сочетании с оплачиваемой практикой на более чем 40 промышленных предприятиях.',
 'Theoretical classroom knowledge combined with paid practical training at over 40 major industrial enterprises.',
 '/assets/images/banner-3.jpg', 'Biz haqimizda', 'О нас', 'About Us', '/about', 3, 1);

-- Documents
INSERT INTO `documents` (`id`, `title_uz`, `title_ru`, `title_en`, `doc_number`, `doc_date`, `category`, `file_path`, `file_size`, `download_count`, `is_active`) VALUES
(1, 'Kosonsoy kasb-hunar kolleji Davlat Ustavi', 'Государственный устав Косонсойского колледжа', 'State Charter of Kosonsoy College', '№ 12-U', '2024-03-15', 'college_charter', '/uploads/documents/ustav.pdf', '2.4 MB', 142, 1),
(2, 'Ta\'lim faoliyatini yuritish uchun Davlat Litsenziyasi', 'Государственная лицензия на образовательную деятельность', 'State License for Educational Activities', '№ NAS-7841', '2023-09-01', 'license', '/uploads/documents/litsenziya.pdf', '1.1 MB', 289, 1),
(3, 'O\'zbekiston Respublikasining "Kasbiy ta\'lim to\'g\'risida"gi Qonuni', 'Закон Республики Узбекистан «О профессиональном образовании»', 'Law of the Republic of Uzbekistan "On Vocational Education"', '№ ZRU-654', '2020-08-25', 'law', '/uploads/documents/qonun.pdf', '850 KB', 98, 1),
(4, 'Dual ta\'lim tizimini tashkil etish to\'g\'risida Vazirlar Mahkamasi Qarori', 'Постановление Кабинета Министров об организации дуального образования', 'Cabinet of Ministers Resolution on Dual Education', '№ 192', '2021-04-12', 'decree', '/uploads/documents/qaror-192.pdf', '1.6 MB', 115, 1);

-- Partners
INSERT INTO `partners` (`id`, `name`, `logo`, `website_url`, `description_uz`, `description_ru`, `description_en`, `sort_order`, `is_active`) VALUES
(1, 'Artel Electronics', '/assets/images/partner-artel.png', 'https://artelgroup.org', 'Elektronika va maishiy texnika ishlab chiqaruvchi yirik korxona', 'Крупный производитель электроники и бытовой техники', 'Leading electronics and home appliance manufacturer', 1, 1),
(2, 'UzAuto Motors', '/assets/images/partner-uzauto.png', 'https://uzautomotors.com', 'Avtomobilsozlik sanoati yetakchisi', 'Лидер автомобильной промышленности', 'Automotive manufacturing leader', 2, 1),
(3, 'Namangan To\'qimachilik Klasteri', '/assets/images/partner-textile.png', 'https://uztextile.uz', 'Yengil sanoat va to\'qimachilik majmuasi', 'Текстильный кластер Намангана', 'Namangan Textile Cluster', 3, 1),
(4, 'IT Park Namangan', '/assets/images/partner-itpark.png', 'https://it-park.uz', 'Raqamli texnologiyalar va startaplar markazi', 'Филиал IT Park в Намангане', 'IT Park Regional Innovation Hub', 4, 1),
(5, 'Kosonsoy Agro Export', '/assets/images/partner-agro.png', 'https://agro.uz', 'Qishloq xo\'jaligi texnikasi va agrofirma', 'Агропромышленное предприятие', 'Agricultural Engineering & Export', 5, 1);

-- Pages
INSERT INTO `pages` (`id`, `title_uz`, `title_ru`, `title_en`, `slug`, `content_uz`, `content_ru`, `content_en`, `banner_image`, `meta_title`, `meta_description`, `is_active`) VALUES
(1, 'Kollej tarixi va faoliyati', 'История и деятельность колледжа', 'College History and Overview', 'kollej-tarixi', 
 '<h2>Kosonsoy kolleji tarixi</h2><p>Kosonsoy kasb-hunar kolleji hududda malakali o\'rta bo\'g\'in mutaxassislarini tayyorlashda uzoq yillik boy an\'analarga ega bo\'lgan ta\'lim dargohidir. Dastlab hunarmandchilik maktabi sifatida tashkil etilgan muassasa keyinchalik zamonaviy kasb-hunar kollejiga aylantirildi.</p><p>Hozirgi kunda kollejda 14 ta mutaxassislik bo\'yicha mingdan ziyod o\'quvchilar eng zamonaviy o\'quv xonalari va ustaxonalarda saboq olmoqdalar. Ta\'lim muassasasida Germaniyaning dual ta\'lim modeli joriy etilgan bo\'lib, o\'quvchilar nazariy bilimlarni bevosita korxonalarda mustahkamlaydilar.</p><h3>Bizning qadriyatlarimiz:</h3><ul><li>Sifatli va amaliyotga yo\'naltirilgan ta\'lim;</li><li>Mehnat bozorida yuqori talabga ega kasblar;</li><li>Ustoz-shogird an\'anasi;</li><li>Zamonaviy innovatsion texnologiyalar;</li><li>Har bir o\'quvchining shaxsiy va kasbiy yuksalishi.</li></ul>',
 '<h2>История Косонсойского колледжа</h2><p>Косонсойский профессиональный колледж имеет многолетние традиции в подготовке квалифицированных специалистов среднего звена.</p>',
 '<h2>History of Kosonsoy College</h2><p>Kosonsoy Vocational College has a rich tradition of training highly qualified middle-tier technical specialists.</p>',
 '/assets/images/about-banner.jpg', 'Kollej tarixi - Kosonsoy Kolleji', 'Kosonsoy kolleji tarixi, tashkil etilishi va faoliyati haqida batafsil ma\'lumot.', 1);

-- Menus
INSERT INTO `menus` (`id`, `parent_id`, `title_uz`, `title_ru`, `title_en`, `url`, `target`, `location`, `sort_order`, `is_active`) VALUES
(1, NULL, 'Bosh sahifa', 'Главная', 'Home', '/', '_self', 'header', 1, 1),
(2, NULL, 'Biz haqimizda', 'О колледже', 'About Us', '/about', '_self', 'header', 2, 1),
(3, NULL, 'Yangiliklar', 'Новости', 'News', '/news', '_self', 'header', 3, 1),
(4, NULL, 'Rahbariyat', 'Руководство', 'Leadership', '/management', '_self', 'header', 4, 1),
(5, NULL, 'Statistika', 'Статистика', 'Statistics', '/statistics', '_self', 'header', 5, 1),
(6, NULL, 'Vakansiyalar', 'Вакансии', 'Vacancies', '/vacancies', '_self', 'header', 6, 1),
(7, NULL, 'Virtual qabulxona', 'Виртуальная приемная', 'Virtual Reception', '/reception', '_self', 'header', 7, 1),
(8, NULL, 'Rasmiy hujjatlar', 'Официальные документы', 'Official Documents', '/documents', '_self', 'header', 8, 1);

-- Photo Gallery
INSERT INTO `gallery` (`id`, `title_uz`, `title_ru`, `title_en`, `event_date`, `cover_image`, `is_active`) VALUES
(1, 'Zamonaviy ustaxonalar va amaliyot jarayonlari', 'Современные мастерские и учебная практика', 'Modern Workshops & Practical Training', '2026-11-01', '/assets/images/gallery-1.jpg', 1),
(2, 'O\'quvchilar hayoti va sport tadbirlari', 'Студенческая жизнь и спорт', 'Student Life & Sports Activities', '2026-10-25', '/assets/images/gallery-2.jpg', 1),
(3, 'IT laboratoriyasi va robototexnika mashg\'ulotlari', 'ИТ-лаборатория и занятия по робототехнике', 'IT Lab & Robotics Classes', '2026-10-15', '/assets/images/gallery-3.jpg', 1);

INSERT INTO `gallery_images` (`gallery_id`, `image_path`, `caption`, `sort_order`) VALUES
(1, '/assets/images/gallery-1.jpg', 'Ustaxonada metallga ishlov berish jarayoni', 1),
(1, '/assets/images/gallery-1-2.jpg', 'Avtomobil dvigatelini diagnostika qilish amaliyoti', 2),
(2, 'assets/images/gallery-2.jpg', 'Voleybol bo\'yicha kollej kubogi musobaqasi', 1),
(3, '/assets/images/gallery-3.jpg', 'Dasturlash va 3D modellashtirish darsi', 1);

SET FOREIGN_KEY_CHECKS = 1;

