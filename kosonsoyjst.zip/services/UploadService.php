<?php
declare(strict_types=1);

namespace Services;

use Core\Database;
use Core\Auth;
use Exception;

class UploadService
{
    protected static array $allowedImages = [
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'webp' => 'image/webp',
        'gif' => 'image/gif',
        'svg' => 'image/svg+xml'
    ];

    protected static array $allowedDocuments = [
        'pdf' => 'application/pdf',
        'doc' => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xls' => 'application/vnd.ms-excel',
        'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'zip' => 'application/zip'
    ];

    public static function uploadImage(array $file, string $folder = 'news', int $maxSize = 10485760): string
    {
        return self::handleUpload($file, $folder, self::$allowedImages, $maxSize);
    }

    public static function uploadDocument(array $file, string $folder = 'documents', int $maxSize = 20971520): string
    {
        $allowed = array_merge(self::$allowedImages, self::$allowedDocuments);
        return self::handleUpload($file, $folder, $allowed, $maxSize);
    }

    public static function uploadCV(array $file, string $folder = 'cv', int $maxSize = 10485760): string
    {
        $allowed = [
            'pdf' => 'application/pdf',
            'doc' => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ];
        return self::handleUpload($file, $folder, $allowed, $maxSize);
    }

    protected static function handleUpload(array $file, string $folder, array $allowedMap, int $maxSize): string
    {
        if (!isset($file['error']) || is_array($file['error'])) {
            throw new Exception("Noto'g'ri fayl parametri");
        }

        switch ($file['error']) {
            case UPLOAD_ERR_OK:
                break;
            case UPLOAD_ERR_NO_FILE:
                throw new Exception("Hech qanday fayl tanlanmadi");
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                throw new Exception("Fayl hajmi ruxsat etilgan limitdan oshib ketdi");
            default:
                throw new Exception("Faylni yuklashda noma'lum xatolik yuz berdi");
        }

        if ($file['size'] > $maxSize) {
            $mb = round($maxSize / 1048576, 1);
            throw new Exception("Fayl hajmi {$mb} MB dan oshmasligi kerak");
        }

        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        // Check if extension in allowed list
        if (!array_key_exists($extension, $allowedMap)) {
            $allowedExts = implode(', ', array_keys($allowedMap));
            throw new Exception("Faqat quyidagi fayl turlariga ruxsat berilgan: {$allowedExts}");
        }

        // MIME type verification with finfo
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);

            // Allow SVG if finfo returns text/plain or image/svg+xml
            if ($extension === 'svg' && (strpos($mime, 'xml') !== false || strpos($mime, 'svg') !== false || strpos($mime, 'text') !== false)) {
                // SVG acceptable
            } elseif ($extension === 'docx' && (strpos($mime, 'zip') !== false || strpos($mime, 'word') !== false || strpos($mime, 'officedocument') !== false)) {
                // Word docx acceptable
            } elseif ($extension === 'xlsx' && (strpos($mime, 'zip') !== false || strpos($mime, 'excel') !== false || strpos($mime, 'officedocument') !== false)) {
                // Excel docx acceptable
            } elseif (!in_array($mime, $allowedMap, true)) {
                // Fallback check
                if ($mime !== 'application/octet-stream' && $mime !== $allowedMap[$extension]) {
                    throw new Exception("Fayl formati xavfsizlik tekshiruvidan o'tmadi ({$mime})");
                }
            }
        }

        // Target path
        $publicDir = dirname(__DIR__) . '/public/uploads/' . trim($folder, '/');
        if (!is_dir($publicDir)) {
            mkdir($publicDir, 0755, true);
        }

        $newFileName = sprintf('%s_%s.%s', date('Ymd_His'), bin2hex(random_bytes(8)), $extension);
        $destination = $publicDir . '/' . $newFileName;

        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            throw new Exception("Faylni serverga saqlashda xatolik yuz berdi");
        }

        $relativePath = '/uploads/' . trim($folder, '/') . '/' . $newFileName;

        // Optionally record in media table
        try {
            $db = Database::getInstance();
            $db->insert('media', [
                'file_name' => $newFileName,
                'original_name' => substr($file['name'], 0, 255),
                'file_path' => $relativePath,
                'file_type' => $extension,
                'file_size' => (int)$file['size'],
                'user_id' => Auth::id()
            ]);
        } catch (\Throwable $e) {
            // Ignore media table error
        }

        return $relativePath;
    }
}

