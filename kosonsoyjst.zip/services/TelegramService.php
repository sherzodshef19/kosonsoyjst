<?php
declare(strict_types=1);

namespace Services;

use Core\Env;

class TelegramService
{
    public static function send(string $message): bool
    {
        $enabled = (bool)Env::get('TELEGRAM_NOTIFICATIONS', false);
        $token = (string)Env::get('TELEGRAM_BOT_TOKEN', '');
        $chatId = (string)Env::get('TELEGRAM_CHAT_ID', '');

        // If not in env, check database settings
        if (empty($token) || empty($chatId)) {
            $token = setting('telegram_bot_token', '');
            $chatId = setting('telegram_chat_id', '');
            $enabled = (setting('telegram_notifications_enabled', '0') === '1');
        }

        if (!$enabled || empty($token) || empty($chatId)) {
            return false;
        }

        $url = "https://api.telegram.org/bot{$token}/sendMessage";
        $data = [
            'chat_id' => $chatId,
            'text' => $message,
            'parse_mode' => 'HTML',
            'disable_web_page_preview' => true
        ];

        // Non-blocking timeout with curl or stream
        if (function_exists('curl_init')) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 3);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $res = curl_exec($ch);
            curl_close($ch);
            return $res !== false;
        }

        $options = [
            'http' => [
                'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
                'method'  => 'POST',
                'content' => http_build_query($data),
                'timeout' => 3
            ]
        ];
        $context = stream_context_create($options);
        @file_get_contents($url, false, $context);
        return true;
    }

    public static function notifyInquiry(array $inquiry): void
    {
        $code = e($inquiry['tracking_code']);
        $name = e($inquiry['full_name']);
        $phone = e($inquiry['phone']);
        $subject = e($inquiry['subject']);
        $type = strtoupper(e($inquiry['inquiry_type']));
        $time = date('Y-m-d H:i:s');

        $msg = "🏛 <b>Yangi Murojaat [{$type}]</b>\n";
        $msg .= "🆔 <b>Kod:</b> <code>{$code}</code>\n";
        $msg .= "👤 <b>F.I.Sh:</b> {$name}\n";
        $msg .= "📞 <b>Telefon:</b> {$phone}\n";
        $msg .= "📝 <b>Mavzu:</b> {$subject}\n";
        $msg .= "⏱ <b>Vaqt:</b> {$time}\n\n";
        $msg .= "<i>Kosonsoy Kolleji Virtual Qabulxonasi</i>";

        self::send($msg);
    }

    public static function notifyApplication(array $app, string $vacancyTitle): void
    {
        $name = e($app['full_name']);
        $phone = e($app['phone']);
        $email = e($app['email']);
        $title = e($vacancyTitle);
        $time = date('Y-m-d H:i:s');

        $msg = "💼 <b>Yangi Vakansiya Arizasi</b>\n";
        $msg .= "📌 <b>Lavozim:</b> {$title}\n";
        $msg .= "👤 <b>Nomzod:</b> {$name}\n";
        $msg .= "📞 <b>Telefon:</b> {$phone}\n";
        $msg .= "📧 <b>Email:</b> {$email}\n";
        $msg .= "⏱ <b>Vaqt:</b> {$time}\n\n";
        $msg .= "<i>Kosonsoy Kolleji HR Tizimi</i>";

        self::send($msg);
    }
}

