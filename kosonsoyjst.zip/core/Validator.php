<?php
declare(strict_types=1);

namespace Core;

class Validator
{
    protected array $data;
    protected array $rules;
    protected array $errors = [];

    public function __construct(array $data, array $rules)
    {
        $this->data = $data;
        $this->rules = $rules;
        $this->validate();
    }

    public static function make(array $data, array $rules): self
    {
        return new self($data, $rules);
    }

    protected function validate(): void
    {
        foreach ($this->rules as $field => $ruleString) {
            $rules = is_array($ruleString) ? $ruleString : explode('|', $ruleString);
            $value = $this->data[$field] ?? null;

            foreach ($rules as $rule) {
                $params = [];
                if (strpos($rule, ':') !== false) {
                    [$rule, $paramStr] = explode(':', $rule, 2);
                    $params = explode(',', $paramStr);
                }

                $this->applyRule($field, $value, $rule, $params);
            }
        }
    }

    protected function applyRule(string $field, $value, string $rule, array $params): void
    {
        $fieldLabel = ucfirst(str_replace('_', ' ', $field));

        switch ($rule) {
            case 'required':
                if ($value === null || (is_string($value) && trim($value) === '') || (is_array($value) && empty($value))) {
                    $this->addError($field, "{$fieldLabel} maydoni to'ldirilishi shart.");
                }
                break;

            case 'email':
                if (!empty($value) && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $this->addError($field, "To'g'ri elektron pochta manzilini kiriting.");
                }
                break;

            case 'numeric':
                if (!empty($value) && !is_numeric($value)) {
                    $this->addError($field, "{$fieldLabel} faqat raqamlardan iborat bo'lishi kerak.");
                }
                break;

            case 'min':
                $min = (int)($params[0] ?? 0);
                if (is_numeric($value)) {
                    if ((float)$value < $min) {
                        $this->addError($field, "{$fieldLabel} kamida {$min} bo'lishi kerak.");
                    }
                } elseif (is_string($value)) {
                    if (mb_strlen(trim($value)) < $min) {
                        $this->addError($field, "{$fieldLabel} kamida {$min} ta belgidan iborat bo'lishi kerak.");
                    }
                }
                break;

            case 'max':
                $max = (int)($params[0] ?? 255);
                if (is_numeric($value)) {
                    if ((float)$value > $max) {
                        $this->addError($field, "{$fieldLabel} {$max} dan oshmasligi kerak.");
                    }
                } elseif (is_string($value)) {
                    if (mb_strlen(trim($value)) > $max) {
                        $this->addError($field, "{$fieldLabel} {$max} ta belgidan oshmasligi kerak.");
                    }
                }
                break;

            case 'in':
                if (!empty($value) && !in_array($value, $params, true)) {
                    $this->addError($field, "Tanlangan {$fieldLabel} noto'g'ri.");
                }
                break;

            case 'unique':
                $table = $params[0] ?? '';
                $column = $params[1] ?? $field;
                $except = $params[2] ?? null;

                if (!empty($value) && !empty($table)) {
                    $db = Database::getInstance();
                    $sql = "SELECT id FROM `{$table}` WHERE `{$column}` = ?";
                    $binds = [$value];
                    if ($except !== null && $except !== '') {
                        $sql .= " AND id != ?";
                        $binds[] = $except;
                    }
                    $sql .= " LIMIT 1";
                    $existing = $db->first($sql, $binds);
                    if ($existing) {
                        $this->addError($field, "Bu {$fieldLabel} allaqachon mavjud.");
                    }
                }
                break;

            case 'matches':
                $otherField = $params[0] ?? '';
                $otherVal = $this->data[$otherField] ?? null;
                if ($value !== $otherVal) {
                    $this->addError($field, "{$fieldLabel} tasdiqlovchi maydon bilan mos kelmadi.");
                }
                break;
        }
    }

    protected function addError(string $field, string $message): void
    {
        if (!isset($this->errors[$field])) {
            $this->errors[$field] = [];
        }
        $this->errors[$field][] = $message;
    }

    public function fails(): bool
    {
        return !empty($this->errors);
    }

    public function passes(): bool
    {
        return empty($this->errors);
    }

    public function errors(): array
    {
        return $this->errors;
    }

    public function first(?string $field = null): ?string
    {
        if ($field === null) {
            foreach ($this->errors as $errs) {
                return $errs[0] ?? null;
            }
            return null;
        }
        return $this->errors[$field][0] ?? null;
    }
}

