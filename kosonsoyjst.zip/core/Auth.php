<?php
declare(strict_types=1);

namespace Core;

class Auth
{
    protected const SESSION_USER = '_auth_user';
    protected const SESSION_PERMS = '_auth_permissions';

    public static function attempt(string $username, string $password): bool
    {
        $db = Database::getInstance();
        $user = $db->first(
            "SELECT u.*, r.name as role_name, r.display_name as role_display 
             FROM users u 
             JOIN roles r ON r.id = u.role_id 
             WHERE (u.username = ? OR u.email = ?) AND u.status = 'active' 
             LIMIT 1",
            [$username, $username]
        );

        if (!$user) {
            return false;
        }

        if (!password_verify($password, $user['password'])) {
            return false;
        }

        // Login user
        self::login($user);

        // Update last_login_at
        $db->update('users', ['last_login_at' => date('Y-m-d H:i:s')], 'id = ?', [$user['id']]);

        // Audit log
        AuditLog::log((int)$user['id'], 'LOGIN', 'auth', (int)$user['id'], 'Foydalanuvchi tizimga kirdi');

        return true;
    }

    public static function login(array $user): void
    {
        Session::start();
        Session::regenerate();

        // Remove sensitive fields
        unset($user['password'], $user['remember_token']);
        Session::set(self::SESSION_USER, $user);

        // Load permissions
        $db = Database::getInstance();
        $perms = $db->query(
            "SELECT p.name 
             FROM permissions p
             JOIN role_permissions rp ON rp.permission_id = p.id
             WHERE rp.role_id = ?",
            [$user['role_id']]
        );

        $permissionNames = array_column($perms, 'name');
        Session::set(self::SESSION_PERMS, $permissionNames);
    }

    public static function logout(): void
    {
        $userId = self::id();
        if ($userId) {
            AuditLog::log($userId, 'LOGOUT', 'auth', $userId, 'Foydalanuvchi tizimdan chiqdi');
        }

        Session::remove(self::SESSION_USER);
        Session::remove(self::SESSION_PERMS);
        Session::regenerate();
    }

    public static function check(): bool
    {
        return Session::has(self::SESSION_USER);
    }

    public static function guest(): bool
    {
        return !self::check();
    }

    public static function user(): ?array
    {
        return Session::get(self::SESSION_USER);
    }

    public static function id(): ?int
    {
        $user = self::user();
        return $user ? (int)$user['id'] : null;
    }

    public static function role(): ?string
    {
        $user = self::user();
        return $user['role_name'] ?? null;
    }

    public static function hasRole($roles): bool
    {
        $userRole = self::role();
        if (!$userRole) {
            return false;
        }

        // SUPER_ADMIN has access to all roles
        if ($userRole === 'SUPER_ADMIN') {
            return true;
        }

        if (is_array($roles)) {
            return in_array($userRole, $roles, true);
        }

        return $userRole === $roles;
    }

    public static function can(string $permission): bool
    {
        if (self::role() === 'SUPER_ADMIN') {
            return true;
        }

        $perms = Session::get(self::SESSION_PERMS, []);
        return in_array($permission, $perms, true);
    }

    public static function permissions(): array
    {
        return Session::get(self::SESSION_PERMS, []);
    }
}

