<?php
declare(strict_types=1);

namespace Core;

use mysqli;
use mysqli_stmt;
use Exception;

class Database
{
    private static ?Database $instance = null;
    private ?mysqli $connection = null;

    private function __construct()
    {
        $config = require dirname(__DIR__) . '/config/database.php';

        // Connect via mysqli
        $this->connection = new mysqli(
            $config['host'],
            $config['username'],
            $config['password'],
            $config['database'],
            $config['port']
        );

        if ($this->connection->connect_error) {
            $msg = "Database connection failed: " . $this->connection->connect_error;
            error_log($msg);
            throw new Exception($msg);
        }

        $this->connection->set_charset($config['charset']);
    }

    public static function getInstance(): Database
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection(): mysqli
    {
        return $this->connection;
    }

    /**
     * Prepare, bind params, and execute query
     */
    protected function prepareAndExecute(string $sql, array $params = []): mysqli_stmt
    {
        $stmt = $this->connection->prepare($sql);
        if (!$stmt) {
            $err = "Prepare failed: (" . $this->connection->errno . ") " . $this->connection->error . " | SQL: " . $sql;
            error_log($err);
            throw new Exception($err);
        }

        if (!empty($params)) {
            $types = '';
            $bindParams = [];

            foreach ($params as $param) {
                if (is_int($param)) {
                    $types .= 'i';
                } elseif (is_float($param)) {
                    $types .= 'd';
                } elseif (is_null($param)) {
                    $types .= 's'; // MySQL accepts null as string in bind_param
                } else {
                    $types .= 's';
                }
            }

            $bindValues = array_values($params);
            $stmt->bind_param($types, ...$bindValues);
        }

        if (!$stmt->execute()) {
            $err = "Execute failed: (" . $stmt->errno . ") " . $stmt->error . " | SQL: " . $sql;
            error_log($err);
            throw new Exception($err);
        }

        return $stmt;
    }

    /**
     * Fetch all records
     */
    public function query(string $sql, array $params = []): array
    {
        $stmt = $this->prepareAndExecute($sql, $params);
        $result = $stmt->get_result();

        if ($result === false) {
            $stmt->close();
            return [];
        }

        $rows = [];
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }

        $result->free();
        $stmt->close();
        return $rows;
    }

    /**
     * Fetch single record
     */
    public function first(string $sql, array $params = []): ?array
    {
        $rows = $this->query($sql, $params);
        return !empty($rows) ? $rows[0] : null;
    }

    /**
     * Fetch single scalar value
     */
    public function value(string $sql, array $params = [])
    {
        $stmt = $this->prepareAndExecute($sql, $params);
        $result = $stmt->get_result();
        if ($result === false) {
            $stmt->close();
            return null;
        }

        $row = $result->fetch_row();
        $result->free();
        $stmt->close();
        return $row ? $row[0] : null;
    }

    /**
     * Execute write queries (INSERT, UPDATE, DELETE)
     */
    public function execute(string $sql, array $params = []): int
    {
        $stmt = $this->prepareAndExecute($sql, $params);
        $affected = $stmt->affected_rows;
        $insertId = $stmt->insert_id;
        $stmt->close();

        return $insertId > 0 ? (int)$insertId : (int)$affected;
    }

    /**
     * Helper to insert row into table
     */
    public function insert(string $table, array $data): int
    {
        $fields = array_keys($data);
        $placeholders = array_fill(0, count($fields), '?');

        $escapedFields = array_map(function ($f) {
            return "`" . str_replace("`", "``", $f) . "`";
        }, $fields);

        $sql = "INSERT INTO `{$table}` (" . implode(', ', $escapedFields) . ") VALUES (" . implode(', ', $placeholders) . ")";
        $params = array_values($data);

        return $this->execute($sql, $params);
    }

    /**
     * Helper to update row in table
     */
    public function update(string $table, array $data, string $where, array $whereParams = []): int
    {
        $sets = [];
        $params = [];

        foreach ($data as $field => $val) {
            $sets[] = "`" . str_replace("`", "``", $field) . "` = ?";
            $params[] = $val;
        }

        $sql = "UPDATE `{$table}` SET " . implode(', ', $sets) . " WHERE {$where}";
        $params = array_merge($params, $whereParams);

        $stmt = $this->prepareAndExecute($sql, $params);
        $affected = $stmt->affected_rows;
        $stmt->close();
        return (int)$affected;
    }

    /**
     * Helper to delete row from table
     */
    public function delete(string $table, string $where, array $whereParams = []): int
    {
        $sql = "DELETE FROM `{$table}` WHERE {$where}";
        $stmt = $this->prepareAndExecute($sql, $whereParams);
        $affected = $stmt->affected_rows;
        $stmt->close();
        return (int)$affected;
    }

    public function lastInsertId(): int
    {
        return (int)$this->connection->insert_id;
    }

    public function beginTransaction(): bool
    {
        return $this->connection->begin_transaction();
    }

    public function commit(): bool
    {
        return $this->connection->commit();
    }

    public function rollback(): bool
    {
        return $this->connection->rollback();
    }

    public function escape(string $value): string
    {
        return $this->connection->real_escape_string($value);
    }
}

