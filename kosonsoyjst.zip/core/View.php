<?php
declare(strict_types=1);

namespace Core;

class View
{
    protected static array $shared = [];

    public static function share(string $key, $value): void
    {
        self::$shared[$key] = $value;
    }

    public static function render(string $viewPath, array $data = [], ?string $layout = 'layouts/main'): string
    {
        $baseDir = dirname(__DIR__) . '/views/';
        $viewFile = $baseDir . str_replace('.', '/', $viewPath) . '.php';

        if (!file_exists($viewFile)) {
            throw new \Exception("View file not found: {$viewFile}");
        }

        // Merge shared data with view data
        $mergedData = array_merge(self::$shared, $data);
        extract($mergedData, EXTR_SKIP);

        // Capture view content
        ob_start();
        include $viewFile;
        $content = ob_get_clean();

        // If no layout is required, return content
        if ($layout === null || $layout === false || $layout === '') {
            return $content;
        }

        // Render layout
        $layoutFile = $baseDir . str_replace('.', '/', $layout) . '.php';
        if (!file_exists($layoutFile)) {
            return $content;
        }

        ob_start();
        include $layoutFile;
        return ob_get_clean();
    }
}

