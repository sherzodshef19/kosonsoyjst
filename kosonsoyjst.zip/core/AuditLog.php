<?php
declare(strict_types=1);

namespace Core;

class AuditLog
{
    public static function log(?int $userId, string $action, string $module, ?int $recordId = null, ?string $details = null): void
    {
        try {
            $db = Database::getInstance();
            $ip = (new Request())->ip();
            $ua = substr((new Request())->userAgent(), 0, 255);

            $db->insert('audit_logs', [
                'user_id' => $userId,
                'action' => strtoupper($action),
                'module' => $module,
                'record_id' => $recordId,
                'details' => $details,
                'ip_address' => $ip,
                'user_agent' => $ua
            ]);
        } catch (\Throwable $e) {
            error_log("Audit log failed: " . $e->getMessage());
        }
    }
}

