<?php
declare(strict_types=1);

namespace Core;

class App
{
    protected Router $router;
    protected Request $request;

    public function __construct()
    {
        $this->request = new Request();
        $this->router = new Router();
    }

    public static function bootstrap(string $rootDir): self
    {
        // 1. Load environment variables
        Env::load($rootDir . '/.env');

        // 2. Set timezone
        $timezone = Env::get('APP_TIMEZONE', 'Asia/Tashkent');
        date_default_timezone_set($timezone);

        // 3. Error reporting
        $debug = (bool)Env::get('APP_DEBUG', true);
        if ($debug) {
            ini_set('display_errors', '1');
            ini_set('display_startup_errors', '1');
            error_reporting(E_ALL);
        } else {
            ini_set('display_errors', '0');
            error_reporting(0);
        }

        // 4. Session start
        Session::start();

        // 5. Handle Language selection
        $lang = $_GET['lang'] ?? Session::get('locale', 'uz');
        if (!in_array($lang, ['uz', 'ru', 'en'], true)) {
            $lang = 'uz';
        }
        Session::set('locale', $lang);

        // 6. Share global variables with views
        self::shareGlobals($rootDir, $lang);

        $app = new self();
        return $app;
    }

    protected static function shareGlobals(string $rootDir, string $lang): void
    {
        View::share('current_locale', $lang);

        // Load settings from database safely
        try {
            $db = Database::getInstance();
            $settingsRows = $db->query("SELECT key_name, key_value FROM site_settings");
            $settings = [];
            foreach ($settingsRows as $row) {
                $settings[$row['key_name']] = $row['key_value'];
            }
            View::share('site_settings', $settings);

            // Load header menus
            $menus = $db->query(
                "SELECT * FROM menus WHERE is_active = 1 AND location = 'header' ORDER BY sort_order ASC"
            );
            View::share('header_menus', $menus);
        } catch (\Throwable $e) {
            View::share('site_settings', []);
            View::share('header_menus', []);
        }

        // Share current user if logged in
        View::share('auth_user', Auth::user());
    }

    public function getRouter(): Router
    {
        return $this->router;
    }

    public function run(): void
    {
        try {
            $response = $this->router->dispatch($this->request);
            if (is_string($response)) {
                echo $response;
            } elseif (is_array($response)) {
                Response::json($response);
            }
        } catch (\Throwable $e) {
            $debug = (bool)Env::get('APP_DEBUG', true);
            error_log((string)$e);

            if ($this->request->isJson()) {
                Response::json([
                    'success' => false,
                    'error' => $debug ? $e->getMessage() : 'Ichki server xatoligi yuz berdi',
                    'trace' => $debug ? explode("\n", $e->getTraceAsString()) : []
                ], 500);
            }

            Response::setStatusCode(500);
            if ($debug) {
                echo "<div style='font-family:sans-serif;padding:30px;background:#fff5f5;border-left:5px solid #e53e3e;'>";
                echo "<h1 style='color:#c53030;'>Kutilmagan xatolik yuz berdi</h1>";
                echo "<p><strong>Xabar:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
                echo "<p><strong>Fayl:</strong> " . htmlspecialchars($e->getFile()) . " (Qator: " . $e->getLine() . ")</p>";
                echo "<h3>Trace:</h3><pre style='background:#edf2f7;padding:15px;border-radius:4px;overflow:auto;'>" . htmlspecialchars($e->getTraceAsString()) . "</pre>";
                echo "</div>";
            } else {
                echo View::render('errors.500', ['title' => 'Server xatoligi'], 'layouts.main');
            }
            exit;
        }
    }
}
