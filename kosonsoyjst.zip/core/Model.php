<?php
declare(strict_types=1);

namespace Core;

abstract class Model
{
    protected string $table = '';
    protected string $primaryKey = 'id';
    protected bool $hasSoftDelete = false;

    public function getTable(): string
    {
        return $this->table;
    }

    protected function db(): Database
    {
        return Database::getInstance();
    }

    public function find(int $id): ?array
    {
        $sql = "SELECT * FROM `{$this->table}` WHERE `{$this->primaryKey}` = ?";
        if ($this->hasSoftDelete) {
            $sql .= " AND is_deleted = 0";
        }
        $sql .= " LIMIT 1";

        return $this->db()->first($sql, [$id]);
    }

    public function findBy(string $column, $value): ?array
    {
        $sql = "SELECT * FROM `{$this->table}` WHERE `{$column}` = ?";
        if ($this->hasSoftDelete) {
            $sql .= " AND is_deleted = 0";
        }
        $sql .= " LIMIT 1";

        return $this->db()->first($sql, [$value]);
    }

    public function all(string $orderBy = 'id DESC'): array
    {
        $sql = "SELECT * FROM `{$this->table}`";
        if ($this->hasSoftDelete) {
            $sql .= " WHERE is_deleted = 0";
        }
        $sql .= " ORDER BY {$orderBy}";

        return $this->db()->query($sql);
    }

    public function where(string $conditions, array $params = [], string $orderBy = 'id DESC', ?int $limit = null, ?int $offset = null): array
    {
        $sql = "SELECT * FROM `{$this->table}` WHERE {$conditions}";
        if ($this->hasSoftDelete && strpos($conditions, 'is_deleted') === false) {
            $sql .= " AND is_deleted = 0";
        }
        $sql .= " ORDER BY {$orderBy}";

        if ($limit !== null) {
            $sql .= " LIMIT " . (int)$limit;
            if ($offset !== null) {
                $sql .= " OFFSET " . (int)$offset;
            }
        }

        return $this->db()->query($sql, $params);
    }

    public function create(array $data): int
    {
        return $this->db()->insert($this->table, $data);
    }

    public function update(int $id, array $data): int
    {
        return $this->db()->update($this->table, $data, "`{$this->primaryKey}` = ?", [$id]);
    }

    public function delete(int $id): int
    {
        if ($this->hasSoftDelete) {
            return $this->softDelete($id);
        }
        return $this->db()->delete($this->table, "`{$this->primaryKey}` = ?", [$id]);
    }

    public function softDelete(int $id): int
    {
        return $this->db()->update($this->table, ['is_deleted' => 1], "`{$this->primaryKey}` = ?", [$id]);
    }

    public function restore(int $id): int
    {
        return $this->db()->update($this->table, ['is_deleted' => 0], "`{$this->primaryKey}` = ?", [$id]);
    }

    public function count(string $where = '', array $params = []): int
    {
        $sql = "SELECT COUNT(*) FROM `{$this->table}`";
        $conditions = [];
        if ($this->hasSoftDelete && strpos($where, 'is_deleted') === false) {
            $conditions[] = "is_deleted = 0";
        }
        if (!empty($where)) {
            $conditions[] = "({$where})";
        }
        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(' AND ', $conditions);
        }

        return (int)$this->db()->value($sql, $params);
    }

    public function paginate(int $page = 1, int $perPage = 10, string $where = '', array $params = [], string $orderBy = 'id DESC'): array
    {
        $page = max(1, $page);
        $total = $this->count($where, $params);
        $totalPages = (int)ceil($total / $perPage);
        $offset = ($page - 1) * $perPage;

        $conditions = [];
        if ($this->hasSoftDelete && strpos($where, 'is_deleted') === false) {
            $conditions[] = "is_deleted = 0";
        }
        if (!empty($where)) {
            $conditions[] = "({$where})";
        }
        $whereSql = !empty($conditions) ? " WHERE " . implode(' AND ', $conditions) : "";

        $sql = "SELECT * FROM `{$this->table}`{$whereSql} ORDER BY {$orderBy} LIMIT {$perPage} OFFSET {$offset}";
        $items = $this->db()->query($sql, $params);

        return [
            'data' => $items,
            'current_page' => $page,
            'per_page' => $perPage,
            'total' => $total,
            'total_pages' => $totalPages,
            'has_prev' => $page > 1,
            'has_next' => $page < $totalPages
        ];
    }
}

