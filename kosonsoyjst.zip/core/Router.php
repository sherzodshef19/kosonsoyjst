<?php
declare(strict_types=1);

namespace Core;

class Router
{
    protected array $routes = [];
    protected array $groupStack = [];
    protected $notFoundHandler = null;

    public function get(string $path, $handler, array $middleware = []): self
    {
        return $this->addRoute('GET', $path, $handler, $middleware);
    }

    public function post(string $path, $handler, array $middleware = []): self
    {
        return $this->addRoute('POST', $path, $handler, $middleware);
    }

    public function put(string $path, $handler, array $middleware = []): self
    {
        return $this->addRoute('PUT', $path, $handler, $middleware);
    }

    public function delete(string $path, $handler, array $middleware = []): self
    {
        return $this->addRoute('DELETE', $path, $handler, $middleware);
    }

    public function any(string $path, $handler, array $middleware = []): self
    {
        foreach (['GET', 'POST', 'PUT', 'DELETE'] as $method) {
            $this->addRoute($method, $path, $handler, $middleware);
        }
        return $this;
    }

    public function group(array $attributes, callable $callback): void
    {
        $this->groupStack[] = $attributes;
        call_user_func($callback, $this);
        array_pop($this->groupStack);
    }

    protected function addRoute(string $method, string $path, $handler, array $middleware = []): self
    {
        $prefix = '';
        $groupMiddleware = [];

        foreach ($this->groupStack as $group) {
            if (isset($group['prefix'])) {
                $prefix .= '/' . trim($group['prefix'], '/');
            }
            if (isset($group['middleware'])) {
                $groupMiddleware = array_merge($groupMiddleware, (array)$group['middleware']);
            }
        }

        $fullPath = '/' . trim($prefix . '/' . trim($path, '/'), '/');
        if ($fullPath === '') {
            $fullPath = '/';
        }

        // Convert route pattern with {param} to regex
        $pattern = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '(?P<$1>[^/]+)', $fullPath);
        $regex = '#^' . $pattern . '$#';

        $this->routes[] = [
            'method' => strtoupper($method),
            'path' => $fullPath,
            'regex' => $regex,
            'handler' => $handler,
            'middleware' => array_merge($groupMiddleware, $middleware)
        ];

        return $this;
    }

    public function setNotFoundHandler(callable $handler): void
    {
        $this->notFoundHandler = $handler;
    }

    public function dispatch(Request $request)
    {
        $method = $request->method();
        $uri = $request->uri();

        foreach ($this->routes as $route) {
            if ($route['method'] !== $method) {
                continue;
            }

            if (preg_match($route['regex'], $uri, $matches)) {
                // Extract named params
                $params = [];
                foreach ($matches as $k => $v) {
                    if (is_string($k)) {
                        $params[$k] = urldecode($v);
                    }
                }

                // Run middlewares
                foreach ($route['middleware'] as $mw) {
                    $mwResult = $this->resolveMiddleware($mw, $request);
                    if ($mwResult !== null) {
                        return $mwResult;
                    }
                }

                return $this->executeHandler($route['handler'], $params, $request);
            }
        }

        // 404 Not Found
        if ($this->notFoundHandler !== null) {
            return call_user_func($this->notFoundHandler, $request);
        }

        if ($request->isJson()) {
            Response::json(['success' => false, 'error' => 'Endpoint not found'], 404);
        }

        Response::setStatusCode(404);
        echo View::render('errors.404', ['title' => 'Sahifa topilmadi'], 'layouts.main');
        exit;
    }

    protected function resolveMiddleware($middleware, Request $request)
    {
        if (is_string($middleware)) {
            $parts = explode(':', $middleware, 2);
            $name = $parts[0];
            $arg = $parts[1] ?? null;

            switch ($name) {
                case 'auth':
                    if (Auth::guest()) {
                        if ($request->isJson()) {
                            Response::json(['success' => false, 'error' => 'Avtorizatsiyadan o\'tilmagan'], 401);
                        }
                        Session::flash('error', 'Iltimos, avval tizimga kiring.');
                        Response::redirect('/admin/login');
                    }
                    break;

                case 'role':
                    $allowedRoles = explode(',', (string)$arg);
                    if (!Auth::hasRole($allowedRoles)) {
                        if ($request->isJson()) {
                            Response::json(['success' => false, 'error' => 'Ushbu amal uchun ruxsat yo\'q'], 403);
                        }
                        Response::setStatusCode(403);
                        echo View::render('errors.403', ['title' => 'Ruxsat etilmagan'], 'layouts.admin');
                        exit;
                    }
                    break;

                case 'can':
                    if (!Auth::can((string)$arg)) {
                        if ($request->isJson()) {
                            Response::json(['success' => false, 'error' => 'Sizda ushbu amalga ruxsat yo\'q'], 403);
                        }
                        Response::setStatusCode(403);
                        echo View::render('errors.403', ['title' => 'Ruxsat etilmagan'], 'layouts.admin');
                        exit;
                    }
                    break;

                case 'csrf':
                    if (in_array($request->method(), ['POST', 'PUT', 'DELETE'], true)) {
                        $token = $request->input('csrf_token') ?? $request->header('X-CSRF-Token');
                        if (!CSRF::validate($token)) {
                            if ($request->isJson()) {
                                Response::json(['success' => false, 'error' => 'CSRF xavfsizlik tokeni eskirgan yoki xato'], 419);
                            }
                            Session::flash('error', 'Xavfsizlik sessiyasi eskirgan. Iltimos qaytadan urinib ko\'ring.');
                            Response::back();
                        }
                    }
                    break;
            }
        } elseif (is_callable($middleware)) {
            return call_user_func($middleware, $request);
        }

        return null;
    }

    protected function executeHandler($handler, array $params, Request $request)
    {
        if (is_array($handler) && count($handler) === 2) {
            [$class, $method] = $handler;
            if (is_string($class)) {
                $instance = new $class();
            } else {
                $instance = $class;
            }

            if (!method_exists($instance, $method)) {
                throw new \Exception("Method {$method} does not exist on controller " . get_class($instance));
            }

            return call_user_func_array([$instance, $method], array_values($params));
        }

        if (is_callable($handler)) {
            return call_user_func_array($handler, array_values($params));
        }

        throw new \Exception("Invalid route handler provided");
    }
}
