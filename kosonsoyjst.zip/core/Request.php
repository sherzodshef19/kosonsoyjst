<?php
declare(strict_types=1);

namespace Core;

class Request
{
    protected array $query;
    protected array $body;
    protected array $files;
    protected array $server;
    protected ?array $json = null;

    public function __construct()
    {
        $this->query = $_GET;
        $this->body = $_POST;
        $this->files = $_FILES;
        $this->server = $_SERVER;

        // Parse JSON body if Content-Type is application/json
        $contentType = $this->header('Content-Type', '');
        if (strpos($contentType, 'application/json') !== false) {
            $raw = file_get_contents('php://input');
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                $this->json = $decoded;
            }
        }
    }

    public function method(): string
    {
        $method = strtoupper($this->server['REQUEST_METHOD'] ?? 'GET');
        if ($method === 'POST') {
            $override = $this->body['_method'] ?? $this->header('X-HTTP-Method-Override', '');
            if (!empty($override)) {
                $override = strtoupper(trim((string)$override));
                if (in_array($override, ['PUT', 'PATCH', 'DELETE'], true)) {
                    return $override;
                }
            }
        }
        return $method;
    }

    public function isGet(): bool { return $this->method() === 'GET'; }
    public function isPost(): bool { return $this->method() === 'POST'; }
    public function isPut(): bool { return $this->method() === 'PUT'; }
    public function isDelete(): bool { return $this->method() === 'DELETE'; }

    public function uri(): string
    {
        $uri = $this->server['REQUEST_URI'] ?? '/';
        $position = strpos($uri, '?');
        if ($position !== false) {
            $uri = substr($uri, 0, $position);
        }
        return '/' . trim($uri, '/');
    }

    public function all(): array
    {
        $merged = array_merge($this->query, $this->body);
        if ($this->json !== null) {
            $merged = array_merge($merged, $this->json);
        }
        return $merged;
    }

    public function input(string $key, $default = null)
    {
        if ($this->json !== null && array_key_exists($key, $this->json)) {
            return $this->json[$key];
        }
        if (array_key_exists($key, $this->body)) {
            return $this->body[$key];
        }
        if (array_key_exists($key, $this->query)) {
            return $this->query[$key];
        }
        return $default;
    }

    public function get(string $key, $default = null)
    {
        return $this->query[$key] ?? $default;
    }

    public function post(string $key, $default = null)
    {
        return $this->body[$key] ?? $default;
    }

    public function json(?string $key = null, $default = null)
    {
        if ($this->json === null) {
            return $default;
        }
        if ($key === null) {
            return $this->json;
        }
        return $this->json[$key] ?? $default;
    }

    public function file(string $key): ?array
    {
        if (!isset($this->files[$key]) || empty($this->files[$key]['name'])) {
            return null;
        }
        return $this->files[$key];
    }

    public function hasFile(string $key): bool
    {
        return isset($this->files[$key]) &&
            !empty($this->files[$key]['name']) &&
            $this->files[$key]['error'] === UPLOAD_ERR_OK;
    }

    public function header(string $name, $default = null)
    {
        $normalized = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
        if (isset($this->server[$normalized])) {
            return $this->server[$normalized];
        }

        // Direct headers fallback
        if (function_exists('getallheaders')) {
            $headers = getallheaders();
            foreach ($headers as $k => $v) {
                if (strcasecmp($k, $name) === 0) {
                    return $v;
                }
            }
        }

        return $default;
    }

    public function isAjax(): bool
    {
        return strtolower((string)$this->header('X-Requested-With', '')) === 'xmlhttprequest';
    }

    public function isJson(): bool
    {
        $accept = (string)$this->header('Accept', '');
        return strpos($accept, 'application/json') !== false || $this->isAjax();
    }

    public function ip(): string
    {
        return $this->server['HTTP_CF_CONNECTING_IP']
            ?? $this->server['HTTP_X_FORWARDED_FOR']
            ?? $this->server['REMOTE_ADDR']
            ?? '127.0.0.1';
    }

    public function userAgent(): string
    {
        return $this->server['HTTP_USER_AGENT'] ?? 'Unknown';
    }
}

