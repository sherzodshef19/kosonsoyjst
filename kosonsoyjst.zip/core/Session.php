<?php
declare(strict_types=1);

namespace Core;

class Session
{
    protected static bool $started = false;

    public static function start(): void
    {
        if (self::$started || session_status() === PHP_SESSION_ACTIVE) {
            self::$started = true;
            return;
        }

        $lifetime = (int)Env::get('SESSION_LIFETIME', 7200);

        ini_set('session.use_only_cookies', '1');
        ini_set('session.use_strict_mode', '1');
        ini_set('session.cookie_httponly', '1');

        session_set_cookie_params([
            'lifetime' => $lifetime,
            'path' => '/',
            'domain' => '',
            'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
            'httponly' => true,
            'samesite' => 'Lax'
        ]);

        session_start();
        self::$started = true;

        // Manage flash messages lifetime
        if (!isset($_SESSION['_flash_old'])) {
            $_SESSION['_flash_old'] = [];
        }
        if (!isset($_SESSION['_flash_new'])) {
            $_SESSION['_flash_new'] = [];
        }

        // Move new flash messages to old, clear aged ones
        foreach ($_SESSION['_flash_old'] as $key) {
            unset($_SESSION['_flash'][$key]);
        }
        $_SESSION['_flash_old'] = $_SESSION['_flash_new'];
        $_SESSION['_flash_new'] = [];
    }

    public static function set(string $key, $value): void
    {
        self::start();
        $_SESSION[$key] = $value;
    }

    public static function get(string $key, $default = null)
    {
        self::start();
        return $_SESSION[$key] ?? $default;
    }

    public static function has(string $key): bool
    {
        self::start();
        return isset($_SESSION[$key]);
    }

    public static function remove(string $key): void
    {
        self::start();
        unset($_SESSION[$key]);
    }

    public static function flash(string $key, $value = null)
    {
        self::start();
        if ($value === null) {
            return self::getFlash($key);
        }

        $_SESSION['_flash'][$key] = $value;
        $_SESSION['_flash_new'][] = $key;
    }

    public static function getFlash(string $key, $default = null)
    {
        self::start();
        return $_SESSION['_flash'][$key] ?? $default;
    }

    public static function hasFlash(string $key): bool
    {
        self::start();
        return isset($_SESSION['_flash'][$key]);
    }

    public static function regenerate(): bool
    {
        self::start();
        return session_regenerate_id(true);
    }

    public static function destroy(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            $_SESSION = [];
            if (ini_get("session.use_cookies")) {
                $params = session_get_cookie_params();
                setcookie(
                    session_name(),
                    '',
                    time() - 42000,
                    $params["path"],
                    $params["domain"],
                    $params["secure"],
                    $params["httponly"]
                );
            }
            session_destroy();
            self::$started = false;
        }
    }
}

