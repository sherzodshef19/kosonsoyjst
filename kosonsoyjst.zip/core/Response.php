<?php
declare(strict_types=1);

namespace Core;

class Response
{
    public static function setStatusCode(int $code): void
    {
        http_response_code($code);
    }

    public static function setHeader(string $name, string $value): void
    {
        header(sprintf('%s: %s', $name, $value));
    }

    public static function json(array $data, int $statusCode = 200): void
    {
        self::setStatusCode($statusCode);
        self::setHeader('Content-Type', 'application/json; charset=UTF-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    public static function redirect(string $url, int $statusCode = 302): void
    {
        self::setStatusCode($statusCode);
        self::setHeader('Location', $url);
        exit;
    }

    public static function back(): void
    {
        $referer = $_SERVER['HTTP_REFERER'] ?? '/';
        self::redirect($referer);
    }

    public static function download(string $filePath, ?string $fileName = null): void
    {
        if (!file_exists($filePath)) {
            self::setStatusCode(404);
            echo "File not found";
            exit;
        }

        $fileName = $fileName ?? basename($filePath);
        $fileSize = filesize($filePath);

        self::setHeader('Content-Description', 'File Transfer');
        self::setHeader('Content-Type', 'application/octet-stream');
        self::setHeader('Content-Disposition', 'attachment; filename="' . addslashes($fileName) . '"');
        self::setHeader('Expires', '0');
        self::setHeader('Cache-Control', 'must-revalidate');
        self::setHeader('Pragma', 'public');
        self::setHeader('Content-Length', (string)$fileSize);

        readfile($filePath);
        exit;
    }
}

