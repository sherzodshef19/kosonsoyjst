<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Setting extends Model
{
    protected string $table = 'site_settings';

    public function allAssoc(): array
    {
        $rows = $this->all('id ASC');
        $assoc = [];
        foreach ($rows as $r) {
            $assoc[$r['key_name']] = $r['key_value'];
        }
        return $assoc;
    }

    public function set(string $key, $value, string $group = 'general'): void
    {
        $existing = $this->db()->first("SELECT id FROM site_settings WHERE key_name = ?", [$key]);
        if ($existing) {
            $this->db()->update('site_settings', ['key_value' => (string)$value], 'id = ?', [$existing['id']]);
        } else {
            $this->db()->insert('site_settings', [
                'key_name' => $key,
                'key_value' => (string)$value,
                'group_name' => $group
            ]);
        }
    }
}

