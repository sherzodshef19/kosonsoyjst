<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Permission extends Model
{
    protected string $table = 'permissions';

    public function groupedByModule(): array
    {
        $all = $this->all('module ASC, id ASC');
        $grouped = [];
        foreach ($all as $item) {
            $grouped[$item['module']][] = $item;
        }
        return $grouped;
    }
}

