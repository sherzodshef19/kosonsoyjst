<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class AuditLogModel extends Model
{
    protected string $table = 'audit_logs';

    public function paginateLogs(int $page = 1, int $perPage = 15): array
    {
        $page = max(1, $page);
        $total = $this->count();
        $totalPages = (int)ceil($total / $perPage);
        $offset = ($page - 1) * $perPage;

        $sql = "SELECT a.*, u.username, u.full_name 
                FROM audit_logs a 
                LEFT JOIN users u ON u.id = a.user_id 
                ORDER BY a.id DESC 
                LIMIT {$perPage} OFFSET {$offset}";

        $items = $this->db()->query($sql);

        return [
            'data' => $items,
            'current_page' => $page,
            'per_page' => $perPage,
            'total' => $total,
            'total_pages' => $totalPages,
            'has_prev' => $page > 1,
            'has_next' => $page < $totalPages
        ];
    }
}

