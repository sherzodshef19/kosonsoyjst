<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Category extends Model
{
    protected string $table = 'news_categories';

    public function allWithCount(): array
    {
        $sql = "SELECT c.*, COUNT(n.id) as news_count 
                FROM news_categories c 
                LEFT JOIN news n ON n.category_id = c.id AND n.status = 'published' AND n.is_deleted = 0 
                WHERE c.is_active = 1 
                GROUP BY c.id 
                ORDER BY c.sort_order ASC";
        return $this->db()->query($sql);
    }
}

