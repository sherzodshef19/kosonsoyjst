<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Statistic extends Model
{
    protected string $table = 'statistics';

    public function allActive(): array
    {
        return $this->db()->query(
            "SELECT * FROM `statistics` WHERE is_active = 1 ORDER BY sort_order ASC, id ASC"
        );
    }
}

