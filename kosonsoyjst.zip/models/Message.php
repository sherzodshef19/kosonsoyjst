<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Message extends Model
{
    protected string $table = 'messages';
    protected bool $hasSoftDelete = true;

    public static function generateTrackingCode(): string
    {
        $year = date('Y');
        $random = mt_rand(10000, 99999);
        return "KK-{$year}-{$random}";
    }

    public function findByTrackingCode(string $code): ?array
    {
        $sql = "SELECT * FROM `messages` WHERE `tracking_code` = ? AND is_deleted = 0 LIMIT 1";
        $msg = $this->db()->first($sql, [trim($code)]);
        if (!$msg) {
            return null;
        }

        // Fetch replies
        $repliesSql = "SELECT r.*, u.full_name as replied_by_name 
                       FROM message_replies r 
                       LEFT JOIN users u ON u.id = r.replied_by_user_id 
                       WHERE r.message_id = ? 
                       ORDER BY r.created_at ASC";
        $msg['replies'] = $this->db()->query($repliesSql, [$msg['id']]);

        return $msg;
    }

    public function addReply(int $messageId, int $userId, string $replyText, ?string $replyFile = null): int
    {
        $insertId = $this->db()->insert('message_replies', [
            'message_id' => $messageId,
            'replied_by_user_id' => $userId,
            'reply_text' => $replyText,
            'reply_file' => $replyFile,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        // Automatically update message status to ANSWERED
        $this->update($messageId, ['status' => 'ANSWERED']);

        return $insertId;
    }
}

