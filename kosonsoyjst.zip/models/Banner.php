<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Banner extends Model
{
    protected string $table = 'banners';

    public function allActive(): array
    {
        return $this->db()->query(
            "SELECT * FROM banners WHERE is_active = 1 ORDER BY sort_order ASC, id ASC"
        );
    }
}

