<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Gallery extends Model
{
    protected string $table = 'gallery';
    protected bool $hasSoftDelete = true;

    public function allWithImages(): array
    {
        $albums = $this->where('is_active = 1', [], 'event_date DESC, id DESC');
        foreach ($albums as &$album) {
            $album['images'] = $this->db()->query(
                "SELECT * FROM gallery_images WHERE gallery_id = ? ORDER BY sort_order ASC, id ASC",
                [$album['id']]
            );
        }
        return $albums;
    }

    public function addImage(int $galleryId, string $imagePath, ?string $caption = null, int $sort = 0): int
    {
        return $this->db()->insert('gallery_images', [
            'gallery_id' => $galleryId,
            'image_path' => $imagePath,
            'caption' => $caption,
            'sort_order' => $sort
        ]);
    }

    public function deleteImage(int $imageId): int
    {
        return $this->db()->delete('gallery_images', 'id = ?', [$imageId]);
    }
}

