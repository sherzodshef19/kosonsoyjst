<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Document extends Model
{
    protected string $table = 'documents';
    protected bool $hasSoftDelete = true;

    public function allActive(?string $category = null): array
    {
        $where = "is_active = 1 AND is_deleted = 0";
        $params = [];

        if (!empty($category)) {
            $where .= " AND category = ?";
            $params[] = $category;
        }

        return $this->db()->query(
            "SELECT * FROM documents WHERE {$where} ORDER BY doc_date DESC, id DESC",
            $params
        );
    }

    public function incrementDownloads(int $id): void
    {
        $this->db()->execute("UPDATE documents SET download_count = download_count + 1 WHERE id = ?", [$id]);
    }
}

