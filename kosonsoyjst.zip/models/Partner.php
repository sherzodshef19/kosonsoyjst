<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Partner extends Model
{
    protected string $table = 'partners';

    public function allActive(): array
    {
        return $this->db()->query("SELECT * FROM partners WHERE is_active = 1 ORDER BY sort_order ASC, id ASC");
    }
}

