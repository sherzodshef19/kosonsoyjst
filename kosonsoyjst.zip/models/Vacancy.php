<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Vacancy extends Model
{
    protected string $table = 'vacancies';
    protected bool $hasSoftDelete = true;

    public function allActive(): array
    {
        return $this->db()->query(
            "SELECT v.*, COUNT(a.id) as applications_count 
             FROM vacancies v 
             LEFT JOIN vacancy_applications a ON a.vacancy_id = v.id AND a.is_deleted = 0 
             WHERE v.is_active = 1 AND v.is_deleted = 0 
             GROUP BY v.id 
             ORDER BY v.id DESC"
        );
    }
}

