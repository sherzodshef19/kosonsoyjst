<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Page extends Model
{
    protected string $table = 'pages';
    protected bool $hasSoftDelete = true;

    public function findBySlug(string $slug): ?array
    {
        return $this->db()->first(
            "SELECT * FROM pages WHERE slug = ? AND is_active = 1 AND is_deleted = 0 LIMIT 1",
            [$slug]
        );
    }
}

