<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Role extends Model
{
    protected string $table = 'roles';

    public function permissions(int $roleId): array
    {
        $sql = "SELECT p.* FROM permissions p 
                JOIN role_permissions rp ON rp.permission_id = p.id 
                WHERE rp.role_id = ? 
                ORDER BY p.module ASC, p.id ASC";
        return $this->db()->query($sql, [$roleId]);
    }

    public function syncPermissions(int $roleId, array $permissionIds): void
    {
        $this->db()->delete('role_permissions', 'role_id = ?', [$roleId]);
        foreach ($permissionIds as $pId) {
            $this->db()->insert('role_permissions', [
                'role_id' => $roleId,
                'permission_id' => (int)$pId
            ]);
        }
    }
}

