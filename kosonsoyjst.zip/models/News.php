<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class News extends Model
{
    protected string $table = 'news';
    protected bool $hasSoftDelete = true;

    public function findBySlug(string $slug): ?array
    {
        $sql = "SELECT n.*, c.name_uz as cat_name_uz, c.name_ru as cat_name_ru, c.name_en as cat_name_en, c.slug as cat_slug, u.full_name as author_name 
                FROM news n 
                LEFT JOIN news_categories c ON c.id = n.category_id 
                LEFT JOIN users u ON u.id = n.author_id 
                WHERE n.slug = ? AND n.is_deleted = 0 
                LIMIT 1";
        return $this->db()->first($sql, [$slug]);
    }

    public function incrementViews(int $id): void
    {
        $this->db()->execute("UPDATE news SET views_count = views_count + 1 WHERE id = ?", [$id]);
    }

    public function getGallery(int $newsId): array
    {
        return $this->db()->query("SELECT * FROM news_gallery WHERE news_id = ? ORDER BY sort_order ASC, id ASC", [$newsId]);
    }

    public function getTags(int $newsId): array
    {
        $sql = "SELECT t.* FROM news_tags t 
                JOIN news_tag_relations r ON r.tag_id = t.id 
                WHERE r.news_id = ?";
        return $this->db()->query($sql, [$newsId]);
    }

    public function syncTags(int $newsId, array $tagIds): void
    {
        $this->db()->delete('news_tag_relations', 'news_id = ?', [$newsId]);
        foreach ($tagIds as $tid) {
            if ((int)$tid > 0) {
                $this->db()->insert('news_tag_relations', [
                    'news_id' => $newsId,
                    'tag_id' => (int)$tid
                ]);
            }
        }
    }

    public function saveGalleryImages(int $newsId, array $imagePaths): void
    {
        foreach ($imagePaths as $idx => $path) {
            $this->db()->insert('news_gallery', [
                'news_id' => $newsId,
                'image_path' => $path,
                'sort_order' => $idx + 1
            ]);
        }
    }

    public function paginateWithDetails(int $page = 1, int $perPage = 9, ?int $categoryId = null, ?string $search = null, ?string $status = 'published'): array
    {
        $where = ["n.is_deleted = 0"];
        $params = [];

        if ($status !== null) {
            $where[] = "n.status = ?";
            $params[] = $status;
        }

        if ($categoryId !== null && $categoryId > 0) {
            $where[] = "n.category_id = ?";
            $params[] = $categoryId;
        }

        if (!empty($search)) {
            $where[] = "(n.title_uz LIKE ? OR n.title_ru LIKE ? OR n.title_en LIKE ? OR n.content_uz LIKE ?)";
            $term = "%{$search}%";
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
        }

        $whereClause = implode(' AND ', $where);

        // Count total
        $countSql = "SELECT COUNT(*) FROM news n WHERE {$whereClause}";
        $total = (int)$this->db()->value($countSql, $params);

        $totalPages = (int)ceil($total / $perPage);
        $page = max(1, min($page, max(1, $totalPages)));
        $offset = ($page - 1) * $perPage;

        $sql = "SELECT n.*, c.name_uz as cat_name_uz, c.name_ru as cat_name_ru, c.name_en as cat_name_en, c.slug as cat_slug, u.full_name as author_name 
                FROM news n 
                LEFT JOIN news_categories c ON c.id = n.category_id 
                LEFT JOIN users u ON u.id = n.author_id 
                WHERE {$whereClause} 
                ORDER BY n.published_at DESC, n.id DESC 
                LIMIT {$perPage} OFFSET {$offset}";

        $items = $this->db()->query($sql, $params);

        return [
            'data' => $items,
            'current_page' => $page,
            'per_page' => $perPage,
            'total' => $total,
            'total_pages' => $totalPages,
            'has_prev' => $page > 1,
            'has_next' => $page < $totalPages
        ];
    }

    public function getFeatured(): ?array
    {
        $sql = "SELECT n.*, c.name_uz as cat_name_uz, c.name_ru as cat_name_ru, c.name_en as cat_name_en 
                FROM news n 
                LEFT JOIN news_categories c ON c.id = n.category_id 
                WHERE n.is_featured = 1 AND n.status = 'published' AND n.is_deleted = 0 
                ORDER BY n.published_at DESC 
                LIMIT 1";
        return $this->db()->first($sql);
    }

    public function getAnnouncements(int $limit = 5): array
    {
        $sql = "SELECT * FROM news 
                WHERE is_announcement = 1 AND status = 'published' AND is_deleted = 0 
                ORDER BY published_at DESC 
                LIMIT " . (int)$limit;
        return $this->db()->query($sql);
    }

    public function getRelated(int $currentId, int $categoryId, int $limit = 3): array
    {
        $sql = "SELECT n.*, c.name_uz as cat_name_uz 
                FROM news n 
                LEFT JOIN news_categories c ON c.id = n.category_id 
                WHERE n.id != ? AND n.category_id = ? AND n.status = 'published' AND n.is_deleted = 0 
                ORDER BY n.published_at DESC 
                LIMIT " . (int)$limit;
        return $this->db()->query($sql, [$currentId, $categoryId]);
    }
}

