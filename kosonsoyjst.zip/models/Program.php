<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Program extends Model
{
    protected string $table = 'programs';

    public function allActive(): array
    {
        return $this->db()->query("SELECT * FROM programs WHERE is_active = 1 ORDER BY sort_order ASC, id ASC");
    }
}

