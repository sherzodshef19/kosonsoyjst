<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Management extends Model
{
    protected string $table = 'management';
    protected bool $hasSoftDelete = true;

    public function allActive(): array
    {
        return $this->db()->query(
            "SELECT * FROM `management` 
             WHERE is_active = 1 AND is_deleted = 0 
             ORDER BY sort_order ASC, id ASC"
        );
    }

    public function getByCategory(string $cat): array
    {
        return $this->db()->query(
            "SELECT * FROM `management` 
             WHERE category = ? AND is_active = 1 AND is_deleted = 0 
             ORDER BY sort_order ASC, id ASC",
            [$cat]
        );
    }
}

