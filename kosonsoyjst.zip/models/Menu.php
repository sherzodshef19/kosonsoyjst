<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Menu extends Model
{
    protected string $table = 'menus';

    public function getTree(string $location = 'header'): array
    {
        $rows = $this->db()->query(
            "SELECT * FROM menus WHERE location = ? AND is_active = 1 ORDER BY sort_order ASC, id ASC",
            [$location]
        );

        $parents = [];
        $children = [];

        foreach ($rows as $r) {
            if (empty($r['parent_id'])) {
                $parents[$r['id']] = $r;
                $parents[$r['id']]['children'] = [];
            } else {
                $children[$r['parent_id']][] = $r;
            }
        }

        foreach ($children as $parentId => $items) {
            if (isset($parents[$parentId])) {
                $parents[$parentId]['children'] = $items;
            }
        }

        return array_values($parents);
    }
}

