<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Application extends Model
{
    protected string $table = 'vacancy_applications';
    protected bool $hasSoftDelete = true;

    public function allWithVacancy(?int $vacancyId = null, ?string $status = null): array
    {
        $where = ["a.is_deleted = 0"];
        $params = [];

        if ($vacancyId !== null && $vacancyId > 0) {
            $where[] = "a.vacancy_id = ?";
            $params[] = $vacancyId;
        }

        if (!empty($status)) {
            $where[] = "a.status = ?";
            $params[] = $status;
        }

        $whereClause = implode(' AND ', $where);

        $sql = "SELECT a.*, v.title_uz as vacancy_title 
                FROM vacancy_applications a 
                JOIN vacancies v ON v.id = a.vacancy_id 
                WHERE {$whereClause} 
                ORDER BY a.id DESC";

        return $this->db()->query($sql, $params);
    }
}

