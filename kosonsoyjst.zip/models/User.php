<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class User extends Model
{
    protected string $table = 'users';

    public function allWithRole(): array
    {
        $sql = "SELECT u.*, r.display_name as role_title, r.name as role_name 
                FROM users u 
                JOIN roles r ON r.id = u.role_id 
                ORDER BY u.id DESC";
        return $this->db()->query($sql);
    }
}

