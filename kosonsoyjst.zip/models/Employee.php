<?php
declare(strict_types=1);

namespace Models;

use Core\Model;

class Employee extends Model
{
    protected string $table = 'employees';
    protected bool $hasSoftDelete = true;

    public function allActive(): array
    {
        return $this->db()->query(
            "SELECT * FROM `employees` 
             WHERE is_active = 1 AND is_deleted = 0 
             ORDER BY sort_order ASC, id ASC"
        );
    }
}

